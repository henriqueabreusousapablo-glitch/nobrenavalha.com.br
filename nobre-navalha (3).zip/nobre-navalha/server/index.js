import { loadConfig } from './config.js';
import { openDb } from './db.js';
import { createApp } from './app.js';

const config = loadConfig();
const db = openDb(config.dbPath);
const server = createApp({ config, db });

server.listen(config.port, config.host, () => {
  console.log(`\n  Nobre Navalha no ar: http://localhost:${config.port}`);
  console.log(`  Banco de dados:       ${config.dbPath}`);
  console.log(`  Painel:               http://localhost:${config.port}/admin`);
  if (config.usingDefaultPassword) {
    console.log('  ATENÇÃO: usando a senha de desenvolvimento "navalha123". Defina ADMIN_PASSWORD antes de publicar.');
  }
  if (!config.adminPassword) {
    console.warn('  ATENÇÃO: ADMIN_PASSWORD não definida. O painel /admin está DESATIVADO.');
  }
  console.log('');
});

let closing = false;
function shutdown(signal) {
  if (closing) return;
  closing = true;
  console.log(`\n${signal} recebido, encerrando...`);
  server.close(() => {
    db.close();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 10_000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
