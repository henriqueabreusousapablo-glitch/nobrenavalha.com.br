import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

/**
 * Lê as variáveis de ambiente e devolve a configuração do servidor.
 * Todas as variáveis são opcionais em desenvolvimento.
 */
export function loadConfig(env = process.env) {
  const isProd = env.NODE_ENV === 'production';
  const hops = env.TRUST_PROXY === undefined ? (isProd ? 1 : 0) : Number(env.TRUST_PROXY) || 0;

  return {
    root,
    isProd,
    port: Number(env.PORT) || 3000,
    host: env.HOST || '0.0.0.0',
    dbPath: env.DATABASE_PATH || path.join(root, 'data', 'nobre-navalha.db'),
    distDir: env.DIST_DIR || path.join(root, 'dist'),
    // URL pública do site (ex.: https://nobrenavalha.com.br). Usada em canonical, sitemap e JSON-LD.
    siteUrl: (env.SITE_URL || '').trim().replace(/\/+$/, ''),
    timezone: env.SHOP_TIMEZONE || 'America/Sao_Paulo',
    // Em produção a senha é obrigatória; sem ela o painel fica desativado.
    adminPassword: env.ADMIN_PASSWORD || (isProd ? '' : 'navalha123'),
    usingDefaultPassword: !env.ADMIN_PASSWORD && !isProd,
    // Quantos proxies confiáveis existem na frente do servidor (Render, Railway, Fly, Nginx...).
    trustProxyHops: hops,
    logRequests: env.LOG_REQUESTS !== '0',
  };
}
