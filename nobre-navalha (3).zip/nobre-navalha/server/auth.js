import crypto from 'node:crypto';

const TOKEN_TTL_MS = 12 * 60 * 60 * 1000; // 12 horas

const sha256 = (value) => crypto.createHash('sha256').update(value).digest();

/** Compara senhas em tempo constante (hash antes para igualar o tamanho). */
export function passwordMatches(input, expected) {
  if (!expected || typeof input !== 'string') return false;
  return crypto.timingSafeEqual(sha256(input), sha256(expected));
}

/**
 * Token assinado: base64url(payload).assinatura.
 * A chave mistura o segredo do banco com a senha atual, então trocar a
 * senha invalida automaticamente todos os tokens antigos.
 */
export function createAuth({ secret, password }) {
  const key = crypto.createHmac('sha256', secret).update(sha256(password || '')).digest();
  const sign = (body) => crypto.createHmac('sha256', key).update(body).digest('base64url');

  return {
    issue(now = Date.now()) {
      const exp = now + TOKEN_TTL_MS;
      const body = Buffer.from(JSON.stringify({ exp, n: crypto.randomBytes(8).toString('hex') })).toString('base64url');
      return { token: `${body}.${sign(body)}`, expiresAt: new Date(exp).toISOString() };
    },
    verify(token, now = Date.now()) {
      if (!password || typeof token !== 'string') return false;
      const [body, signature, extra] = token.split('.');
      if (!body || !signature || extra !== undefined) return false;
      const expected = Buffer.from(sign(body));
      const received = Buffer.from(signature);
      if (expected.length !== received.length || !crypto.timingSafeEqual(expected, received)) return false;
      try {
        const { exp } = JSON.parse(Buffer.from(body, 'base64url').toString('utf8'));
        return typeof exp === 'number' && exp > now;
      } catch {
        return false;
      }
    },
  };
}
