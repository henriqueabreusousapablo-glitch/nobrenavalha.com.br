import crypto from 'node:crypto';
import { transaction } from './db.js';
import { DEFAULT_SETTINGS } from './seed.js';
import { ApiError } from './errors.js';
import {
  addDays,
  cleanName,
  fromMin,
  isValidDate,
  isValidTime,
  normalizeCode,
  normalizePhone,
  toMin,
  weekdayOf,
} from './validate.js';

export const MAX_ACTIVE_PER_PHONE = 3;
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789'; // sem 0/O, 1/I/L

/* ------------------------------------------------------------------ */
/* Relógio no fuso da barbearia                                        */
/* ------------------------------------------------------------------ */

export function shopNow(timezone, date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: timezone,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hourCycle: 'h23',
  }).formatToParts(date);
  const get = (type) => parts.find((p) => p.type === type).value;
  return {
    date: `${get('year')}-${get('month')}-${get('day')}`,
    minutes: Number(get('hour')) * 60 + Number(get('minute')),
  };
}

/* ------------------------------------------------------------------ */
/* Configurações da barbearia                                          */
/* ------------------------------------------------------------------ */

export function loadSettings(db) {
  const raw = { ...DEFAULT_SETTINGS };
  for (const row of db.prepare('SELECT key, value FROM settings').all()) {
    try {
      raw[row.key] = JSON.parse(row.value);
    } catch {
      /* valor corrompido: mantém o padrão */
    }
  }
  return {
    businessName: raw.business_name,
    tagline: raw.tagline,
    phone: raw.phone,
    whatsapp: raw.whatsapp,
    address: raw.address,
    instagram: raw.instagram,
    hours: raw.hours,
    closedDates: raw.closed_dates,
    intervalMin: raw.interval_min,
    maxDaysAhead: raw.max_days_ahead,
    minNoticeMin: raw.min_notice_min,
  };
}

const text = (v, label, max, field) => {
  if (typeof v !== 'string' || !v.trim() || v.trim().length > max) {
    throw new ApiError(400, 'VALIDATION', `${label} é obrigatório (até ${max} caracteres).`, {
      [field]: `Informe ${label.toLowerCase()} com até ${max} caracteres.`,
    });
  }
  return v.normalize('NFC').trim();
};

/** Valida o corpo do PUT /api/admin/settings e devolve { chave_no_banco: valor }. */
export function parseSettingsInput(body) {
  const out = {};
  const fail = (field, message) => {
    throw new ApiError(400, 'VALIDATION', message, { [field]: message });
  };

  if (body.businessName !== undefined) out.business_name = text(body.businessName, 'Nome', 60, 'businessName');
  if (body.tagline !== undefined) out.tagline = text(body.tagline, 'Frase de destaque', 90, 'tagline');
  if (body.phone !== undefined) out.phone = text(body.phone, 'Telefone', 30, 'phone');
  if (body.address !== undefined) out.address = text(body.address, 'Endereço', 200, 'address');

  if (body.whatsapp !== undefined) {
    let digits = String(body.whatsapp).replace(/\D/g, '');
    if (digits.length === 10 || digits.length === 11) digits = `55${digits}`;
    if (!/^55\d{10,11}$/.test(digits)) fail('whatsapp', 'WhatsApp inválido. Use DDD + número, ex.: (11) 91234-5678.');
    out.whatsapp = digits;
  }

  if (body.instagram !== undefined) {
    const handle = String(body.instagram)
      .trim()
      .replace(/^https?:\/\/(www\.)?instagram\.com\//i, '')
      .replace(/^@/, '')
      .replace(/[/?#].*$/, '');
    if (handle && !/^[A-Za-z0-9._]{1,30}$/.test(handle)) fail('instagram', 'Usuário do Instagram inválido.');
    out.instagram = handle;
  }

  if (body.hours !== undefined) {
    const hours = {};
    for (let day = 0; day <= 6; day += 1) {
      const entry = body.hours?.[day] ?? body.hours?.[String(day)];
      if (entry === null || entry === undefined) {
        hours[day] = null;
        continue;
      }
      if (!isValidTime(entry.open) || !isValidTime(entry.close) || toMin(entry.open) >= toMin(entry.close)) {
        fail('hours', 'Horário inválido: a abertura deve ser antes do fechamento.');
      }
      hours[day] = { open: entry.open, close: entry.close };
    }
    out.hours = hours;
  }

  if (body.closedDates !== undefined) {
    if (!Array.isArray(body.closedDates) || body.closedDates.length > 366 || !body.closedDates.every(isValidDate)) {
      fail('closedDates', 'Lista de datas fechadas inválida.');
    }
    out.closed_dates = [...new Set(body.closedDates)].sort();
  }

  if (body.intervalMin !== undefined) {
    if (![15, 30, 60].includes(Number(body.intervalMin))) fail('intervalMin', 'O intervalo deve ser 15, 30 ou 60 minutos.');
    out.interval_min = Number(body.intervalMin);
  }
  if (body.maxDaysAhead !== undefined) {
    const n = Number(body.maxDaysAhead);
    if (!Number.isInteger(n) || n < 1 || n > 90) fail('maxDaysAhead', 'Antecedência máxima: de 1 a 90 dias.');
    out.max_days_ahead = n;
  }
  if (body.minNoticeMin !== undefined) {
    const n = Number(body.minNoticeMin);
    if (!Number.isInteger(n) || n < 0 || n > 1440) fail('minNoticeMin', 'Antecedência mínima: de 0 a 1440 minutos.');
    out.min_notice_min = n;
  }
  return out;
}

export function saveSettings(db, values) {
  const upsert = db.prepare(
    'INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value',
  );
  transaction(db, () => {
    for (const [key, value] of Object.entries(values)) upsert.run(key, JSON.stringify(value));
  });
}

/* ------------------------------------------------------------------ */
/* Horários disponíveis                                                */
/* ------------------------------------------------------------------ */

/**
 * Gera a grade de horários de um dia para um barbeiro e uma duração.
 * Devolve todos os horários da grade, marcando quais estão livres.
 */
export function buildDaySlots({ date, settings, durationMin, now, booked }) {
  const closed = (reason) => ({ date, open: false, reason, slots: [] });

  if (date < now.date) return closed('past');
  if (date > addDays(now.date, settings.maxDaysAhead)) return closed('too_far');
  if (settings.closedDates.includes(date)) return closed('holiday');

  const dayHours = settings.hours[weekdayOf(date)];
  if (!dayHours) return closed('closed');

  const open = toMin(dayHours.open);
  const close = toMin(dayHours.close);
  const slots = [];

  for (let start = open; start + durationMin <= close; start += settings.intervalMin) {
    const end = start + durationMin;
    const tooSoon = date === now.date && start < now.minutes + settings.minNoticeMin;
    const overlaps = booked.some((b) => b.start_min < end && b.end_min > start);
    slots.push({
      time: fromMin(start),
      available: !tooSoon && !overlaps,
      ...(tooSoon ? { reason: 'past' } : overlaps ? { reason: 'taken' } : {}),
    });
  }
  return { date, open: true, slots };
}

function findBookable(db, serviceId, barberId) {
  const service = db.prepare('SELECT * FROM services WHERE id = ? AND active = 1').get(serviceId);
  const barber = db.prepare('SELECT * FROM barbers WHERE id = ? AND active = 1').get(barberId);
  return { service, barber };
}

export function getAvailability(db, { date, barberId, serviceId }, now) {
  const fields = {};
  if (!isValidDate(date)) fields.date = 'Data inválida.';
  const { service, barber } = findBookable(db, Number(serviceId), Number(barberId));
  if (!service) fields.serviceId = 'Serviço indisponível.';
  if (!barber) fields.barberId = 'Barbeiro indisponível.';
  if (Object.keys(fields).length) throw new ApiError(400, 'VALIDATION', 'Parâmetros inválidos.', fields);

  const booked = db
    .prepare("SELECT start_min, end_min FROM appointments WHERE barber_id = ? AND date = ? AND status <> 'cancelled'")
    .all(barber.id, date);
  return buildDaySlots({ date, settings: loadSettings(db), durationMin: service.duration_min, now, booked });
}

/* ------------------------------------------------------------------ */
/* Agendamentos                                                        */
/* ------------------------------------------------------------------ */

export function appointmentDto(row) {
  return {
    id: row.id,
    code: row.code,
    date: row.date,
    time: fromMin(row.start_min),
    endTime: fromMin(row.end_min),
    serviceId: row.service_id,
    serviceName: row.service_name,
    priceCents: row.price_cents,
    barberId: row.barber_id,
    barberName: row.barber_name,
    customerName: row.customer_name,
    customerPhone: row.customer_phone,
    status: row.status,
    createdAt: row.created_at,
  };
}

const APPT_SELECT = `
  SELECT a.*, b.name AS barber_name
  FROM appointments a JOIN barbers b ON b.id = a.barber_id`;

function generateCode(db) {
  for (let attempt = 0; attempt < 8; attempt += 1) {
    let code = '';
    for (let i = 0; i < 6; i += 1) code += CODE_ALPHABET[crypto.randomInt(CODE_ALPHABET.length)];
    if (!db.prepare('SELECT 1 FROM appointments WHERE code = ?').get(code)) return code;
  }
  throw new ApiError(500, 'CODE_GENERATION', 'Não foi possível gerar o código do agendamento.');
}

export function createAppointment(db, input, now) {
  const fields = {};
  const name = cleanName(input.name);
  if (!name) fields.name = 'Informe seu nome (apenas letras, de 2 a 80 caracteres).';
  const phone = normalizePhone(input.phone);
  if (!phone) fields.phone = 'Informe um telefone válido com DDD, ex.: (11) 91234-5678.';
  if (!isValidDate(input.date)) fields.date = 'Escolha uma data.';
  if (!isValidTime(input.time)) fields.time = 'Escolha um horário.';
  const serviceId = Number(input.serviceId);
  const barberId = Number(input.barberId);
  const { service, barber } = findBookable(db, serviceId, barberId);
  if (!service) fields.serviceId = 'Escolha um serviço.';
  if (!barber) fields.barberId = 'Escolha um barbeiro.';
  if (Object.keys(fields).length) {
    throw new ApiError(400, 'VALIDATION', 'Confira os campos destacados.', fields);
  }

  const start = toMin(input.time);
  const end = start + service.duration_min;

  return transaction(db, () => {
    const settings = loadSettings(db);

    // 1. O horário existe na grade do dia e está livre? (mesma regra da tela de horários)
    const booked = db
      .prepare("SELECT start_min, end_min FROM appointments WHERE barber_id = ? AND date = ? AND status <> 'cancelled'")
      .all(barber.id, input.date);
    const day = buildDaySlots({ date: input.date, settings, durationMin: service.duration_min, now, booked });
    if (!day.open) {
      throw new ApiError(409, 'DAY_UNAVAILABLE', 'A barbearia não atende nesta data. Escolha outro dia.');
    }
    const slot = day.slots.find((s) => s.time === input.time);
    if (!slot) {
      throw new ApiError(400, 'INVALID_TIME', 'Esse horário não existe na agenda do dia. Escolha um da lista.', {
        time: 'Horário inválido.',
      });
    }
    if (!slot.available) {
      const message =
        slot.reason === 'past'
          ? 'Esse horário não está mais disponível. Escolha um mais tarde.'
          : 'Esse horário acabou de ser reservado. Escolha outro, por favor.';
      throw new ApiError(409, 'SLOT_TAKEN', message, { time: message });
    }

    // 2. O mesmo cliente não pode estar em dois lugares ao mesmo tempo, nem acumular reservas.
    const overlapSamePhone = db
      .prepare(
        `SELECT 1 FROM appointments
         WHERE customer_phone = ? AND date = ? AND status <> 'cancelled'
           AND start_min < ? AND end_min > ? LIMIT 1`,
      )
      .get(phone, input.date, end, start);
    if (overlapSamePhone) {
      throw new ApiError(409, 'PHONE_OVERLAP', 'Você já tem um agendamento nesse horário.', {
        time: 'Você já tem um agendamento nesse horário.',
      });
    }
    const active = db
      .prepare(
        `SELECT COUNT(*) AS c FROM appointments
         WHERE customer_phone = ? AND status = 'confirmed'
           AND (date > ? OR (date = ? AND end_min > ?))`,
      )
      .get(phone, now.date, now.date, now.minutes).c;
    if (active >= MAX_ACTIVE_PER_PHONE) {
      throw new ApiError(
        429,
        'BOOKING_LIMIT',
        `Cada telefone pode ter até ${MAX_ACTIVE_PER_PHONE} agendamentos ativos. Cancele um ou fale com a gente.`,
      );
    }

    // 3. Grava. O índice único é a segunda barreira contra duplicidade.
    const code = generateCode(db);
    let id;
    try {
      const result = db
        .prepare(
          `INSERT INTO appointments
           (code, service_id, barber_id, date, start_min, end_min, customer_name, customer_phone, service_name, price_cents)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .run(code, service.id, barber.id, input.date, start, end, name, phone, service.name, service.price_cents);
      id = Number(result.lastInsertRowid);
    } catch (err) {
      if (String(err.message).includes('UNIQUE')) {
        throw new ApiError(409, 'SLOT_TAKEN', 'Esse horário acabou de ser reservado. Escolha outro, por favor.');
      }
      throw err;
    }
    return appointmentDto(db.prepare(`${APPT_SELECT} WHERE a.id = ?`).get(id));
  });
}

function findForCustomer(db, input) {
  const code = normalizeCode(input.code);
  const phone = normalizePhone(input.phone);
  const notFound = new ApiError(404, 'NOT_FOUND', 'Não encontramos um agendamento com esse código e telefone.');
  if (!code || !phone) throw notFound;
  const row = db.prepare(`${APPT_SELECT} WHERE a.code = ?`).get(code);
  if (!row || row.customer_phone !== phone) throw notFound;
  return row;
}

const hasStarted = (row, now) => row.date < now.date || (row.date === now.date && row.start_min <= now.minutes);

export function lookupAppointment(db, input, now) {
  const row = findForCustomer(db, input);
  return { ...appointmentDto(row), canCancel: row.status === 'confirmed' && !hasStarted(row, now) };
}

export function cancelAppointmentByCustomer(db, input, now) {
  return transaction(db, () => {
    const row = findForCustomer(db, input);
    if (row.status !== 'confirmed') {
      throw new ApiError(409, 'NOT_CANCELLABLE', 'Este agendamento não pode mais ser cancelado.');
    }
    if (hasStarted(row, now)) {
      throw new ApiError(409, 'PAST_APPOINTMENT', 'Este horário já passou.');
    }
    db.prepare("UPDATE appointments SET status = 'cancelled' WHERE id = ?").run(row.id);
    return { ...appointmentDto({ ...row, status: 'cancelled' }), canCancel: false };
  });
}

/* ----------------------------- painel ----------------------------- */

export function listAppointments(db, { from, to, status, q }) {
  const where = ['a.date >= ?', 'a.date <= ?'];
  const params = [from, to];
  if (status) {
    where.push('a.status = ?');
    params.push(status);
  }
  if (q) {
    const term = q.replace(/[%_\\]/g, '').trim();
    const digits = term.replace(/\D/g, '');
    const clauses = ['a.customer_name LIKE ?', 'a.code LIKE ?'];
    const values = [`%${term}%`, `%${term.toUpperCase()}%`];
    if (digits) {
      clauses.push('a.customer_phone LIKE ?');
      values.push(`%${digits}%`);
    }
    if (term) {
      where.push(`(${clauses.join(' OR ')})`);
      params.push(...values);
    }
  }
  return db
    .prepare(`${APPT_SELECT} WHERE ${where.join(' AND ')} ORDER BY a.date, a.start_min, a.id`)
    .all(...params)
    .map(appointmentDto);
}

export function setAppointmentStatus(db, id, status) {
  return transaction(db, () => {
    const row = db.prepare(`${APPT_SELECT} WHERE a.id = ?`).get(id);
    if (!row) throw new ApiError(404, 'NOT_FOUND', 'Agendamento não encontrado.');
    if (row.status === 'cancelled' && status !== 'cancelled') {
      const clash = db
        .prepare(
          `SELECT 1 FROM appointments
           WHERE barber_id = ? AND date = ? AND status <> 'cancelled' AND id <> ?
             AND start_min < ? AND end_min > ? LIMIT 1`,
        )
        .get(row.barber_id, row.date, row.id, row.end_min, row.start_min);
      if (clash) {
        throw new ApiError(409, 'SLOT_TAKEN', 'Não é possível reativar: o horário já foi ocupado por outro cliente.');
      }
    }
    db.prepare('UPDATE appointments SET status = ? WHERE id = ?').run(status, id);
    return appointmentDto({ ...row, status });
  });
}
