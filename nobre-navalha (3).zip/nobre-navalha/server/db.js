import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import { seedDefaults } from './seed.js';

const SCHEMA = `
CREATE TABLE IF NOT EXISTS meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS services (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  name         TEXT    NOT NULL,
  description  TEXT    NOT NULL DEFAULT '',
  price_cents  INTEGER NOT NULL CHECK (price_cents >= 0),
  duration_min INTEGER NOT NULL CHECK (duration_min BETWEEN 15 AND 480),
  active       INTEGER NOT NULL DEFAULT 1,
  sort_order   INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS barbers (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  role        TEXT    NOT NULL DEFAULT '',
  bio         TEXT    NOT NULL DEFAULT '',
  specialties TEXT    NOT NULL DEFAULT '[]',
  photo_url   TEXT    NOT NULL DEFAULT '',
  active      INTEGER NOT NULL DEFAULT 1,
  sort_order  INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT    NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS appointments (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  code           TEXT    NOT NULL UNIQUE,
  service_id     INTEGER NOT NULL REFERENCES services(id),
  barber_id      INTEGER NOT NULL REFERENCES barbers(id),
  date           TEXT    NOT NULL,           -- AAAA-MM-DD (fuso da barbearia)
  start_min      INTEGER NOT NULL,           -- minutos desde 00:00
  end_min        INTEGER NOT NULL,
  customer_name  TEXT    NOT NULL,
  customer_phone TEXT    NOT NULL,           -- só dígitos, sem +55
  service_name   TEXT    NOT NULL,           -- cópia do nome na hora da reserva
  price_cents    INTEGER NOT NULL,           -- cópia do preço na hora da reserva
  status         TEXT    NOT NULL DEFAULT 'confirmed'
                 CHECK (status IN ('confirmed', 'done', 'cancelled', 'no_show')),
  created_at     TEXT    NOT NULL DEFAULT (datetime('now')),
  CHECK (end_min > start_min)
);

-- Barreira final contra reserva duplicada: dois agendamentos ativos não podem
-- começar no mesmo minuto para o mesmo barbeiro, mesmo se a checagem de
-- sobreposição falhar por algum motivo.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_active_slot
  ON appointments (barber_id, date, start_min)
  WHERE status <> 'cancelled';

CREATE INDEX IF NOT EXISTS idx_appt_day   ON appointments (date, barber_id);
CREATE INDEX IF NOT EXISTS idx_appt_phone ON appointments (customer_phone, date);
`;

/** Executa fn dentro de uma transação que já reserva o banco para escrita. */
export function transaction(db, fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {
      /* a transação já pode ter sido encerrada */
    }
    throw err;
  }
}

export function openDb(file) {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA synchronous = NORMAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 5000;');
  db.exec(SCHEMA);
  seedDefaults(db);
  return db;
}

/** Segredo usado para assinar o token do painel. Gerado uma vez e guardado no banco. */
export function getOrCreateSecret(db) {
  const row = db.prepare("SELECT value FROM meta WHERE key = 'admin_secret'").get();
  if (row) return row.value;
  const secret = crypto.randomBytes(32).toString('hex');
  db.prepare("INSERT OR IGNORE INTO meta (key, value) VALUES ('admin_secret', ?)").run(secret);
  return db.prepare("SELECT value FROM meta WHERE key = 'admin_secret'").get().value;
}
