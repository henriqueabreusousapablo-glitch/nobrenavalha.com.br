import { ApiError } from './errors.js';
import { requireInt, requireString } from './validate.js';

/* ------------------------------ serviços ------------------------------ */

export const serviceDto = (r) => ({
  id: r.id,
  name: r.name,
  description: r.description,
  priceCents: r.price_cents,
  durationMin: r.duration_min,
  active: Boolean(r.active),
  sortOrder: r.sort_order,
});

function parseService(body) {
  return {
    name: requireString(body.name, 'name', 'Nome', { min: 2, max: 80 }),
    description: requireString(body.description, 'description', 'Descrição', { max: 240, allowEmpty: true }),
    priceCents: requireInt(body.priceCents, 'priceCents', 'Preço', { min: 0, max: 1_000_000 }),
    durationMin: requireInt(body.durationMin, 'durationMin', 'Duração', { min: 15, max: 480 }),
    active: body.active === undefined ? true : Boolean(body.active),
    sortOrder: body.sortOrder === undefined ? null : requireInt(body.sortOrder, 'sortOrder', 'Ordem', { min: 0, max: 9999 }),
  };
}

export function listServices(db, { onlyActive = false } = {}) {
  const where = onlyActive ? 'WHERE active = 1' : '';
  return db.prepare(`SELECT * FROM services ${where} ORDER BY sort_order, id`).all().map(serviceDto);
}

export function createService(db, body) {
  const s = parseService(body);
  const order = s.sortOrder ?? db.prepare('SELECT COALESCE(MAX(sort_order), -1) + 1 AS n FROM services').get().n;
  const result = db
    .prepare('INSERT INTO services (name, description, price_cents, duration_min, active, sort_order) VALUES (?, ?, ?, ?, ?, ?)')
    .run(s.name, s.description, s.priceCents, s.durationMin, s.active ? 1 : 0, order);
  return serviceDto(db.prepare('SELECT * FROM services WHERE id = ?').get(Number(result.lastInsertRowid)));
}

export function updateService(db, id, body) {
  const current = db.prepare('SELECT * FROM services WHERE id = ?').get(id);
  if (!current) throw new ApiError(404, 'NOT_FOUND', 'Serviço não encontrado.');
  const s = parseService(body);
  db.prepare(
    'UPDATE services SET name = ?, description = ?, price_cents = ?, duration_min = ?, active = ?, sort_order = ? WHERE id = ?',
  ).run(s.name, s.description, s.priceCents, s.durationMin, s.active ? 1 : 0, s.sortOrder ?? current.sort_order, id);
  return serviceDto(db.prepare('SELECT * FROM services WHERE id = ?').get(id));
}

/** Serviços já usados em agendamentos são apenas desativados, para manter o histórico. */
export function deleteService(db, id) {
  const current = db.prepare('SELECT * FROM services WHERE id = ?').get(id);
  if (!current) throw new ApiError(404, 'NOT_FOUND', 'Serviço não encontrado.');
  const used = db.prepare('SELECT 1 FROM appointments WHERE service_id = ? LIMIT 1').get(id);
  if (used) {
    db.prepare('UPDATE services SET active = 0 WHERE id = ?').run(id);
    return { deleted: false, deactivated: true };
  }
  db.prepare('DELETE FROM services WHERE id = ?').run(id);
  return { deleted: true, deactivated: false };
}

/* ----------------------------- barbeiros ----------------------------- */

export const barberDto = (r) => {
  let specialties = [];
  try {
    specialties = JSON.parse(r.specialties);
  } catch {
    /* mantém vazio */
  }
  return {
    id: r.id,
    name: r.name,
    role: r.role,
    bio: r.bio,
    specialties,
    photoUrl: r.photo_url,
    active: Boolean(r.active),
    sortOrder: r.sort_order,
  };
};

function parseBarber(body) {
  let specialties = body.specialties;
  if (typeof specialties === 'string') specialties = specialties.split(',');
  if (!Array.isArray(specialties)) specialties = [];
  specialties = specialties
    .map((s) => String(s).trim())
    .filter(Boolean)
    .slice(0, 6)
    .map((s) => s.slice(0, 40));

  const photoUrl = requireString(body.photoUrl, 'photoUrl', 'Foto', { max: 300, allowEmpty: true });
  if (photoUrl && !/^(\/[\w\-./]+|https:\/\/[^\s]+)$/.test(photoUrl)) {
    throw new ApiError(400, 'VALIDATION', 'Foto inválida.', {
      photoUrl: 'Use um endereço https:// ou um caminho como /equipe/rafael.jpg.',
    });
  }
  return {
    name: requireString(body.name, 'name', 'Nome', { min: 2, max: 60 }),
    role: requireString(body.role, 'role', 'Função', { max: 60, allowEmpty: true }),
    bio: requireString(body.bio, 'bio', 'Apresentação', { max: 280, allowEmpty: true }),
    specialties,
    photoUrl,
    active: body.active === undefined ? true : Boolean(body.active),
    sortOrder: body.sortOrder === undefined ? null : requireInt(body.sortOrder, 'sortOrder', 'Ordem', { min: 0, max: 9999 }),
  };
}

export function listBarbers(db, { onlyActive = false } = {}) {
  const where = onlyActive ? 'WHERE active = 1' : '';
  return db.prepare(`SELECT * FROM barbers ${where} ORDER BY sort_order, id`).all().map(barberDto);
}

export function createBarber(db, body) {
  const b = parseBarber(body);
  const order = b.sortOrder ?? db.prepare('SELECT COALESCE(MAX(sort_order), -1) + 1 AS n FROM barbers').get().n;
  const result = db
    .prepare('INSERT INTO barbers (name, role, bio, specialties, photo_url, active, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(b.name, b.role, b.bio, JSON.stringify(b.specialties), b.photoUrl, b.active ? 1 : 0, order);
  return barberDto(db.prepare('SELECT * FROM barbers WHERE id = ?').get(Number(result.lastInsertRowid)));
}

export function updateBarber(db, id, body) {
  const current = db.prepare('SELECT * FROM barbers WHERE id = ?').get(id);
  if (!current) throw new ApiError(404, 'NOT_FOUND', 'Barbeiro não encontrado.');
  const b = parseBarber(body);
  db.prepare(
    'UPDATE barbers SET name = ?, role = ?, bio = ?, specialties = ?, photo_url = ?, active = ?, sort_order = ? WHERE id = ?',
  ).run(b.name, b.role, b.bio, JSON.stringify(b.specialties), b.photoUrl, b.active ? 1 : 0, b.sortOrder ?? current.sort_order, id);
  return barberDto(db.prepare('SELECT * FROM barbers WHERE id = ?').get(id));
}

export function deleteBarber(db, id) {
  const current = db.prepare('SELECT * FROM barbers WHERE id = ?').get(id);
  if (!current) throw new ApiError(404, 'NOT_FOUND', 'Barbeiro não encontrado.');
  const used = db.prepare('SELECT 1 FROM appointments WHERE barber_id = ? LIMIT 1').get(id);
  if (used) {
    db.prepare('UPDATE barbers SET active = 0 WHERE id = ?').run(id);
    return { deleted: false, deactivated: true };
  }
  db.prepare('DELETE FROM barbers WHERE id = ?').run(id);
  return { deleted: true, deactivated: false };
}
