/**
 * Dados iniciais. São inseridos apenas quando as tabelas estão vazias,
 * então editar pelo painel nunca é sobrescrito em um novo deploy.
 * Tudo aqui é conteúdo de exemplo: troque pelo da sua barbearia no painel /admin.
 */

export const DEFAULT_HOURS = {
  0: null, // domingo
  1: null, // segunda
  2: { open: '09:00', close: '20:00' },
  3: { open: '09:00', close: '20:00' },
  4: { open: '09:00', close: '20:00' },
  5: { open: '09:00', close: '20:00' },
  6: { open: '08:00', close: '18:00' },
};

export const DEFAULT_SETTINGS = {
  business_name: 'Nobre Navalha',
  tagline: 'Seu estilo começa no corte certo',
  phone: '(11) 99999-0000',
  whatsapp: '5511999990000',
  address: 'Av. Paulista, 1000 - Bela Vista, São Paulo - SP',
  instagram: 'nobrenavalha',
  hours: DEFAULT_HOURS,
  closed_dates: [],
  interval_min: 30,
  max_days_ahead: 30,
  min_notice_min: 60,
};

const SERVICES = [
  ['Corte social', 'Tesoura e máquina, acabamento na navalha e finalização com pomada ou óleo.', 5000, 30],
  ['Degradê (low, mid ou high fade)', 'Transição milimétrica na máquina, desenhada para o formato do seu rosto.', 6500, 60],
  ['Mullet e cortes texturizados', 'Corte com camadas e movimento, ajustado ao tipo e à direção do fio.', 7500, 60],
  ['Buzz cut', 'Máquina em um único comprimento, contorno limpo e acabamento na navalha.', 4000, 30],
  ['Barba completa', 'Toalha quente, óleo pré-barba, navalha e hidratação final.', 4500, 30],
  ['Corte + barba', 'O combo completo: corte do seu estilo e barba na navalha, no mesmo horário.', 9500, 60],
  ['Sobrancelha na navalha', 'Limpeza e alinhamento discretos, sem exagero.', 2000, 30],
];

const BARBERS = [
  [
    'Rafael Monteiro',
    'Mestre barbeiro',
    'Referência da casa em degradês e em acabamento na navalha. Atende quem quer o corte milimétrico.',
    ['Degradê (fade)', 'Acabamento na navalha', 'Barba desenhada'],
  ],
  [
    'Diego Fontana',
    'Barbeiro clássico',
    'Cortes sociais na tesoura e barba com toalha quente, no ritmo de quem não tem pressa.',
    ['Corte social', 'Tesoura', 'Barba com toalha quente'],
  ],
  [
    'Caio Nascimento',
    'Barbeiro criativo',
    'Cuida dos cortes de personalidade: mullet, texturizados e buzz cut com contorno preciso.',
    ['Mullet', 'Texturizados', 'Buzz cut'],
  ],
];

export function seedDefaults(db) {
  const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    insertSetting.run(key, JSON.stringify(value));
  }

  if (db.prepare('SELECT COUNT(*) AS c FROM services').get().c === 0) {
    const ins = db.prepare(
      'INSERT INTO services (name, description, price_cents, duration_min, sort_order) VALUES (?, ?, ?, ?, ?)',
    );
    SERVICES.forEach(([name, description, price, duration], i) => ins.run(name, description, price, duration, i));
  }

  if (db.prepare('SELECT COUNT(*) AS c FROM barbers').get().c === 0) {
    const ins = db.prepare('INSERT INTO barbers (name, role, bio, specialties, sort_order) VALUES (?, ?, ?, ?, ?)');
    BARBERS.forEach(([name, role, bio, specialties], i) => ins.run(name, role, bio, JSON.stringify(specialties), i));
  }
}
