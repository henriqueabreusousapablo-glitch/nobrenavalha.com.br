import { after, before, describe, test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { loadConfig } from '../config.js';
import { openDb } from '../db.js';
import { createApp } from '../app.js';
import { RateLimiter } from '../http.js';

// "Agora" fixo: domingo, 25/10/2026, 14:05 (a barbearia fecha aos domingos e segundas).
const NOW = { date: '2026-10-25', minutes: 14 * 60 + 5 };
const TUESDAY = '2026-10-27';
const WEDNESDAY = '2026-10-28';
const THURSDAY = '2026-10-29';
const MONDAY = '2026-10-26';

const SOCIAL = 1; // corte social, 30 min
const DEGRADE = 2; // degradê, 60 min
const [RAFAEL, DIEGO, CAIO] = [1, 2, 3];

const wideLimits = () => ({
  booking: new RateLimiter({ windowMs: 60_000, max: 10_000 }),
  lookup: new RateLimiter({ windowMs: 60_000, max: 10_000 }),
  login: new RateLimiter({ windowMs: 60_000, max: 10_000 }),
  api: new RateLimiter({ windowMs: 60_000, max: 10_000 }),
});

async function startServer({ limits = wideLimits() } = {}) {
  const dist = fs.mkdtempSync(path.join(os.tmpdir(), 'nn-dist-'));
  fs.writeFileSync(
    path.join(dist, 'index.html'),
    '<!doctype html><html><head><!--@seo--></head><body><div id="root"></div><!--@noscript--></body></html>',
  );
  fs.mkdirSync(path.join(dist, 'assets'));
  fs.writeFileSync(path.join(dist, 'assets', 'app-abc123.js'), 'console.log("ok")');

  const config = {
    ...loadConfig({ NODE_ENV: 'test', ADMIN_PASSWORD: 'segredo-de-teste', LOG_REQUESTS: '0' }),
    distDir: dist,
  };
  const db = openDb(':memory:');
  const state = { now: { ...NOW } };
  const server = createApp({ config, db, clock: () => ({ ...state.now }), limits });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const base = `http://127.0.0.1:${server.address().port}`;

  async function api(method, url, body, token) {
    const res = await fetch(base + url, {
      method,
      headers: {
        ...(body ? { 'content-type': 'application/json' } : {}),
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
    const text = await res.text();
    let json = null;
    try {
      json = JSON.parse(text);
    } catch {
      /* resposta não é JSON */
    }
    return { status: res.status, body: json, text, headers: res.headers };
  }

  return {
    api,
    base,
    db,
    state,
    close: () =>
      new Promise((resolve) => {
        server.close(() => {
          db.close();
          resolve();
        });
        server.closeAllConnections();
      }),
  };
}

let phoneCounter = 0;
/** Gera telefones válidos e distintos (DDD 11, celular). */
const nextPhone = () => `1198${String(1000000 + phoneCounter++).slice(-7)}`;

const booking = (overrides = {}) => ({
  name: 'João da Silva',
  phone: nextPhone(),
  serviceId: SOCIAL,
  barberId: RAFAEL,
  date: TUESDAY,
  time: '09:00',
  ...overrides,
});

describe('configuração pública', () => {
  let s;
  before(async () => (s = await startServer()));
  after(() => s.close());

  test('devolve serviços, barbeiros, horários e data/hora da barbearia', async () => {
    const res = await s.api('GET', '/api/config');
    assert.equal(res.status, 200);
    assert.equal(res.body.services.length, 7);
    assert.equal(res.body.barbers.length, 3);
    assert.equal(res.body.business.name, undefined);
    assert.equal(res.body.business.businessName, 'Nobre Navalha');
    assert.deepEqual(res.body.business.hours['2'], { open: '09:00', close: '20:00' });
    assert.equal(res.body.business.hours['1'], null);
    assert.deepEqual(res.body.now, NOW);
  });

  test('rotas desconhecidas e métodos errados respondem com JSON claro', async () => {
    const missing = await s.api('GET', '/api/nao-existe');
    assert.equal(missing.status, 404);
    assert.equal(missing.body.error.code, 'NOT_FOUND');
    const wrong = await s.api('POST', '/api/config', {});
    assert.equal(wrong.status, 405);
  });
});

describe('horários disponíveis', () => {
  let s;
  before(async () => (s = await startServer()));
  after(() => s.close());

  const slots = (date, serviceId = SOCIAL, barberId = RAFAEL) =>
    s.api('GET', `/api/availability?date=${date}&serviceId=${serviceId}&barberId=${barberId}`);

  test('gera a grade do dia respeitando a duração do serviço', async () => {
    const short = await slots(TUESDAY, SOCIAL);
    assert.equal(short.body.open, true);
    assert.equal(short.body.slots[0].time, '09:00');
    assert.equal(short.body.slots.at(-1).time, '19:30');
    assert.equal(short.body.slots.length, 22);

    const long = await slots(TUESDAY, DEGRADE);
    assert.equal(long.body.slots.at(-1).time, '19:00'); // 60 min precisa terminar até 20:00
    assert.equal(long.body.slots.length, 21);
  });

  test('sábado tem horário próprio', async () => {
    const sat = await slots('2026-10-31');
    assert.equal(sat.body.slots[0].time, '08:00');
    assert.equal(sat.body.slots.at(-1).time, '17:30');
  });

  test('explica por que o dia não tem horários', async () => {
    assert.equal((await slots(MONDAY)).body.reason, 'closed');
    assert.equal((await slots(NOW.date)).body.reason, 'closed'); // domingo
    assert.equal((await slots('2026-10-20')).body.reason, 'past');
    assert.equal((await slots('2026-12-30')).body.reason, 'too_far');
  });

  test('rejeita parâmetros inválidos', async () => {
    const res = await s.api('GET', '/api/availability?date=2026-02-30&serviceId=999&barberId=1');
    assert.equal(res.status, 400);
    assert.ok(res.body.error.fields.date);
    assert.ok(res.body.error.fields.serviceId);
  });

  test('no dia de hoje bloqueia horários dentro da antecedência mínima', async () => {
    s.state.now = { date: TUESDAY, minutes: 9 * 60 }; // terça, 09:00; antecedência de 60 min
    const res = await slots(TUESDAY);
    const byTime = Object.fromEntries(res.body.slots.map((x) => [x.time, x.available]));
    assert.equal(byTime['09:00'], false);
    assert.equal(byTime['09:30'], false);
    assert.equal(byTime['10:00'], true);
    s.state.now = { ...NOW };
  });
});

describe('agendamento e reservas duplicadas', () => {
  let s;
  before(async () => (s = await startServer()));
  after(() => s.close());

  test('confirma a reserva e devolve o código', async () => {
    const res = await s.api('POST', '/api/appointments', booking({ time: '09:00', phone: '(11) 91234-5678' }));
    assert.equal(res.status, 201);
    const a = res.body.appointment;
    assert.match(a.code, /^[A-Z2-9]{6}$/);
    assert.equal(a.date, TUESDAY);
    assert.equal(a.time, '09:00');
    assert.equal(a.endTime, '09:30');
    assert.equal(a.barberName, 'Rafael Monteiro');
    assert.equal(a.customerPhone, '11912345678');
    assert.equal(a.priceCents, 5000);
  });

  test('o mesmo horário e barbeiro não pode ser reservado duas vezes', async () => {
    const again = await s.api('POST', '/api/appointments', booking({ time: '09:00' }));
    assert.equal(again.status, 409);
    assert.equal(again.body.error.code, 'SLOT_TAKEN');

    const view = await s.api('GET', `/api/availability?date=${TUESDAY}&serviceId=${SOCIAL}&barberId=${RAFAEL}`);
    assert.equal(view.body.slots.find((x) => x.time === '09:00').available, false);
    assert.equal(view.body.slots.find((x) => x.time === '09:30').available, true);
  });

  test('outro barbeiro continua livre no mesmo horário', async () => {
    const res = await s.api('POST', '/api/appointments', booking({ time: '09:00', barberId: DIEGO }));
    assert.equal(res.status, 201);
  });

  test('serviço longo bloqueia os horários que ele ocupa, sem sobreposição', async () => {
    const long = await s.api('POST', '/api/appointments', booking({ serviceId: DEGRADE, time: '11:00' }));
    assert.equal(long.status, 201);
    assert.equal(long.body.appointment.endTime, '12:00');

    const view = await s.api('GET', `/api/availability?date=${TUESDAY}&serviceId=${SOCIAL}&barberId=${RAFAEL}`);
    const free = Object.fromEntries(view.body.slots.map((x) => [x.time, x.available]));
    assert.equal(free['10:30'], true); // termina às 11:00, exatamente quando o outro começa
    assert.equal(free['11:00'], false);
    assert.equal(free['11:30'], false);
    assert.equal(free['12:00'], true);

    // um corte de 60 min às 10:30 invadiria o das 11:00
    const overlap = await s.api('POST', '/api/appointments', booking({ serviceId: DEGRADE, time: '10:30' }));
    assert.equal(overlap.status, 409);
    // e às 11:30 invadiria o final
    const overlap2 = await s.api('POST', '/api/appointments', booking({ serviceId: SOCIAL, time: '11:30' }));
    assert.equal(overlap2.status, 409);
  });

  test('20 pedidos simultâneos para o mesmo horário geram exatamente uma reserva', async () => {
    const attempts = Array.from({ length: 20 }, (_, i) =>
      s.api('POST', '/api/appointments', booking({ barberId: CAIO, date: WEDNESDAY, time: '15:00', name: `Cliente ${'ABCDEFGHIJKLMNOPQRST'[i]}` })),
    );
    const results = await Promise.all(attempts);
    const created = results.filter((r) => r.status === 201);
    const refused = results.filter((r) => r.status === 409);
    assert.equal(created.length, 1);
    assert.equal(refused.length, 19);
    const rows = s.db
      .prepare("SELECT COUNT(*) AS c FROM appointments WHERE barber_id = ? AND date = ? AND start_min = ? AND status <> 'cancelled'")
      .get(CAIO, WEDNESDAY, 15 * 60);
    assert.equal(rows.c, 1);
  });

  test('o índice único do banco impede duplicidade mesmo sem passar pela API', () => {
    const insert = () =>
      s.db
        .prepare(
          `INSERT INTO appointments (code, service_id, barber_id, date, start_min, end_min, customer_name, customer_phone, service_name, price_cents)
           VALUES (?, 1, ?, ?, 540, 570, 'X', '11911111112', 'Corte', 5000)`,
        )
        .run(`ZZ${Math.random().toString(36).slice(2, 6).toUpperCase()}`, RAFAEL, TUESDAY);
    assert.throws(insert, /UNIQUE/);
  });

  test('o mesmo cliente não pode agendar dois barbeiros no mesmo horário', async () => {
    const phone = nextPhone();
    const first = await s.api('POST', '/api/appointments', booking({ phone, date: THURSDAY, time: '10:00' }));
    assert.equal(first.status, 201);
    const second = await s.api('POST', '/api/appointments', booking({ phone, date: THURSDAY, time: '10:00', barberId: DIEGO }));
    assert.equal(second.status, 409);
    assert.equal(second.body.error.code, 'PHONE_OVERLAP');
  });

  test('limita a 3 agendamentos ativos por telefone', async () => {
    const phone = nextPhone();
    for (const time of ['13:00', '14:00', '15:00']) {
      const ok = await s.api('POST', '/api/appointments', booking({ phone, date: THURSDAY, time, barberId: DIEGO }));
      assert.equal(ok.status, 201);
    }
    const fourth = await s.api('POST', '/api/appointments', booking({ phone, date: THURSDAY, time: '16:00', barberId: DIEGO }));
    assert.equal(fourth.status, 429);
    assert.equal(fourth.body.error.code, 'BOOKING_LIMIT');
  });

  test('campo isca (honeypot) preenchido é recusado', async () => {
    const res = await s.api('POST', '/api/appointments', { ...booking({ time: '18:00' }), website: 'http://spam.example' });
    assert.equal(res.status, 400);
  });
});

describe('validação dos dados', () => {
  let s;
  before(async () => (s = await startServer()));
  after(() => s.close());

  const post = (overrides) => s.api('POST', '/api/appointments', booking(overrides));

  test('telefone inválido', async () => {
    for (const phone of ['123', '(11) 1234-567', '11 81234-5678', '00000000000', 'abc', '(00) 91234-5678']) {
      const res = await post({ phone });
      assert.equal(res.status, 400, `telefone ${phone}`);
      assert.ok(res.body.error.fields.phone, `telefone ${phone}`);
    }
  });

  test('aceita formatos comuns de telefone', async () => {
    const res = await post({ phone: '+55 (21) 98123-4567', time: '12:00' });
    assert.equal(res.status, 201);
    assert.equal(res.body.appointment.customerPhone, '21981234567');
  });

  test('nome inválido', async () => {
    for (const name of ['A', '', '12345', '<script>alert(1)</script>', 'x'.repeat(100)]) {
      const res = await post({ name });
      assert.equal(res.status, 400, `nome ${name}`);
      assert.ok(res.body.error.fields.name);
    }
  });

  test('data, horário e ids inválidos', async () => {
    assert.ok((await post({ date: '2026-02-30' })).body.error.fields.date);
    assert.ok((await post({ time: '25:00' })).body.error.fields.time);
    assert.ok((await post({ serviceId: 999 })).body.error.fields.serviceId);
    assert.ok((await post({ barberId: 999 })).body.error.fields.barberId);
    const offGrid = await post({ time: '10:15' });
    assert.equal(offGrid.status, 400);
    assert.equal(offGrid.body.error.code, 'INVALID_TIME');
  });

  test('não agenda fora do funcionamento nem no passado', async () => {
    assert.equal((await post({ date: MONDAY })).body.error.code, 'DAY_UNAVAILABLE');
    assert.equal((await post({ date: '2026-10-20' })).status, 409);
    assert.equal((await post({ date: '2027-03-01' })).status, 409);
    assert.equal((await post({ time: '20:00' })).status, 400); // fecha às 20:00
    assert.equal((await post({ time: '08:30' })).status, 400); // abre às 09:00
  });

  test('JSON quebrado e corpo gigante', async () => {
    const res = await fetch(`${s.base}/api/appointments`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{ruim' });
    assert.equal(res.status, 400);
    const big = await fetch(`${s.base}/api/appointments`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ name: 'x'.repeat(200_000) }),
    });
    assert.equal(big.status, 413);
  });
});

describe('consulta e cancelamento pelo cliente', () => {
  let s;
  before(async () => (s = await startServer()));
  after(() => s.close());

  test('só quem tem código e telefone consegue ver ou cancelar', async () => {
    const phone = '11977776666';
    const created = await s.api('POST', '/api/appointments', booking({ phone, time: '10:00' }));
    const { code } = created.body.appointment;

    assert.equal((await s.api('POST', '/api/appointments/lookup', { code, phone: '11977770000' })).status, 404);
    assert.equal((await s.api('POST', '/api/appointments/lookup', { code: 'AAAAAA', phone })).status, 404);

    const ok = await s.api('POST', '/api/appointments/lookup', { code: code.toLowerCase(), phone: '(11) 97777-6666' });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.appointment.canCancel, true);

    const blocked = await s.api('POST', '/api/appointments/cancel', { code, phone: '11977770000' });
    assert.equal(blocked.status, 404);

    const cancelled = await s.api('POST', '/api/appointments/cancel', { code, phone });
    assert.equal(cancelled.status, 200);
    assert.equal(cancelled.body.appointment.status, 'cancelled');

    const again = await s.api('POST', '/api/appointments/cancel', { code, phone });
    assert.equal(again.status, 409);

    // o horário volta a ficar livre
    const rebook = await s.api('POST', '/api/appointments', booking({ time: '10:00' }));
    assert.equal(rebook.status, 201);
  });
});

describe('painel administrativo', () => {
  let s;
  let token;
  before(async () => {
    s = await startServer();
    const login = await s.api('POST', '/api/admin/login', { password: 'segredo-de-teste' });
    token = login.body.token;
  });
  after(() => s.close());

  test('exige senha e token válido', async () => {
    assert.equal((await s.api('POST', '/api/admin/login', { password: 'errada' })).status, 401);
    assert.ok(token);
    assert.equal((await s.api('GET', '/api/admin/appointments')).status, 401);
    assert.equal((await s.api('GET', '/api/admin/appointments', null, `${token}x`)).status, 401);
    assert.equal((await s.api('GET', '/api/admin/appointments', null, 'lixo.lixo')).status, 401);
    assert.equal((await s.api('GET', '/api/admin/appointments', null, token)).status, 200);
  });

  test('token expira', async () => {
    const { createAuth } = await import('../auth.js');
    const auth = createAuth({ secret: 'abc', password: 'p' });
    const { token: t } = auth.issue(1_000);
    assert.equal(auth.verify(t, 2_000), true);
    assert.equal(auth.verify(t, 1_000 + 13 * 60 * 60 * 1000), false);
    const other = createAuth({ secret: 'abc', password: 'nova-senha' });
    assert.equal(other.verify(t, 2_000), false); // trocar a senha invalida os tokens antigos
  });

  test('lista, filtra e altera o status dos agendamentos', async () => {
    await s.api('POST', '/api/appointments', booking({ name: 'Maria Souza', time: '14:00' }));
    const list = await s.api('GET', `/api/admin/appointments?from=${TUESDAY}&to=${TUESDAY}`, null, token);
    assert.equal(list.body.appointments.length, 1);
    const [item] = list.body.appointments;
    assert.equal(item.customerName, 'Maria Souza');

    const search = await s.api('GET', `/api/admin/appointments?from=${TUESDAY}&to=${TUESDAY}&q=maria`, null, token);
    assert.equal(search.body.appointments.length, 1);
    const none = await s.api('GET', `/api/admin/appointments?from=${TUESDAY}&to=${TUESDAY}&q=zzz`, null, token);
    assert.equal(none.body.appointments.length, 0);

    const done = await s.api('PATCH', `/api/admin/appointments/${item.id}`, { status: 'done' }, token);
    assert.equal(done.body.appointment.status, 'done');
    assert.equal((await s.api('PATCH', `/api/admin/appointments/${item.id}`, { status: 'xyz' }, token)).status, 400);

    // cancelar libera o horário; reativar só funciona se ninguém ocupou
    await s.api('PATCH', `/api/admin/appointments/${item.id}`, { status: 'cancelled' }, token);
    const taken = await s.api('POST', '/api/appointments', booking({ time: '14:00' }));
    assert.equal(taken.status, 201);
    const reactivate = await s.api('PATCH', `/api/admin/appointments/${item.id}`, { status: 'confirmed' }, token);
    assert.equal(reactivate.status, 409);
  });

  test('edita preços e serviços, e o site público reflete', async () => {
    const edit = await s.api(
      'PUT',
      '/api/admin/services/1',
      { name: 'Corte social premium', description: 'Novo', priceCents: 6000, durationMin: 30, active: true },
      token,
    );
    assert.equal(edit.status, 200);
    assert.equal(edit.body.service.priceCents, 6000);
    const pub = await s.api('GET', '/api/config');
    assert.equal(pub.body.services.find((x) => x.id === 1).priceCents, 6000);

    const created = await s.api(
      'POST',
      '/api/admin/services',
      { name: 'Pigmentação', description: '', priceCents: 12000, durationMin: 60, active: true },
      token,
    );
    assert.equal(created.status, 201);
    const removed = await s.api('DELETE', `/api/admin/services/${created.body.service.id}`, null, token);
    assert.equal(removed.body.deleted, true);

    // serviço com histórico é desativado, não apagado
    const used = await s.api('DELETE', '/api/admin/services/1', null, token);
    assert.deepEqual(used.body, { deleted: false, deactivated: true });
    const pub2 = await s.api('GET', '/api/config');
    assert.equal(pub2.body.services.some((x) => x.id === 1), false);
    // e o histórico mantém o preço da época
    const hist = await s.api('GET', `/api/admin/appointments?from=${TUESDAY}&to=${TUESDAY}`, null, token);
    assert.ok(hist.body.appointments.some((a) => a.serviceName === 'Corte social' && a.priceCents === 5000));
  });

  test('valida os dados de serviço', async () => {
    const bad = await s.api('POST', '/api/admin/services', { name: '', priceCents: -1, durationMin: 5 }, token);
    assert.equal(bad.status, 400);
  });

  test('edita barbeiros', async () => {
    const edit = await s.api(
      'PUT',
      '/api/admin/barbers/3',
      { name: 'Caio N.', role: 'Barbeiro', bio: 'Teste', specialties: 'Mullet, Buzz cut', photoUrl: '', active: true },
      token,
    );
    assert.equal(edit.status, 200);
    assert.deepEqual(edit.body.barber.specialties, ['Mullet', 'Buzz cut']);
    const badPhoto = await s.api(
      'PUT',
      '/api/admin/barbers/3',
      { name: 'Caio', specialties: [], photoUrl: 'javascript:alert(1)', active: true },
      token,
    );
    assert.equal(badPhoto.status, 400);
  });

  test('configurações: horários, feriados e contatos', async () => {
    const holiday = await s.api('PUT', '/api/admin/settings', { closedDates: [THURSDAY] }, token);
    assert.equal(holiday.status, 200);
    const view = await s.api('GET', `/api/availability?date=${THURSDAY}&serviceId=${DEGRADE}&barberId=${RAFAEL}`);
    assert.equal(view.body.reason, 'holiday');
    const book = await s.api('POST', '/api/appointments', booking({ date: THURSDAY, time: '10:00', serviceId: DEGRADE }));
    assert.equal(book.status, 409);

    const wa = await s.api('PUT', '/api/admin/settings', { whatsapp: '(11) 98888-7777', instagram: 'https://instagram.com/nobre.navalha/' }, token);
    assert.equal(wa.body.settings.whatsapp, '5511988887777');
    assert.equal(wa.body.settings.instagram, 'nobre.navalha');

    const badHours = await s.api('PUT', '/api/admin/settings', { hours: { 2: { open: '20:00', close: '09:00' } } }, token);
    assert.equal(badHours.status, 400);

    const hours = await s.api(
      'PUT',
      '/api/admin/settings',
      { hours: { 0: null, 1: null, 2: { open: '10:00', close: '12:00' }, 3: null, 4: null, 5: null, 6: null } },
      token,
    );
    assert.equal(hours.status, 200);
    const tue = await s.api('GET', `/api/availability?date=${TUESDAY}&serviceId=${DEGRADE}&barberId=${DIEGO}`);
    assert.deepEqual(
      tue.body.slots.map((x) => x.time),
      ['10:00', '10:30', '11:00'],
    );
  });
});

describe('SEO, arquivos estáticos e segurança', () => {
  let s;
  before(async () => (s = await startServer()));
  after(() => s.close());

  test('página inicial traz canonical, JSON-LD e conteúdo noscript', async () => {
    const res = await s.api('GET', '/');
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/html/);
    assert.match(res.text, /<link rel="canonical" href="http:\/\/127\.0\.0\.1:\d+\/">/);
    assert.match(res.text, /<noscript>/);
    assert.match(res.text, /Corte social — R\$ 50,00/);

    const ld = /<script type="application\/ld\+json">(.*?)<\/script>/s.exec(res.text);
    assert.ok(ld, 'JSON-LD presente');
    const data = JSON.parse(ld[1]);
    assert.equal(data['@type'], 'BarberShop');
    assert.equal(data.name, 'Nobre Navalha');
    assert.ok(data.openingHoursSpecification.some((h) => h.dayOfWeek.includes('Tuesday') && h.opens === '09:00'));
    assert.equal(data.hasOfferCatalog.itemListElement.length, 7);
  });

  test('JSON-LD não deixa dados do painel quebrarem o HTML', async () => {
    const login = await s.api('POST', '/api/admin/login', { password: 'segredo-de-teste' });
    await s.api('PUT', '/api/admin/settings', { address: 'Rua </script><img src=x onerror=alert(1)> 10' }, login.body.token);
    const res = await s.api('GET', '/');
    assert.equal(res.text.includes('</script><img'), false);
    assert.equal(res.text.includes('<img src=x'), false);
  });

  test('rotas do app caem no index e /admin não é indexado', async () => {
    const admin = await s.api('GET', '/admin');
    assert.equal(admin.status, 200);
    assert.match(admin.headers.get('x-robots-tag'), /noindex/);
    assert.match(admin.text, /ld\+json/);
  });

  test('robots.txt e sitemap.xml', async () => {
    const robots = await s.api('GET', '/robots.txt');
    assert.match(robots.text, /Disallow: \/admin/);
    assert.match(robots.text, /Sitemap: http:\/\/127\.0\.0\.1:\d+\/sitemap\.xml/);
    const map = await s.api('GET', '/sitemap.xml');
    assert.match(map.headers.get('content-type'), /xml/);
    assert.match(map.text, /<loc>http:\/\/127\.0\.0\.1:\d+\/<\/loc>/);
  });

  test('assets com hash têm cache longo e inexistentes dão 404', async () => {
    const asset = await s.api('GET', '/assets/app-abc123.js');
    assert.equal(asset.status, 200);
    assert.match(asset.headers.get('cache-control'), /immutable/);
    assert.equal((await s.api('GET', '/assets/nao-existe.js')).status, 404);
  });

  test('não permite sair da pasta pública (path traversal)', async () => {
    const get = (rawPath) =>
      new Promise((resolve, reject) => {
        const url = new URL(s.base);
        const req = http.request({ host: url.hostname, port: url.port, path: rawPath, method: 'GET' }, (res) => {
          let body = '';
          res.on('data', (c) => (body += c));
          res.on('end', () => resolve({ status: res.statusCode, body }));
        });
        req.on('error', reject);
        req.end();
      });
    for (const rawPath of [
      '/%2e%2e/%2e%2e/%2e%2e/etc/passwd.txt',
      '/..%2fserver%2fconfig.js',
      '/%2e%2e%2fpackage.json',
      '/assets/..%2f..%2fserver%2fdb.js',
      '/..%5cserver%5cdb.js',
    ]) {
      const res = await get(rawPath);
      assert.equal(res.status, 404, rawPath);
      assert.equal(/openDb|DatabaseSync|"name": "nobre-navalha"/.test(res.body), false, rawPath);
    }
  });

  test('envia cabeçalhos de segurança', async () => {
    const res = await s.api('GET', '/');
    assert.match(res.headers.get('content-security-policy'), /default-src 'self'/);
    assert.equal(res.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(res.headers.get('x-frame-options'), 'DENY');
    assert.match(res.headers.get('content-security-policy'), /frame-ancestors 'none'/);
  });
});

describe('limite de requisições', () => {
  test('bloqueia excesso de tentativas de reserva e de login', async () => {
    const s = await startServer({
      limits: {
        ...wideLimits(),
        booking: new RateLimiter({ windowMs: 60_000, max: 2 }),
        login: new RateLimiter({ windowMs: 60_000, max: 2 }),
      },
    });
    try {
      const results = [];
      for (let i = 0; i < 3; i += 1) {
        results.push(await s.api('POST', '/api/appointments', booking({ time: `1${i}:00`, barberId: CAIO })));
      }
      assert.deepEqual(results.map((r) => r.status), [201, 201, 429]);
      assert.ok(Number(results[2].headers.get('retry-after')) > 0);

      const logins = [];
      for (let i = 0; i < 3; i += 1) logins.push((await s.api('POST', '/api/admin/login', { password: 'x' })).status);
      assert.deepEqual(logins, [401, 401, 429]);
    } finally {
      await s.close();
    }
  });
});

describe('painel desativado sem senha', () => {
  test('em produção sem ADMIN_PASSWORD o login responde 503', async () => {
    const dist = fs.mkdtempSync(path.join(os.tmpdir(), 'nn-dist-'));
    const config = { ...loadConfig({ NODE_ENV: 'production', LOG_REQUESTS: '0' }), distDir: dist };
    assert.equal(config.adminPassword, '');
    const db = openDb(':memory:');
    const server = createApp({ config, db, limits: wideLimits() });
    await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    try {
      const res = await fetch(`http://127.0.0.1:${server.address().port}/api/admin/login`, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ password: '' }),
      });
      assert.equal(res.status, 503);
    } finally {
      server.closeAllConnections();
      await new Promise((resolve) => server.close(resolve));
      db.close();
    }
  });
});
