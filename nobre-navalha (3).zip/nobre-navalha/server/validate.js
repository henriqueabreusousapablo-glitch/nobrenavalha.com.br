import { ApiError } from './errors.js';

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const TIME_RE = /^([01]\d|2[0-3]):([0-5]\d)$/;
const NAME_RE = /^\p{L}[\p{L}\p{M}'’ .-]{1,79}$/u;

export function isValidDate(value) {
  if (typeof value !== 'string' || !DATE_RE.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
}

export function isValidTime(value) {
  return typeof value === 'string' && TIME_RE.test(value);
}

export function toMin(time) {
  const [h, m] = time.split(':').map(Number);
  return h * 60 + m;
}

export function fromMin(total) {
  const h = String(Math.floor(total / 60)).padStart(2, '0');
  const m = String(total % 60).padStart(2, '0');
  return `${h}:${m}`;
}

/** 0 = domingo ... 6 = sábado, calculado sem depender do fuso do servidor. */
export function weekdayOf(date) {
  const [y, m, d] = date.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function addDays(date, days) {
  const [y, m, d] = date.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return dt.toISOString().slice(0, 10);
}

export function cleanName(value) {
  if (typeof value !== 'string') return null;
  const name = value.normalize('NFC').replace(/\s+/g, ' ').trim();
  return NAME_RE.test(name) ? name : null;
}

/**
 * Aceita (11) 91234-5678, +55 11 91234-5678, 1132345678...
 * Devolve só os dígitos nacionais (10 ou 11) ou null se inválido.
 */
export function normalizePhone(value) {
  if (typeof value !== 'string' && typeof value !== 'number') return null;
  let digits = String(value).replace(/\D/g, '');
  if ((digits.length === 12 || digits.length === 13) && digits.startsWith('55')) digits = digits.slice(2);
  if (digits.length !== 10 && digits.length !== 11) return null;
  if (!/^[1-9][1-9]/.test(digits)) return null; // DDD válido: 11 a 99
  if (digits.length === 11 && digits[2] !== '9') return null; // celular começa com 9
  if (/^(\d)\1+$/.test(digits)) return null; // 11111111111
  return digits;
}

export function normalizeCode(value) {
  if (typeof value !== 'string') return null;
  const code = value.toUpperCase().replace(/[^A-Z0-9]/g, '');
  return code.length === 6 ? code : null;
}

export function requireString(value, field, label, { min = 1, max = 200, allowEmpty = false } = {}) {
  if (typeof value !== 'string') {
    if (allowEmpty && (value === undefined || value === null)) return '';
    throw new ApiError(400, 'VALIDATION', `${label} é obrigatório.`, { [field]: `${label} é obrigatório.` });
  }
  const text = value.normalize('NFC').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim();
  if (!allowEmpty && text.length < min) {
    throw new ApiError(400, 'VALIDATION', `${label} é obrigatório.`, { [field]: `${label} é obrigatório.` });
  }
  if (text.length > max) {
    throw new ApiError(400, 'VALIDATION', `${label} deve ter até ${max} caracteres.`, {
      [field]: `Use até ${max} caracteres.`,
    });
  }
  return text;
}

export function requireInt(value, field, label, { min = 0, max = 1e9 } = {}) {
  const n = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
  if (!Number.isInteger(n) || n < min || n > max) {
    throw new ApiError(400, 'VALIDATION', `${label} deve ser um número inteiro entre ${min} e ${max}.`, {
      [field]: `Informe um valor entre ${min} e ${max}.`,
    });
  }
  return n;
}
