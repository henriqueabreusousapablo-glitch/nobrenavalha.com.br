import http from 'node:http';
import { setTimeout as sleep } from 'node:timers/promises';
import { ApiError } from './errors.js';
import { createAuth, passwordMatches } from './auth.js';
import { getOrCreateSecret } from './db.js';
import {
  RateLimiter,
  Router,
  applySecurityHeaders,
  clientIp,
  readJson,
  readStaticFile,
  sendBuffer,
  sendJson,
  sendStatic,
  sendText,
} from './http.js';
import {
  cancelAppointmentByCustomer,
  createAppointment,
  getAvailability,
  listAppointments,
  loadSettings,
  lookupAppointment,
  parseSettingsInput,
  saveSettings,
  setAppointmentStatus,
  shopNow,
} from './scheduling.js';
import {
  createBarber,
  createService,
  deleteBarber,
  deleteService,
  listBarbers,
  listServices,
  updateBarber,
  updateService,
} from './catalog.js';
import { createSeo } from './seo.js';
import { addDays, isValidDate, requireInt } from './validate.js';

const STATUSES = ['confirmed', 'done', 'cancelled', 'no_show'];

const defaultLimits = () => ({
  api: new RateLimiter({ windowMs: 60_000, max: 240 }),
  booking: new RateLimiter({ windowMs: 60 * 60_000, max: 12 }),
  lookup: new RateLimiter({ windowMs: 15 * 60_000, max: 20 }),
  login: new RateLimiter({ windowMs: 15 * 60_000, max: 8 }),
});

/**
 * Monta o servidor HTTP (sem iniciar a escuta).
 * `clock` e `limits` podem ser trocados nos testes.
 */
export function createApp({ config, db, clock, limits: limitOverrides = {} }) {
  const limits = { ...defaultLimits(), ...limitOverrides };
  const now = clock || (() => shopNow(config.timezone));
  const auth = createAuth({ secret: getOrCreateSecret(db), password: config.adminPassword });
  const seo = createSeo(config);
  const router = new Router();

  const serializeSettings = (s) => ({
    businessName: s.businessName,
    tagline: s.tagline,
    phone: s.phone,
    whatsapp: s.whatsapp,
    address: s.address,
    instagram: s.instagram,
    hours: s.hours,
    closedDates: s.closedDates,
    intervalMin: s.intervalMin,
    maxDaysAhead: s.maxDaysAhead,
    minNoticeMin: s.minNoticeMin,
  });

  /* ------------------------------ público ------------------------------ */

  router.add('GET', '/api/health', () => ({ ok: true }));

  router.add('GET', '/api/config', (ctx) => {
    ctx.res.setHeader('Cache-Control', 'no-cache');
    return {
      business: serializeSettings(loadSettings(db)),
      timezone: config.timezone,
      now: ctx.now,
      services: listServices(db, { onlyActive: true }),
      barbers: listBarbers(db, { onlyActive: true }),
    };
  });

  router.add('GET', '/api/availability', (ctx) => {
    ctx.res.setHeader('Cache-Control', 'no-store');
    return getAvailability(db, ctx.query, ctx.now);
  });

  router.add(
    'POST',
    '/api/appointments',
    async (ctx) => {
      const body = await ctx.body();
      if (body.website) throw new ApiError(400, 'INVALID', 'Requisição inválida.'); // campo isca para robôs
      const appointment = createAppointment(db, body, ctx.now);
      return ctx.json(201, { appointment });
    },
    { limit: 'booking' },
  );

  router.add(
    'POST',
    '/api/appointments/lookup',
    async (ctx) => ({ appointment: lookupAppointment(db, await ctx.body(), ctx.now) }),
    { limit: 'lookup' },
  );

  router.add(
    'POST',
    '/api/appointments/cancel',
    async (ctx) => ({ appointment: cancelAppointmentByCustomer(db, await ctx.body(), ctx.now) }),
    { limit: 'lookup' },
  );

  /* ------------------------------- painel ------------------------------- */

  router.add(
    'POST',
    '/api/admin/login',
    async (ctx) => {
      if (!config.adminPassword) {
        throw new ApiError(503, 'ADMIN_DISABLED', 'O painel está desativado. Defina ADMIN_PASSWORD no servidor.');
      }
      const { password } = await ctx.body();
      if (!passwordMatches(password, config.adminPassword)) {
        await sleep(400);
        throw new ApiError(401, 'INVALID_CREDENTIALS', 'Senha incorreta.');
      }
      return auth.issue();
    },
    { limit: 'login' },
  );

  const admin = { admin: true };

  router.add('GET', '/api/admin/me', () => ({ ok: true }), admin);

  router.add(
    'GET',
    '/api/admin/appointments',
    (ctx) => {
      const today = ctx.now.date;
      const from = ctx.query.from ?? today;
      const to = ctx.query.to ?? addDays(today, 90);
      if (!isValidDate(from) || !isValidDate(to)) {
        throw new ApiError(400, 'VALIDATION', 'Datas inválidas.');
      }
      const status = STATUSES.includes(ctx.query.status) ? ctx.query.status : undefined;
      return { appointments: listAppointments(db, { from, to, status, q: String(ctx.query.q || '').slice(0, 60) }) };
    },
    admin,
  );

  router.add(
    'PATCH',
    '/api/admin/appointments/:id',
    async (ctx) => {
      const { status } = await ctx.body();
      if (!STATUSES.includes(status)) throw new ApiError(400, 'VALIDATION', 'Status inválido.');
      return { appointment: setAppointmentStatus(db, requireInt(ctx.params.id, 'id', 'ID', { min: 1 }), status) };
    },
    admin,
  );

  router.add('GET', '/api/admin/services', () => ({ services: listServices(db) }), admin);
  router.add('POST', '/api/admin/services', async (ctx) => ctx.json(201, { service: createService(db, await ctx.body()) }), admin);
  router.add(
    'PUT',
    '/api/admin/services/:id',
    async (ctx) => ({ service: updateService(db, Number(ctx.params.id), await ctx.body()) }),
    admin,
  );
  router.add('DELETE', '/api/admin/services/:id', (ctx) => deleteService(db, Number(ctx.params.id)), admin);

  router.add('GET', '/api/admin/barbers', () => ({ barbers: listBarbers(db) }), admin);
  router.add('POST', '/api/admin/barbers', async (ctx) => ctx.json(201, { barber: createBarber(db, await ctx.body()) }), admin);
  router.add(
    'PUT',
    '/api/admin/barbers/:id',
    async (ctx) => ({ barber: updateBarber(db, Number(ctx.params.id), await ctx.body()) }),
    admin,
  );
  router.add('DELETE', '/api/admin/barbers/:id', (ctx) => deleteBarber(db, Number(ctx.params.id)), admin);

  router.add('GET', '/api/admin/settings', () => ({ settings: serializeSettings(loadSettings(db)) }), admin);
  router.add(
    'PUT',
    '/api/admin/settings',
    async (ctx) => {
      saveSettings(db, parseSettingsInput(await ctx.body()));
      return { settings: serializeSettings(loadSettings(db)) };
    },
    admin,
  );

  /* ------------------------------- API ------------------------------- */

  async function handleApi(req, res, url, pathname, ip) {
    const found = router.match(req.method, pathname);
    if (!found.route) {
      if (found.allowed.length) {
        res.setHeader('Allow', found.allowed.join(', '));
        throw new ApiError(405, 'METHOD_NOT_ALLOWED', 'Método não permitido.');
      }
      throw new ApiError(404, 'NOT_FOUND', 'Recurso não encontrado.');
    }
    const { route, params } = found;

    const rate = limits.api.take(ip);
    if (!rate.ok) {
      res.setHeader('Retry-After', rate.retryAfter);
      throw new ApiError(429, 'RATE_LIMITED', 'Muitas requisições. Aguarde um instante.');
    }
    if (route.options.limit) {
      const hit = limits[route.options.limit].take(ip);
      if (!hit.ok) {
        res.setHeader('Retry-After', hit.retryAfter);
        throw new ApiError(429, 'RATE_LIMITED', 'Muitas tentativas. Tente novamente em alguns minutos.');
      }
    }
    if (route.options.admin) {
      const header = String(req.headers.authorization || '');
      if (!header.startsWith('Bearer ') || !auth.verify(header.slice(7))) {
        throw new ApiError(401, 'UNAUTHORIZED', 'Sessão expirada. Entre novamente.');
      }
    }

    let cachedBody;
    const ctx = {
      req,
      res,
      params,
      ip,
      now: now(),
      query: Object.fromEntries(url.searchParams),
      body: async () => (cachedBody ??= await readJson(req)),
      json: (status, data) => sendJson(req, res, status, data),
    };
    const result = await route.handler(ctx);
    if (res.writableEnded) return;
    if (result === undefined) {
      res.writeHead(204);
      res.end();
      return;
    }
    res.setHeader('Cache-Control', res.getHeader('Cache-Control') || 'no-store');
    sendJson(req, res, 200, result);
  }

  /* ------------------------ arquivos e páginas ------------------------ */

  async function sendIndex(req, res, status = 200) {
    let html;
    try {
      html = await seo.renderIndex(req, {
        settings: loadSettings(db),
        services: listServices(db, { onlyActive: true }),
      });
    } catch (err) {
      if (err.code === 'ENOENT') {
        return sendText(req, res, 503, 'Site ainda não compilado. Execute "npm run build" e reinicie.');
      }
      throw err;
    }
    sendBuffer(req, res, status, Buffer.from(html), { type: 'text/html; charset=utf-8', cache: 'no-cache' });
  }

  async function handleStatic(req, res, pathname) {
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.setHeader('Allow', 'GET, HEAD');
      return sendText(req, res, 405, 'Método não permitido.');
    }
    if (pathname === '/robots.txt') return sendText(req, res, 200, seo.robots(req), 'text/plain; charset=utf-8', 'no-cache');
    if (pathname === '/sitemap.xml') {
      return sendText(req, res, 200, seo.sitemap(req), 'application/xml; charset=utf-8', 'no-cache');
    }

    if (pathname.split('/').includes('..') || pathname.includes('\\')) return sendText(req, res, 404, 'Não encontrado.');

    const isAsset = /\.[a-z0-9]{1,8}$/i.test(pathname);
    if (!isAsset) {
      if (pathname.startsWith('/admin')) res.setHeader('X-Robots-Tag', 'noindex, nofollow');
      return sendIndex(req, res);
    }
    if (pathname === '/index.html') return sendIndex(req, res);

    const file = await readStaticFile(config.distDir, pathname);
    if (!file) return sendText(req, res, 404, 'Arquivo não encontrado.');
    return sendStatic(req, res, file, pathname);
  }

  /* ------------------------- servidor principal ------------------------- */

  function sendError(req, res, err) {
    if (res.headersSent) {
      res.destroy();
      return;
    }
    if (err instanceof ApiError) {
      sendJson(req, res, err.status, { error: { code: err.code, message: err.message, fields: err.fields } });
      return;
    }
    console.error('[erro]', err);
    sendJson(req, res, 500, { error: { code: 'INTERNAL', message: 'Algo deu errado do nosso lado. Tente novamente.' } });
  }

  const server = http.createServer(async (req, res) => {
    const started = process.hrtime.bigint();
    if (config.logRequests) {
      res.on('finish', () => {
        const ms = Number(process.hrtime.bigint() - started) / 1e6;
        console.log(`${req.method} ${req.url.split('?')[0]} ${res.statusCode} ${ms.toFixed(1)}ms`);
      });
    }
    try {
      const url = new URL(req.url, 'http://localhost');
      let pathname;
      try {
        pathname = decodeURIComponent(url.pathname);
      } catch {
        throw new ApiError(400, 'BAD_REQUEST', 'Endereço inválido.');
      }
      applySecurityHeaders(req, res, { isProd: config.isProd, trustProxy: config.trustProxyHops > 0 });
      if (pathname.startsWith('/api/') || pathname === '/api') {
        await handleApi(req, res, url, pathname, clientIp(req, config.trustProxyHops));
      } else {
        await handleStatic(req, res, pathname);
      }
    } catch (err) {
      sendError(req, res, err);
    }
  });
  server.requestTimeout = 30_000;
  server.headersTimeout = 15_000;
  server.keepAliveTimeout = 65_000;

  return server;
}
