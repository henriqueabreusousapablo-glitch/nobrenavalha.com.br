import fs from 'node:fs/promises';
import path from 'node:path';
import zlib from 'node:zlib';
import { ApiError } from './errors.js';

export const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

const COMPRESSIBLE = /^(text\/|application\/(json|xml|manifest\+json)|image\/svg\+xml)/;

/* ------------------------------------------------------------------ */
/* Limite de requisições (em memória, por IP)                          */
/* ------------------------------------------------------------------ */

export class RateLimiter {
  constructor({ windowMs, max }) {
    this.windowMs = windowMs;
    this.max = max;
    this.hits = new Map();
  }

  take(key, now = Date.now()) {
    if (this.hits.size > 5000) this.sweep(now);
    const entry = this.hits.get(key);
    if (!entry || entry.reset <= now) {
      this.hits.set(key, { count: 1, reset: now + this.windowMs });
      return { ok: true, retryAfter: 0 };
    }
    entry.count += 1;
    return entry.count > this.max
      ? { ok: false, retryAfter: Math.max(1, Math.ceil((entry.reset - now) / 1000)) }
      : { ok: true, retryAfter: 0 };
  }

  sweep(now = Date.now()) {
    for (const [key, entry] of this.hits) if (entry.reset <= now) this.hits.delete(key);
  }
}

/** IP do cliente. Só confia em X-Forwarded-For quando há proxies confiáveis configurados. */
export function clientIp(req, hops) {
  const direct = req.socket.remoteAddress || 'unknown';
  if (!hops) return direct;
  const forwarded = String(req.headers['x-forwarded-for'] || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  if (!forwarded.length) return direct;
  return forwarded[Math.max(0, forwarded.length - hops)];
}

/* ------------------------------------------------------------------ */
/* Cabeçalhos de segurança                                             */
/* ------------------------------------------------------------------ */

const CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com",
  "img-src 'self' data: https:",
  'frame-src https://www.google.com https://maps.google.com',
  "connect-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
].join('; ');

export function applySecurityHeaders(req, res, { isProd, trustProxy }) {
  res.setHeader('Content-Security-Policy', CSP);
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=(), payment=()');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader('X-Frame-Options', 'DENY');
  const https = req.socket.encrypted || (trustProxy && req.headers['x-forwarded-proto'] === 'https');
  if (isProd && https) res.setHeader('Strict-Transport-Security', 'max-age=15552000; includeSubDomains');
}

/* ------------------------------------------------------------------ */
/* Respostas                                                           */
/* ------------------------------------------------------------------ */

const compressedCache = new Map();

function pickEncoding(req) {
  const accept = String(req.headers['accept-encoding'] || '');
  if (/\bbr\b/.test(accept)) return 'br';
  if (/\bgzip\b/.test(accept)) return 'gzip';
  return null;
}

/**
 * Envia um buffer, comprimindo quando vale a pena.
 * `cacheKey` permite guardar a versão comprimida (arquivos estáticos).
 */
export function sendBuffer(req, res, status, buffer, { type, cache = 'no-store', etag, cacheKey } = {}) {
  const headers = { 'Content-Type': type, 'Cache-Control': cache, Vary: 'Accept-Encoding' };
  if (etag) headers.ETag = etag;

  if (etag && req.headers['if-none-match'] === etag) {
    res.writeHead(304, headers);
    res.end();
    return;
  }

  let body = buffer;
  const encoding = COMPRESSIBLE.test(type) && buffer.length > 1024 ? pickEncoding(req) : null;
  if (encoding) {
    const key = cacheKey ? `${cacheKey}:${encoding}` : null;
    let packed = key ? compressedCache.get(key) : null;
    if (!packed) {
      packed =
        encoding === 'br'
          ? zlib.brotliCompressSync(buffer, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: key ? 6 : 4 } })
          : zlib.gzipSync(buffer, { level: key ? 9 : 6 });
      if (key) {
        if (compressedCache.size > 200) compressedCache.clear();
        compressedCache.set(key, packed);
      }
    }
    body = packed;
    headers['Content-Encoding'] = encoding;
  }

  headers['Content-Length'] = body.length;
  res.writeHead(status, headers);
  res.end(req.method === 'HEAD' ? undefined : body);
}

export function sendJson(req, res, status, data, extraHeaders = {}) {
  const buffer = Buffer.from(JSON.stringify(data));
  const type = 'application/json; charset=utf-8';
  if (Object.keys(extraHeaders).length) for (const [k, v] of Object.entries(extraHeaders)) res.setHeader(k, v);
  sendBuffer(req, res, status, buffer, { type });
}

export function sendText(req, res, status, text, type = 'text/plain; charset=utf-8', cache = 'no-store') {
  sendBuffer(req, res, status, Buffer.from(text), { type, cache });
}

export async function readJson(req, limit = 32 * 1024) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > limit) throw new ApiError(413, 'PAYLOAD_TOO_LARGE', 'Requisição grande demais.');
    chunks.push(chunk);
  }
  if (!size) return {};
  let value;
  try {
    value = JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    throw new ApiError(400, 'INVALID_JSON', 'Corpo da requisição inválido.');
  }
  if (value === null || typeof value !== 'object' || Array.isArray(value)) {
    throw new ApiError(400, 'INVALID_JSON', 'Corpo da requisição inválido.');
  }
  return value;
}

/* ------------------------------------------------------------------ */
/* Roteador                                                            */
/* ------------------------------------------------------------------ */

export class Router {
  #routes = [];

  add(method, pattern, handler, options = {}) {
    const keys = [];
    const source = pattern.replace(/\/:([A-Za-z]+)/g, (_, key) => {
      keys.push(key);
      return '/([^/]+)';
    });
    this.#routes.push({ method, regex: new RegExp(`^${source}/?$`), keys, handler, options });
  }

  match(method, pathname) {
    const allowed = [];
    for (const route of this.#routes) {
      const m = route.regex.exec(pathname);
      if (!m) continue;
      if (route.method !== method) {
        allowed.push(route.method);
        continue;
      }
      const params = {};
      route.keys.forEach((key, i) => {
        params[key] = decodeURIComponent(m[i + 1]);
      });
      return { route, params };
    }
    return { allowed };
  }
}

/* ------------------------------------------------------------------ */
/* Arquivos estáticos                                                  */
/* ------------------------------------------------------------------ */

/** Resolve o caminho dentro de `root` ou devolve null se tentar sair dele. */
export function safeResolve(root, pathname) {
  if (pathname.includes('\0')) return null;
  const full = path.join(root, path.normalize(pathname));
  return full === root || full.startsWith(root + path.sep) ? full : null;
}

export async function readStaticFile(root, pathname) {
  const full = safeResolve(root, pathname);
  if (!full) return null;
  try {
    const stat = await fs.stat(full);
    if (!stat.isFile()) return null;
    return { full, stat, buffer: await fs.readFile(full) };
  } catch {
    return null;
  }
}

export function sendStatic(req, res, file, pathname) {
  const ext = path.extname(file.full).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  const hashed = pathname.startsWith('/assets/');
  const cache = hashed
    ? 'public, max-age=31536000, immutable'
    : ext === '.html' || ext === '.xml' || ext === '.txt'
      ? 'no-cache'
      : 'public, max-age=86400';
  const etag = `W/"${file.stat.size}-${Math.floor(file.stat.mtimeMs)}"`;
  sendBuffer(req, res, 200, file.buffer, { type, cache, etag, cacheKey: `${file.full}:${etag}` });
}
