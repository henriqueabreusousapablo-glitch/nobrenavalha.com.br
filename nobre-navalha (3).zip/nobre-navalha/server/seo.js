import fs from 'node:fs/promises';
import path from 'node:path';

const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const DAY_LABELS = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];

export const escapeHtml = (value) =>
  String(value).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

/** JSON seguro para ficar dentro de <script>: impede fechar a tag por engano. */
const safeJson = (data) =>
  JSON.stringify(data)
    .replace(/</g, '\\u003c')
    .replace(/\u2028/g, '\\u2028')
    .replace(/\u2029/g, '\\u2029');

const money = (cents) => `R$ ${(cents / 100).toFixed(2).replace('.', ',')}`;

export function baseUrl(req, config) {
  if (config.siteUrl) return config.siteUrl;
  const trust = config.trustProxyHops > 0;
  const proto = req.socket.encrypted || (trust && req.headers['x-forwarded-proto'] === 'https') ? 'https' : 'http';
  const rawHost = String((trust && req.headers['x-forwarded-host']) || req.headers.host || 'localhost');
  const host = /^[a-z0-9.-]+(:\d{1,5})?$/i.test(rawHost) ? rawHost : 'localhost';
  return `${proto}://${host}`;
}

/** Agrupa dias com o mesmo horário: "Ter–Sex 09:00–20:00". */
function hoursGroups(hours) {
  const groups = new Map();
  for (let day = 0; day <= 6; day += 1) {
    const h = hours[day];
    if (!h) continue;
    const key = `${h.open}|${h.close}`;
    if (!groups.has(key)) groups.set(key, { open: h.open, close: h.close, days: [] });
    groups.get(key).days.push(day);
  }
  return [...groups.values()];
}

export function buildJsonLd({ settings, services, url }) {
  const prices = services.map((s) => s.priceCents / 100);
  const data = {
    '@context': 'https://schema.org',
    '@type': 'BarberShop',
    name: settings.businessName,
    url,
    description: `${settings.businessName}: barbearia com cortes masculinos, barba na navalha e agendamento online.`,
    telephone: `+${settings.whatsapp}`,
    address: { '@type': 'PostalAddress', streetAddress: settings.address, addressCountry: 'BR' },
    openingHoursSpecification: hoursGroups(settings.hours).map((g) => ({
      '@type': 'OpeningHoursSpecification',
      dayOfWeek: g.days.map((d) => DAY_NAMES[d]),
      opens: g.open,
      closes: g.close,
    })),
    hasOfferCatalog: {
      '@type': 'OfferCatalog',
      name: 'Serviços',
      itemListElement: services.map((s) => ({
        '@type': 'Offer',
        priceCurrency: 'BRL',
        price: (s.priceCents / 100).toFixed(2),
        itemOffered: { '@type': 'Service', name: s.name, description: s.description },
      })),
    },
    potentialAction: { '@type': 'ReserveAction', target: `${url}/#agendar`, name: 'Agendar horário' },
  };
  if (prices.length) data.priceRange = `R$${Math.min(...prices).toFixed(0)}–R$${Math.max(...prices).toFixed(0)}`;
  if (settings.instagram) data.sameAs = [`https://www.instagram.com/${settings.instagram}`];
  return data;
}

function buildHead({ settings, services, url }) {
  return [
    `<link rel="canonical" href="${escapeHtml(url)}/">`,
    `<meta property="og:url" content="${escapeHtml(url)}/">`,
    `<meta property="og:image" content="${escapeHtml(url)}/og-image.png">`,
    `<meta name="twitter:image" content="${escapeHtml(url)}/og-image.png">`,
    `<script type="application/ld+json">${safeJson(buildJsonLd({ settings, services, url }))}</script>`,
  ].join('\n    ');
}

/** Conteúdo para quem não executa JavaScript (e para robôs simples). */
function buildNoscript({ settings, services }) {
  const hours = hoursGroups(settings.hours)
    .map((g) => {
      const first = DAY_LABELS[g.days[0]];
      const last = DAY_LABELS[g.days[g.days.length - 1]];
      const label = g.days.length > 1 ? `${first} a ${last}` : first;
      return `<li>${escapeHtml(label)}: ${g.open} às ${g.close}</li>`;
    })
    .join('');
  const list = services
    .map((s) => `<li>${escapeHtml(s.name)} — ${money(s.priceCents)} (${s.durationMin} min)</li>`)
    .join('');
  return `<noscript>
      <main style="max-width:42rem;margin:0 auto;padding:2rem 1rem;font-family:system-ui,sans-serif;line-height:1.6">
        <h1>${escapeHtml(settings.businessName)} — ${escapeHtml(settings.tagline)}</h1>
        <p>Para agendar online é preciso ativar o JavaScript. Se preferir, chame no
        <a href="https://wa.me/${escapeHtml(settings.whatsapp)}">WhatsApp ${escapeHtml(settings.phone)}</a>.</p>
        <h2>Serviços e preços</h2><ul>${list}</ul>
        <h2>Horário de funcionamento</h2><ul>${hours}</ul>
        <h2>Endereço</h2><p>${escapeHtml(settings.address)}</p>
      </main>
    </noscript>`;
}

export function createSeo(config) {
  const file = path.join(config.distDir, 'index.html');
  let cache = { mtime: 0, html: '' };

  async function template() {
    const stat = await fs.stat(file);
    if (stat.mtimeMs !== cache.mtime) cache = { mtime: stat.mtimeMs, html: await fs.readFile(file, 'utf8') };
    return cache.html;
  }

  return {
    /** Devolve o index.html com canonical, JSON-LD e conteúdo noscript preenchidos. */
    async renderIndex(req, { settings, services }) {
      const html = await template();
      const url = baseUrl(req, config);
      return html
        .replace('<!--@seo-->', () => buildHead({ settings, services, url }))
        .replace('<!--@noscript-->', () => buildNoscript({ settings, services }));
    },

    robots(req) {
      return ['User-agent: *', 'Allow: /', 'Disallow: /admin', 'Disallow: /api/', '', `Sitemap: ${baseUrl(req, config)}/sitemap.xml`, ''].join('\n');
    },

    sitemap(req) {
      const url = baseUrl(req, config);
      const lastmod = new Date().toISOString().slice(0, 10);
      return `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url><loc>${escapeHtml(url)}/</loc><lastmod>${lastmod}</lastmod><changefreq>weekly</changefreq><priority>1.0</priority></url>
</urlset>
`;
    },
  };
}
