import { createElement, useEffect, useRef } from 'react';

let observer;

function getObserver() {
  if (observer || typeof IntersectionObserver === 'undefined') return observer;
  observer = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          observer.unobserve(entry.target);
        }
      }
    },
    { threshold: 0.12, rootMargin: '0px 0px -8% 0px' },
  );
  return observer;
}

/**
 * Anima o elemento quando ele entra na tela.
 * variant: rise (sobe e aparece) | slice (corte de navalha, revela da esquerda) | scale | fade | line
 */
export function Reveal({ as = 'div', variant = 'rise', delay = 0, className = '', style, children, ...rest }) {
  const ref = useRef(null);

  useEffect(() => {
    const el = ref.current;
    const io = getObserver();
    if (!el) return undefined;
    if (!io) {
      el.classList.add('is-in');
      return undefined;
    }
    io.observe(el);
    return () => io.unobserve(el);
  }, []);

  return createElement(
    as,
    {
      ref,
      'data-reveal': variant,
      className,
      style: delay ? { ...style, '--d': `${delay}ms` } : style,
      ...rest,
    },
    children,
  );
}
