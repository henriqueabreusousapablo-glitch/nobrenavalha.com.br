import { createContext, useContext } from 'react';

export const SiteContext = createContext(null);

/** Dados públicos do site: { business, services, barbers, timezone, now } */
export const useSite = () => useContext(SiteContext);

export const DEFAULT_BUSINESS = {
  businessName: 'Nobre Navalha',
  tagline: 'Seu estilo começa no corte certo',
  phone: '',
  whatsapp: '',
  address: '',
  instagram: '',
  hours: {},
  closedDates: [],
  intervalMin: 30,
  maxDaysAhead: 30,
  minNoticeMin: 60,
};
