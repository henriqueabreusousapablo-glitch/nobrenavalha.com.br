import { Suspense, lazy, useCallback, useEffect, useMemo, useState } from 'react';
import { SiteContext } from './site-context.js';
import { api } from './lib/api.js';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import Services from './components/Services.jsx';
import Cuts from './components/Cuts.jsx';
import Barbers from './components/Barbers.jsx';
import HairLab from './components/HairScience/HairLab.jsx';
import Reviews from './components/Reviews.jsx';
import Booking from './components/Booking/Booking.jsx';
import Location from './components/Location.jsx';
import Footer from './components/Footer.jsx';
import FloatingActions from './components/FloatingActions.jsx';
import ScrollProgress from './components/ScrollProgress.jsx';

const Admin = lazy(() => import('./components/Admin/Admin.jsx'));

/** Dados embutidos no HTML pelo servidor (evita uma ida extra à API no primeiro carregamento). */
function readBoot() {
  try {
    const el = document.getElementById('boot-data');
    return el ? JSON.parse(el.textContent) : null;
  } catch {
    return null;
  }
}

function useSiteData() {
  const [data, setData] = useState(readBoot);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    try {
      setData(await api('/api/config'));
      setError(null);
    } catch (err) {
      setError(err);
    }
  }, []);

  useEffect(() => {
    if (!data) load();
    // Atualiza preços e horários ao voltar para a aba, sem exigir recarregar.
    const onVisible = () => document.visibilityState === 'visible' && load();
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [load]);

  return { data, error, reload: load };
}

function Site() {
  const { data, error, reload } = useSiteData();
  const [intent, setIntent] = useState({ serviceId: null, barberId: null, nonce: 0 });

  const startBooking = useCallback((partial = {}) => {
    setIntent((prev) => ({ serviceId: null, barberId: null, ...partial, nonce: prev.nonce + 1 }));
    document.getElementById('agendar')?.scrollIntoView({
      behavior: matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth',
      block: 'start',
    });
  }, []);

  const value = useMemo(() => ({ ...(data || {}), startBooking, reload }), [data, startBooking, reload]);

  if (!data) {
    return (
      <div className="boot">
        <p className="boot__brand">Nobre Navalha</p>
        {error ? (
          <>
            <p className="boot__msg">{error.message}</p>
            <button className="btn btn--primary" onClick={reload}>
              <span>Tentar de novo</span>
            </button>
          </>
        ) : (
          <span className="boot__bar" aria-label="Carregando" role="status" />
        )}
      </div>
    );
  }

  return (
    <SiteContext.Provider value={value}>
      <ScrollProgress />
      <a className="skip" href="#conteudo">
        Ir para o conteúdo
      </a>
      <Header />
      <main id="conteudo">
        <Hero />
        <Services />
        <Cuts />
        <Barbers />
        <HairLab />
        <Reviews />
        <Booking intent={intent} />
        <Location />
      </main>
      <Footer />
      <FloatingActions />
    </SiteContext.Provider>
  );
}

export default function App() {
  const isAdmin = location.pathname.replace(/\/+$/, '') === '/admin';
  useEffect(() => {
    if (isAdmin) document.title = 'Painel | Nobre Navalha';
  }, [isAdmin]);

  if (isAdmin) {
    return (
      <Suspense fallback={<div className="boot"><span className="boot__bar" role="status" aria-label="Carregando" /></div>}>
        <Admin />
      </Suspense>
    );
  }
  return <Site />;
}
