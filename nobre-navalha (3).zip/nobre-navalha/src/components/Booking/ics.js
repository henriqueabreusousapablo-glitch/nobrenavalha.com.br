const pad = (n) => String(n).padStart(2, '0');
const stamp = (date, time) => `${date.replaceAll('-', '')}T${time.replace(':', '')}00`;
const esc = (s) => String(s).replace(/([,;\\])/g, '\\$1').replace(/\n/g, '\\n');

/** Gera um arquivo .ics (calendário) com lembrete 1 hora antes. */
export function buildIcs({ appointment, business, timezone }) {
  const a = appointment;
  const now = new Date();
  const dtstamp = `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}T${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}00Z`;
  return [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//Nobre Navalha//Agendamento//PT-BR',
    'CALSCALE:GREGORIAN',
    'BEGIN:VEVENT',
    `UID:${a.code}@nobrenavalha`,
    `DTSTAMP:${dtstamp}`,
    `DTSTART;TZID=${timezone}:${stamp(a.date, a.time)}`,
    `DTEND;TZID=${timezone}:${stamp(a.date, a.endTime)}`,
    `SUMMARY:${esc(`${a.serviceName} - ${business.businessName}`)}`,
    `DESCRIPTION:${esc(`Barbeiro: ${a.barberName}\nCódigo: ${a.code}`)}`,
    `LOCATION:${esc(business.address)}`,
    'BEGIN:VALARM',
    'TRIGGER:-PT1H',
    'ACTION:DISPLAY',
    'DESCRIPTION:Seu horário na barbearia é daqui a pouco',
    'END:VALARM',
    'END:VEVENT',
    'END:VCALENDAR',
  ].join('\r\n');
}

export function downloadIcs(args) {
  const blob = new Blob([buildIcs(args)], { type: 'text/calendar;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = 'nobre-navalha-agendamento.ics';
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
