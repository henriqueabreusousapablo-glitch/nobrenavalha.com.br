import { useState } from 'react';
import { api } from '../../lib/api.js';
import { brl, longDate, maskPhone, showCode, formatPhone } from '../../lib/format.js';

/** Consulta e cancelamento pelo código + telefone. */
export default function Lookup({ initial }) {
  let saved = null;
  if (!initial) {
    try {
      saved = JSON.parse(localStorage.getItem('nn:last') || 'null');
    } catch {
      saved = null;
    }
  }
  const start = initial || saved || {};
  const [open, setOpen] = useState(Boolean(initial));
  const [code, setCode] = useState(start.code ? showCode(start.code) : '');
  const [phone, setPhone] = useState(start.phone ? formatPhone(start.phone) : '');
  const [appt, setAppt] = useState(null);
  const [msg, setMsg] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState(false);
  const [confirm, setConfirm] = useState(false);

  async function find(e) {
    e?.preventDefault();
    setBusy(true);
    setMsg({ type: '', text: '' });
    setConfirm(false);
    try {
      setAppt(await api('/api/appointments/lookup', { method: 'POST', body: { code, phone } }).then((r) => r.appointment));
    } catch (err) {
      setAppt(null);
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  async function cancel() {
    setBusy(true);
    try {
      const { appointment } = await api('/api/appointments/cancel', { method: 'POST', body: { code, phone } });
      setAppt(appointment);
      setMsg({ type: 'ok', text: 'Agendamento cancelado. O horário já voltou para a agenda.' });
      setConfirm(false);
      try {
        localStorage.removeItem('nn:last');
      } catch {
        /* ignora */
      }
    } catch (err) {
      setMsg({ type: 'err', text: err.message });
    } finally {
      setBusy(false);
    }
  }

  const STATUS = { confirmed: 'Confirmado', cancelled: 'Cancelado', done: 'Concluído', no_show: 'Não compareceu' };

  return (
    <details className="lookup" open={open} onToggle={(e) => setOpen(e.currentTarget.open)}>
      <summary>Já tem um agendamento? Consulte ou cancele</summary>
      <form className="lookup__form" onSubmit={find}>
        <div className="field">
          <label htmlFor="l-code">Código</label>
          <input id="l-code" value={code} maxLength={7} autoCapitalize="characters" placeholder="K7P-4QM" onChange={(e) => setCode(e.target.value.toUpperCase())} />
        </div>
        <div className="field">
          <label htmlFor="l-phone">Telefone</label>
          <input id="l-phone" type="tel" inputMode="tel" placeholder="(11) 91234-5678" value={phone} onChange={(e) => setPhone(maskPhone(e.target.value))} />
        </div>
        <button className="btn btn--ghost" type="submit" disabled={busy || code.length < 6 || phone.replace(/\D/g, '').length < 10}>
          <span>{busy ? 'Buscando…' : 'Consultar'}</span>
        </button>
      </form>

      <div aria-live="polite">
        {msg.text && <p className={msg.type === 'ok' ? 'ok' : 'err'}>{msg.text}</p>}
        {appt && (
          <div className="found">
            <p>
              <b>{appt.serviceName}</b> com {appt.barberName} · <span className="cap">{longDate(appt.date)}</span> às {appt.time} · {brl(appt.priceCents)}
            </p>
            <p className={`pill pill--${appt.status}`}>{STATUS[appt.status] || appt.status}</p>
            {appt.canCancel &&
              (confirm ? (
                <div className="found__confirm">
                  <span>Cancelar este horário?</span>
                  <button type="button" className="btn btn--danger btn--sm" onClick={cancel} disabled={busy}><span>Sim, cancelar</span></button>
                  <button type="button" className="btn btn--ghost btn--sm" onClick={() => setConfirm(false)}><span>Manter</span></button>
                </div>
              ) : (
                <button type="button" className="btn btn--danger btn--sm" onClick={() => setConfirm(true)}><span>Cancelar agendamento</span></button>
              ))}
          </div>
        )}
      </div>
    </details>
  );
}
