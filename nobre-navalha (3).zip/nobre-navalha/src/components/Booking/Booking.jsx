import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useSite } from '../../site-context.js';
import { Reveal } from '../../hooks/useReveal.jsx';
import { api } from '../../lib/api.js';
import { addDays, brl, dayMonth, dayNumber, duration, initials, longDate, maskPhone, monthYear, showCode, toMin, weekdayShort } from '../../lib/format.js';
import { hoursFor } from '../../lib/hours.js';
import { waLink } from '../../lib/whatsapp.js';
import { IconCalendar, IconCheck, IconDownload, IconWarn, IconWhatsApp } from '../icons.jsx';
import { downloadIcs } from './ics.js';
import Lookup from './Lookup.jsx';

const REASONS = {
  past: 'Esta data já passou.',
  too_far: 'Ainda não abrimos a agenda para esta data.',
  holiday: 'Não abrimos neste dia. Escolha outra data.',
  closed: 'Não abrimos neste dia da semana. Escolha outra data.',
};

const fromMin = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;

export default function Booking({ intent }) {
  const { business, services, barbers, timezone, now, startBooking } = useSite();

  const [serviceId, setServiceId] = useState(null);
  const [barberId, setBarberId] = useState(null);
  const [date, setDate] = useState(null);
  const [time, setTime] = useState(null);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [trap, setTrap] = useState('');
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [sending, setSending] = useState(false);
  const [done, setDone] = useState(null);

  const [day, setDay] = useState({ state: 'idle', slots: [], reason: null });
  const formRef = useRef(null);
  const timesRef = useRef(null);
  const nameRef = useRef(null);

  const service = services.find((s) => s.id === serviceId) || null;
  const barber = barbers.find((b) => b.id === barberId) || null;

  /* Chega do resto do site: "Agendar com Fulano", "Quero esse corte"... */
  useEffect(() => {
    if (!intent.nonce) return;
    setDone(null);
    if (intent.serviceId) setServiceId(intent.serviceId);
    if (intent.barberId) setBarberId(intent.barberId);
    setTime(null);
  }, [intent]);

  // se um serviço/barbeiro for removido pelo painel enquanto a pessoa escolhe
  useEffect(() => {
    if (serviceId && !service) setServiceId(null);
    if (barberId && !barber) setBarberId(null);
  }, [service, barber, serviceId, barberId]);

  /* 30 dias (ou o que o painel definir) a partir de hoje no fuso da barbearia */
  const days = useMemo(
    () =>
      Array.from({ length: business.maxDaysAhead + 1 }, (_, i) => {
        const d = addDays(now.date, i);
        return { date: d, open: Boolean(hoursFor(business, d)) };
      }),
    [business, now.date],
  );

  /* Horários livres do dia escolhido */
  const loadDay = useCallback(
    async (signal) => {
      if (!serviceId || !barberId || !date) return;
      setDay((d) => ({ ...d, state: 'loading' }));
      try {
        const res = await api(`/api/availability?date=${date}&barberId=${barberId}&serviceId=${serviceId}`, { signal });
        setDay({ state: 'ready', slots: res.slots, reason: res.open ? null : res.reason });
      } catch (err) {
        if (err.name === 'AbortError') return;
        setDay({ state: 'error', slots: [], reason: null, message: err.message });
      }
    },
    [serviceId, barberId, date],
  );

  useEffect(() => {
    if (!serviceId || !barberId || !date) {
      setDay({ state: 'idle', slots: [], reason: null });
      return undefined;
    }
    const ctrl = new AbortController();
    loadDay(ctrl.signal);
    // atualiza a grade enquanto a pessoa decide, para não oferecer horário que acabou de ser pego
    const every = setInterval(() => loadDay(ctrl.signal), 45_000);
    return () => {
      ctrl.abort();
      clearInterval(every);
    };
  }, [serviceId, barberId, date, loadDay]);

  // se o horário escolhido deixou de estar livre, solta a escolha
  useEffect(() => {
    if (time && day.state === 'ready' && !day.slots.some((s) => s.time === time && s.available)) setTime(null);
  }, [day, time]);

  const pick = (setter) => (value) => {
    setter(value);
    setTime(null);
    setErrors({});
    setFormError('');
  };

  const freeCount = day.slots.filter((s) => s.available).length;
  const endTime = service && time ? fromMin(toMin(time) + service.durationMin) : null;
  const ready = Boolean(service && barber && date && time);

  async function submit(e) {
    e.preventDefault();
    if (sending) return;
    setErrors({});
    setFormError('');
    setSending(true);
    try {
      const { appointment } = await api('/api/appointments', {
        method: 'POST',
        body: { serviceId, barberId, date, time, name, phone, website: trap },
      });
      setDone(appointment);
      try {
        localStorage.setItem('nn:last', JSON.stringify({ code: appointment.code, phone: appointment.customerPhone }));
      } catch {
        /* armazenamento indisponível: tudo bem */
      }
      document.getElementById('agendar')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (err) {
      setErrors(err.fields || {});
      setFormError(err.message);
      if (err.code === 'SLOT_TAKEN' || err.code === 'INVALID_TIME' || err.code === 'DAY_UNAVAILABLE') {
        setTime(null);
        loadDay();
        timesRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      } else if (err.fields?.name) nameRef.current?.focus();
    } finally {
      setSending(false);
    }
  }

  function reset() {
    setDone(null);
    setServiceId(null);
    setBarberId(null);
    setDate(null);
    setTime(null);
    setName('');
    setPhone('');
    setErrors({});
    setFormError('');
  }

  /* ----------------------------- sucesso ----------------------------- */
  if (done) {
    const msg = `Olá! Acabei de agendar na ${business.businessName}: ${done.serviceName} com ${done.barberName}, ${longDate(done.date)} às ${done.time}. Código ${showCode(done.code)}.`;
    return (
      <section className="section book" id="agendar" aria-labelledby="agendar-t">
        <div className="wrap">
          <div className="done" role="status">
            <span className="done__seal" aria-hidden="true"><IconCheck size={34} /></span>
            <p className="eyebrow done__eyebrow">Reserva confirmada</p>
            <h2 id="agendar-t" className="done__title">Tudo certo, {done.customerName.split(' ')[0]}!</h2>
            <p className="done__lead">Seu horário está reservado. Guarde o código abaixo: com ele e o seu telefone você consulta ou cancela o agendamento.</p>

            <div className="ticket">
              <div className="ticket__code">
                <span>Código</span>
                <b>{showCode(done.code)}</b>
              </div>
              <dl>
                <div><dt>Serviço</dt><dd>{done.serviceName}</dd></div>
                <div><dt>Barbeiro</dt><dd>{done.barberName}</dd></div>
                <div><dt>Data</dt><dd className="cap">{longDate(done.date)}</dd></div>
                <div><dt>Horário</dt><dd>{done.time} às {done.endTime}</dd></div>
                <div><dt>Valor</dt><dd>{brl(done.priceCents)} <small>pagamento no local</small></dd></div>
                <div><dt>Endereço</dt><dd>{business.address}</dd></div>
              </dl>
            </div>

            <div className="done__actions">
              <button className="btn btn--primary" onClick={() => downloadIcs({ appointment: done, business, timezone })}>
                <span><IconDownload /> Adicionar ao calendário</span>
              </button>
              <a className="btn btn--wa" href={waLink(business.whatsapp, msg)} target="_blank" rel="noopener noreferrer">
                <span><IconWhatsApp size={20} /> Avisar no WhatsApp</span>
              </a>
              <button className="btn btn--ghost" onClick={reset}><span>Fazer outro agendamento</span></button>
            </div>
          </div>
          <Lookup initial={{ code: done.code, phone: done.customerPhone }} />
        </div>
      </section>
    );
  }

  /* ----------------------------- formulário ----------------------------- */
  const monthLabels = new Map();
  days.forEach((d, i) => {
    const key = d.date.slice(0, 7);
    if (!monthLabels.has(key)) monthLabels.set(key, i);
  });

  return (
    <section className="section book" id="agendar" aria-labelledby="agendar-t">
      <div className="pole" aria-hidden="true" />
      <div className="wrap">
        <div className="section__head">
          <Reveal as="p" className="eyebrow">Agendamento online</Reveal>
          <Reveal as="h2" id="agendar-t" className="section__title">
            Reserve o seu <em>horário</em>
          </Reveal>
          <Reveal as="p" className="section__lead" delay={100}>
            Sem cadastro e sem espera. Em quatro escolhas rápidas o horário é seu, e ninguém mais consegue reservá-lo.
          </Reveal>
        </div>

        <form className="book__grid" onSubmit={submit} ref={formRef} noValidate>
          <div className="book__steps">
            {/* 1. serviço */}
            <fieldset className="step">
              <legend><span className="step__n">1</span> Serviço</legend>
              <div className="opts opts--services">
                {services.map((s) => (
                  <label key={s.id} className={`opt ${serviceId === s.id ? 'is-on' : ''}`}>
                    <input type="radio" name="service" className="sr-only" checked={serviceId === s.id} onChange={() => pick(setServiceId)(s.id)} />
                    <span className="opt__t">{s.name}</span>
                    <span className="opt__m">{brl(s.priceCents)} · {duration(s.durationMin)}</span>
                  </label>
                ))}
              </div>
              {errors.serviceId && <p className="err">{errors.serviceId}</p>}
            </fieldset>

            {/* 2. barbeiro */}
            <fieldset className="step">
              <legend><span className="step__n">2</span> Barbeiro</legend>
              <div className="opts opts--barbers">
                {barbers.map((b) => (
                  <label key={b.id} className={`opt opt--barber ${barberId === b.id ? 'is-on' : ''}`}>
                    <input type="radio" name="barber" className="sr-only" checked={barberId === b.id} onChange={() => pick(setBarberId)(b.id)} />
                    <span className="avatar" aria-hidden="true">{initials(b.name)}</span>
                    <span>
                      <span className="opt__t">{b.name}</span>
                      <span className="opt__m">{b.role}</span>
                    </span>
                  </label>
                ))}
              </div>
              {errors.barberId && <p className="err">{errors.barberId}</p>}
            </fieldset>

            {/* 3. data */}
            <fieldset className="step">
              <legend><span className="step__n">3</span> Data</legend>
              <div className="days" role="radiogroup" aria-label="Escolha a data">
                {days.map((d, i) => (
                  <label key={d.date} className={`day ${date === d.date ? 'is-on' : ''} ${d.open ? '' : 'is-off'}`}>
                    <input type="radio" name="date" className="sr-only" disabled={!d.open} checked={date === d.date} onChange={() => pick(setDate)(d.date)} />
                    {monthLabels.get(d.date.slice(0, 7)) === i && <em className="day__month">{monthYear(d.date).split(' de ')[0]}</em>}
                    <span className="day__w">{i === 0 ? 'hoje' : weekdayShort(d.date)}</span>
                    <span className="day__n">{dayNumber(d.date)}</span>
                    <span className="day__sub">{d.open ? dayMonth(d.date) : 'fechado'}</span>
                  </label>
                ))}
              </div>
              {errors.date && <p className="err">{errors.date}</p>}
            </fieldset>

            {/* 4. horário */}
            <fieldset className="step" ref={timesRef} aria-live="polite">
              <legend><span className="step__n">4</span> Horário</legend>
              {!service || !barber || !date ? (
                <p className="hint">Escolha serviço, barbeiro e data para ver os horários livres.</p>
              ) : day.state === 'loading' && !day.slots.length ? (
                <div className="slots slots--skeleton" aria-label="Carregando horários">
                  {Array.from({ length: 12 }, (_, i) => <span key={i} />)}
                </div>
              ) : day.state === 'error' ? (
                <p className="err">{day.message} <button type="button" className="link" onClick={() => loadDay()}>Tentar de novo</button></p>
              ) : day.reason ? (
                <p className="hint hint--warn"><IconWarn /> {REASONS[day.reason] || 'Sem horários neste dia.'}</p>
              ) : freeCount === 0 ? (
                <p className="hint hint--warn"><IconWarn /> Todos os horários deste dia já foram reservados. Experimente outra data ou outro barbeiro.</p>
              ) : (
                <>
                  <div className="slots">
                    {day.slots.map((s) => (
                      <label key={s.time} className={`slot ${time === s.time ? 'is-on' : ''} ${s.available ? '' : 'is-off'}`}>
                        <input type="radio" name="time" className="sr-only" disabled={!s.available} checked={time === s.time} onChange={() => { setTime(s.time); setErrors({}); setFormError(''); }} />
                        <span>{s.time}</span>
                        {!s.available && <span className="sr-only">{s.reason === 'taken' ? ' (reservado)' : ' (indisponível)'}</span>}
                      </label>
                    ))}
                  </div>
                  <p className="hint">{freeCount} {freeCount === 1 ? 'horário livre' : 'horários livres'} com {barber.name.split(' ')[0]}.</p>
                </>
              )}
              {errors.time && <p className="err">{errors.time}</p>}
            </fieldset>

            {/* 5. dados */}
            <fieldset className="step" disabled={!ready}>
              <legend><span className="step__n">5</span> Seus dados</legend>
              <div className="fields">
                <div className={`field ${errors.name ? 'has-err' : ''}`}>
                  <label htmlFor="f-name">Nome</label>
                  <input id="f-name" ref={nameRef} type="text" autoComplete="name" placeholder="Como podemos te chamar?" value={name} maxLength={80} onChange={(e) => setName(e.target.value)} aria-invalid={Boolean(errors.name)} aria-describedby={errors.name ? 'e-name' : undefined} />
                  {errors.name && <p className="err" id="e-name">{errors.name}</p>}
                </div>
                <div className={`field ${errors.phone ? 'has-err' : ''}`}>
                  <label htmlFor="f-phone">Telefone / WhatsApp</label>
                  <input id="f-phone" type="tel" inputMode="tel" autoComplete="tel-national" placeholder="(11) 91234-5678" value={phone} onChange={(e) => setPhone(maskPhone(e.target.value))} aria-invalid={Boolean(errors.phone)} aria-describedby={errors.phone ? 'e-phone' : undefined} />
                  {errors.phone && <p className="err" id="e-phone">{errors.phone}</p>}
                </div>
                {/* campo isca: pessoas não veem, robôs preenchem */}
                <div className="hp" aria-hidden="true">
                  <label>Não preencha<input tabIndex={-1} autoComplete="off" value={trap} onChange={(e) => setTrap(e.target.value)} /></label>
                </div>
              </div>
            </fieldset>

            {formError && <p className="err err--box" role="alert"><IconWarn /> {formError}</p>}
          </div>

          {/* resumo */}
          <aside className="summary" aria-label="Resumo do agendamento">
            <h3>Seu horário</h3>
            <dl>
              <div className={service ? 'is-set' : ''}><dt>Serviço</dt><dd>{service ? service.name : 'Escolha um serviço'}</dd></div>
              <div className={barber ? 'is-set' : ''}><dt>Barbeiro</dt><dd>{barber ? barber.name : 'Escolha um barbeiro'}</dd></div>
              <div className={date ? 'is-set' : ''}><dt>Data</dt><dd className="cap">{date ? longDate(date) : 'Escolha uma data'}</dd></div>
              <div className={time ? 'is-set' : ''}><dt>Horário</dt><dd>{time ? `${time} às ${endTime}` : 'Escolha um horário'}</dd></div>
            </dl>
            <div className="summary__total">
              <span>Total <small>(pagamento no local)</small></span>
              <b>{service ? brl(service.priceCents) : '—'}</b>
            </div>
            <button className="btn btn--primary summary__btn" type="submit" disabled={!ready || sending || !name.trim() || phone.replace(/\D/g, '').length < 10}>
              <span>{sending ? 'Confirmando…' : <><IconCalendar /> Confirmar agendamento</>}</span>
            </button>
            <p className="summary__fine">Ao confirmar, você autoriza o uso do nome e do telefone apenas para este atendimento.</p>
          </aside>
        </form>

        <Lookup />
      </div>
    </section>
  );
}
