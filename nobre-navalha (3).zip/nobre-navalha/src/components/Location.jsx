import { useMemo } from 'react';
import { useSite } from '../site-context.js';
import { Reveal } from '../hooks/useReveal.jsx';
import { groupHours, openStatus } from '../lib/hours.js';
import { mapsEmbed, mapsLink, waLink } from '../lib/whatsapp.js';
import { IconClock, IconInstagram, IconPhone, IconPin, IconWhatsApp } from './icons.jsx';

export default function Location() {
  const { business, timezone } = useSite();
  const rows = useMemo(() => groupHours(business.hours), [business.hours]);
  const status = openStatus(business, timezone);
  const todayIdx = new Date(new Date().toLocaleString('en-US', { timeZone: timezone })).getDay();

  return (
    <section className="section section--alt" id="local" aria-labelledby="local-t">
      <div className="wrap">
        <div className="section__head">
          <Reveal as="p" className="eyebrow">Onde estamos</Reveal>
          <Reveal as="h2" id="local-t" className="section__title">
            Venha tomar o seu <em>lugar</em> na cadeira
          </Reveal>
        </div>

        <div className="loc">
          <Reveal className="loc__info" variant="rise">
            <p className={`loc__status ${status.open ? 'is-open' : ''}`} role="status">
              <span className="dot" aria-hidden="true" /> {status.text}
            </p>

            <div className="loc__block">
              <h3><IconPin /> Endereço</h3>
              <p>{business.address}</p>
              <a className="btn btn--ghost btn--sm" href={mapsLink(business.address)} target="_blank" rel="noopener noreferrer">
                <span>Abrir rota no mapa</span>
              </a>
            </div>

            <div className="loc__block">
              <h3><IconClock /> Horário de funcionamento</h3>
              <ul className="hours">
                {rows.map((r) => (
                  <li key={r.label} className={`${r.closed ? 'is-closed' : ''} ${r.days.includes(todayIdx) ? 'is-today' : ''}`}>
                    <span>{r.label}</span>
                    <b>{r.hours}</b>
                  </li>
                ))}
              </ul>
            </div>

            <div className="loc__block loc__links">
              <a className="btn btn--wa" href={waLink(business.whatsapp, 'Olá! Gostaria de agendar um horário.')} target="_blank" rel="noopener noreferrer">
                <span><IconWhatsApp size={20} /> Chamar no WhatsApp</span>
              </a>
              <a className="loc__link" href={`tel:+${business.whatsapp}`}>
                <IconPhone /> {business.phone}
              </a>
              {business.instagram && (
                <a className="loc__link" href={`https://www.instagram.com/${business.instagram}`} target="_blank" rel="noopener noreferrer">
                  <IconInstagram /> @{business.instagram}
                </a>
              )}
            </div>
          </Reveal>

          <Reveal className="loc__map" variant="scale" delay={120}>
            <iframe
              title={`Mapa: ${business.address}`}
              src={mapsEmbed(business.address)}
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              allowFullScreen
            />
          </Reveal>
        </div>
      </div>
    </section>
  );
}
