import { useSite } from '../site-context.js';
import { Reveal } from '../hooks/useReveal.jsx';
import { CUTS } from '../data/cuts.js';
import { normalizeText } from '../lib/format.js';
import CutHead from './CutHead.jsx';

export default function Cuts() {
  const { services, startBooking } = useSite();

  const serviceFor = (cut) =>
    services.find((s) => cut.match.some((m) => normalizeText(s.name).includes(m)))?.id ?? null;

  return (
    <section className="section section--alt" id="cortes" aria-labelledby="cortes-t">
      <div className="wrap">
        <div className="section__head">
          <Reveal as="p" className="eyebrow">Galeria de cortes</Reveal>
          <Reveal as="h2" id="cortes-t" className="section__title">
            Seis caminhos para o <em>seu</em> estilo
          </Reveal>
          <Reveal as="p" className="section__lead" delay={100}>
            Não sabe qual escolher? Leve a referência que quiser ou deixe o barbeiro sugerir o que combina com o seu rosto e o seu fio.
          </Reveal>
        </div>

        <div className="cuts">
          {CUTS.map((cut, i) => (
            <Reveal as="article" key={cut.kind} className="cut" variant="rise" delay={(i % 3) * 90}>
              <div className="cut__art">
                <CutHead kind={cut.kind} label={`Ilustração de ${cut.name}`} />
                <span className="cut__idx" aria-hidden="true">{String(i + 1).padStart(2, '0')}</span>
              </div>
              <div className="cut__body">
                <h3>{cut.name}</h3>
                <p>{cut.text}</p>
                <dl>
                  <div><dt>Ideal para</dt><dd>{cut.ideal}</dd></div>
                  <div><dt>Manutenção</dt><dd>{cut.upkeep}</dd></div>
                </dl>
                <button className="btn btn--ghost btn--sm" onClick={() => startBooking({ serviceId: serviceFor(cut) })}>
                  <span>Quero esse corte</span>
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
