import { useSite } from '../site-context.js';
import { Reveal } from '../hooks/useReveal.jsx';
import { brl, duration } from '../lib/format.js';
import { IconChevron } from './icons.jsx';

export default function Services() {
  const { services, startBooking } = useSite();
  return (
    <section className="section" id="servicos" aria-labelledby="servicos-t">
      <div className="wrap services">
        <div className="section__head services__head">
          <Reveal as="p" className="eyebrow">Serviços e preços</Reveal>
          <Reveal as="h2" id="servicos-t" className="section__title">
            Ofício de <em>precisão</em>, preço à vista
          </Reveal>
          <Reveal as="p" className="section__lead" delay={100}>
            Valores atualizados em tempo real. Escolha o serviço e reserve em seguida, sem precisar de cadastro.
          </Reveal>
        </div>

        <ul className="menu" aria-label="Lista de serviços">
          {services.map((s, i) => (
            <Reveal as="li" key={s.id} className="menu__item" variant="rise" delay={Math.min(i, 6) * 70}>
              <button className="menu__btn" onClick={() => startBooking({ serviceId: s.id })} aria-label={`Agendar ${s.name}, ${brl(s.priceCents)}`}>
                <span className="menu__num" aria-hidden="true">{String(i + 1).padStart(2, '0')}</span>
                <span className="menu__main">
                  <span className="menu__name">{s.name}</span>
                  {s.description && <span className="menu__desc">{s.description}</span>}
                </span>
                <span className="menu__meta">
                  <span className="menu__price">{brl(s.priceCents)}</span>
                  <span className="menu__time">{duration(s.durationMin)}</span>
                </span>
                <span className="menu__go" aria-hidden="true"><IconChevron /></span>
              </button>
            </Reveal>
          ))}
        </ul>
      </div>
    </section>
  );
}
