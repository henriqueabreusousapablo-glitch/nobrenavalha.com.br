import { useEffect, useState } from 'react';
import { useSite } from '../site-context.js';
import { IconMenu, Wordmark } from './icons.jsx';

const LINKS = [
  ['#servicos', 'Serviços'],
  ['#cortes', 'Cortes'],
  ['#barbeiros', 'Barbeiros'],
  ['#ciencia', 'Ciência do fio'],
  ['#avaliacoes', 'Avaliações'],
  ['#local', 'Onde estamos'],
];

export default function Header() {
  const { startBooking } = useSite();
  const [stuck, setStuck] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState('');

  useEffect(() => {
    const onScroll = () => {
      setStuck(scrollY > 24);
      if (scrollY < 200) setActive('');
    };
    onScroll();
    addEventListener('scroll', onScroll, { passive: true });
    return () => removeEventListener('scroll', onScroll);
  }, []);

  // destaca o item do menu da seção visível
  useEffect(() => {
    const ids = [...LINKS.map(([h]) => h.slice(1)), 'agendar'];
    const els = ids.map((id) => document.getElementById(id)).filter(Boolean);
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) setActive(`#${e.target.id}`);
      },
      { rootMargin: '-45% 0px -50% 0px' },
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);

  useEffect(() => {
    document.documentElement.style.overflow = open ? 'hidden' : '';
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    addEventListener('keydown', onKey);
    return () => {
      removeEventListener('keydown', onKey);
      document.documentElement.style.overflow = '';
    };
  }, [open]);

  return (
    <header className={`header ${stuck || open ? 'is-stuck' : ''}`}>
      <div className="header__in">
        <a href="#topo" className="wordmark" aria-label="Nobre Navalha, início" onClick={() => setOpen(false)}>
          <Wordmark />
        </a>
        <nav id="menu" className={`nav ${open ? 'is-open' : ''}`} aria-label="Principal">
          {LINKS.map(([href, label]) => (
            <a
              key={href}
              href={href}
              className={`nav__link ${active === href ? 'is-active' : ''}`}
              onClick={() => setOpen(false)}
            >
              {label}
            </a>
          ))}
          <button
            className="btn btn--primary btn--mobile"
            onClick={() => {
              setOpen(false);
              startBooking();
            }}
          >
            <span>Agendar horário</span>
          </button>
        </nav>
        <button className="btn btn--primary btn--sm header__cta" onClick={() => startBooking()}>
          <span>Agendar</span>
        </button>
        <button
          className="header__burger"
          aria-expanded={open}
          aria-controls="menu"
          aria-label={open ? 'Fechar menu' : 'Abrir menu'}
          onClick={() => setOpen((v) => !v)}
        >
          <IconMenu open={open} />
        </button>
      </div>
    </header>
  );
}
