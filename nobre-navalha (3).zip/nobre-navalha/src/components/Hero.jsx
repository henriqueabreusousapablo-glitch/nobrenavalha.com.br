import { useEffect, useRef } from 'react';
import { useSite } from '../site-context.js';
import { openStatus } from '../lib/hours.js';
import { IconChevron } from './icons.jsx';

const WORDS = ['Seu', 'estilo', 'começa', 'no', 'corte', 'certo'];
const TICKER = ['Degradê', 'Corte social', 'Mullet', 'Buzz cut', 'Barba na navalha', 'Toalha quente', 'Acabamento milimétrico'];

function RazorArt() {
  return (
    <svg className="razor" viewBox="0 0 640 640" aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="steel" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f6f0e4" />
          <stop offset=".35" stopColor="#c9c3b8" />
          <stop offset=".62" stopColor="#8c877e" />
          <stop offset="1" stopColor="#d9d3c6" />
        </linearGradient>
        <linearGradient id="grip" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4a3326" />
          <stop offset=".5" stopColor="#2a1c14" />
          <stop offset="1" stopColor="#1a110c" />
        </linearGradient>
        <linearGradient id="goldg" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#ebd299" />
          <stop offset="1" stopColor="#8f6f32" />
        </linearGradient>
        <clipPath id="blade-clip">
          <path d="M214 296 L528 270 C566 268 598 288 606 314 C576 318 550 328 526 340 L214 352 Z" />
        </clipPath>
      </defs>

      <g className="razor__rings" fill="none" stroke="#c9a45c" strokeWidth="1">
        <circle cx="320" cy="320" r="292" opacity=".22" />
        <circle cx="320" cy="320" r="252" opacity=".14" strokeDasharray="2 10" />
        <circle className="razor__spin" cx="320" cy="320" r="312" opacity=".3" strokeDasharray="1 18" strokeWidth="3" strokeLinecap="round" />
      </g>

      <g className="razor__body" transform="rotate(-28 320 320)">
        {/* cabo */}
        <g className="razor__handle">
          <path d="M40 322 C40 296 62 288 92 288 L226 294 L226 360 L92 360 C62 360 40 350 40 322 Z" fill="url(#grip)" stroke="#6b4b36" strokeWidth="1.5" />
          <path d="M70 304 L214 308 M62 324 L214 326 M70 344 L214 346" stroke="#c9a45c" strokeOpacity=".32" strokeWidth="1.6" />
          <path d="M40 322 C40 296 62 288 92 288 L226 294 L226 302 L94 296 C66 296 50 304 46 322 Z" fill="#fff" opacity=".14" />
        </g>
        {/* lâmina */}
        <g className="razor__blade">
          <path d="M214 296 L528 270 C566 268 598 288 606 314 C576 318 550 328 526 340 L214 352 Z" fill="url(#steel)" stroke="#ece4d3" strokeWidth="1" />
          <path d="M214 304 L526 280" stroke="#fff" strokeWidth="2" strokeOpacity=".75" />
          <path d="M214 338 L520 326" stroke="#59544c" strokeWidth="4" strokeOpacity=".45" /><path d="M214 346 L520 336" stroke="#fff" strokeWidth="1.5" strokeOpacity=".8" />
          <g clipPath="url(#blade-clip)">
            <rect className="razor__glint" x="180" y="260" width="70" height="110" fill="#fff" opacity=".7" transform="skewX(-24)" />
          </g>
          <path d="M240 320 h60 M320 320 h20" stroke="#4d483f" strokeWidth="1.2" strokeOpacity=".5" />
        </g>
        {/* pino */}
        <circle cx="224" cy="326" r="18" fill="url(#goldg)" stroke="#6e5424" />
        <circle cx="224" cy="326" r="6.5" fill="#2a1c14" />
      </g>

      {/* fios que se desenham ao redor */}
      <g fill="none" stroke="#ebd299" strokeLinecap="round" strokeWidth="1.4" opacity=".7">
        <path className="strand s1" d="M70 150 C140 80 230 100 270 56" />
        <path className="strand s2" d="M580 470 C500 540 410 520 370 586" />
        <path className="strand s3" d="M44 420 C80 500 170 520 200 590" />
      </g>
    </svg>
  );
}

export default function Hero() {
  const { business, services, barbers, timezone, startBooking } = useSite();
  const ref = useRef(null);
  const status = openStatus(business, timezone);

  // brilho que acompanha o ponteiro (só em dispositivos com mouse)
  useEffect(() => {
    const el = ref.current;
    if (!el || !matchMedia('(hover: hover) and (pointer: fine)').matches) return undefined;
    let frame = 0;
    const move = (e) => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const r = el.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width;
        const y = (e.clientY - r.top) / r.height;
        el.style.setProperty('--mx', `${x * 100}%`);
        el.style.setProperty('--my', `${y * 100}%`);
        el.style.setProperty('--tx', ((x - 0.5) * 2).toFixed(3));
        el.style.setProperty('--ty', ((y - 0.5) * 2).toFixed(3));
      });
    };
    el.addEventListener('pointermove', move);
    return () => {
      el.removeEventListener('pointermove', move);
      cancelAnimationFrame(frame);
    };
  }, []);

  return (
    <section className="hero" id="topo" ref={ref} aria-labelledby="hero-t">
      <div className="hero__glow" aria-hidden="true" />
      <div className="hero__grain" aria-hidden="true" />

      <div className="wrap hero__grid">
        <div className="hero__copy">
          <p className="eyebrow hero__eyebrow">Barbearia de alto padrão</p>
          <h1 id="hero-t" className="hero__title" aria-label={WORDS.join(' ')}>
            {WORDS.map((w, i) => (
              <span className="hw" key={w + i} aria-hidden="true">
                <span style={{ '--i': i }}>{w}</span>
              </span>
            ))}
          </h1>
          <span className="hero__rule" aria-hidden="true" />
          <p className="hero__lead">
            Degradês milimétricos, navalha afiada e atendimento sem pressa. Escolha o serviço, o barbeiro e o horário, e confirme em menos de um minuto.
          </p>
          <div className="hero__cta">
            <button className="btn btn--primary" onClick={() => startBooking()}>
              <span>Agendar meu horário <IconChevron /></span>
            </button>
            <a className="btn btn--ghost" href="#cortes">
              <span>Ver os cortes</span>
            </a>
          </div>
          <p className={`hero__status ${status.open ? 'is-open' : ''}`} role="status">
            <span className="dot" aria-hidden="true" /> {status.text}
          </p>
        </div>

        <div className="hero__art">
          <div className="hero__parallax">
            <RazorArt />
          </div>
          <ul className="hero__facts" aria-label="Destaques">
            <li><b>{barbers.length}</b><span>barbeiros</span></li>
            <li><b>{services.length}</b><span>serviços</span></li>
            <li><b>&lt; 1 min</b><span>para agendar</span></li>
          </ul>
        </div>
      </div>

      <div className="ticker" aria-hidden="true">
        <div className="ticker__track">
          {[0, 1].map((n) => (
            <div className="ticker__row" key={n}>
              {TICKER.map((t) => (
                <span key={t + n}>{t}<i /></span>
              ))}
            </div>
          ))}
        </div>
      </div>
      <a className="hero__scroll" href="#servicos" aria-label="Rolar para os serviços"><span /></a>
    </section>
  );
}
