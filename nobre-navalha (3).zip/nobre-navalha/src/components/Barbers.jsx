import { useSite } from '../site-context.js';
import { Reveal } from '../hooks/useReveal.jsx';
import { initials } from '../lib/format.js';

export default function Barbers() {
  const { barbers, startBooking } = useSite();
  return (
    <section className="section" id="barbeiros" aria-labelledby="barbeiros-t">
      <div className="wrap">
        <div className="section__head">
          <Reveal as="p" className="eyebrow">A equipe</Reveal>
          <Reveal as="h2" id="barbeiros-t" className="section__title">
            Mãos que <em>entendem</em> do ofício
          </Reveal>
        </div>

        <div className="team">
          {barbers.map((b, i) => (
            <Reveal as="article" key={b.id} className="pro" variant="rise" delay={i * 110}>
              <div className="pro__photo">
                {b.photoUrl ? (
                  <img src={b.photoUrl} alt={`${b.name}, ${b.role}`} loading="lazy" width="400" height="500" />
                ) : (
                  <div className="pro__mono" aria-hidden="true">
                    <span>{initials(b.name)}</span>
                  </div>
                )}
                <span className="pro__shine" aria-hidden="true" />
              </div>
              <div className="pro__body">
                <p className="pro__role">{b.role}</p>
                <h3>{b.name}</h3>
                <p className="pro__bio">{b.bio}</p>
                <ul className="tags" aria-label="Especialidades">
                  {b.specialties.map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
                <button className="btn btn--ghost btn--sm" onClick={() => startBooking({ barberId: b.id })}>
                  <span>Agendar com {b.name.split(' ')[0]}</span>
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
