import { useCallback, useEffect, useState } from 'react';

const centsToInput = (c) => (c / 100).toFixed(2).replace('.', ',');
const inputToCents = (v) => Math.round(Number(String(v).replace(/\./g, '').replace(',', '.')) * 100);

function useList(call, notify, path, key) {
  const [items, setItems] = useState(null);
  const load = useCallback(async () => {
    try {
      setItems((await call(path))[key]);
    } catch (err) {
      notify(err.message, 'err');
    }
  }, [call, notify, path, key]);
  useEffect(() => {
    load();
  }, [load]);
  return [items, load];
}

/* --------------------------- serviços e preços --------------------------- */

function ServiceRow({ item, call, notify, reload }) {
  const isNew = !item.id;
  const [f, setF] = useState({
    name: item.name,
    description: item.description,
    price: centsToInput(item.priceCents),
    durationMin: item.durationMin,
    active: item.active,
  });
  const [errors, setErrors] = useState({});
  const set = (k) => (e) => setF((v) => ({ ...v, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  async function save(e) {
    e.preventDefault();
    setErrors({});
    const body = { name: f.name, description: f.description, priceCents: inputToCents(f.price), durationMin: Number(f.durationMin), active: f.active };
    try {
      await call(isNew ? '/api/admin/services' : `/api/admin/services/${item.id}`, { method: isNew ? 'POST' : 'PUT', body });
      notify(isNew ? 'Serviço criado.' : 'Serviço salvo. O site já mostra o novo preço.');
      reload();
    } catch (err) {
      setErrors(err.fields || {});
      notify(err.message, 'err');
    }
  }

  async function remove() {
    if (!window.confirm(`Excluir "${item.name}"? Se já houver agendamentos, ele será apenas desativado.`)) return;
    try {
      const r = await call(`/api/admin/services/${item.id}`, { method: 'DELETE' });
      notify(r?.deactivated ? 'Serviço desativado (tem histórico de agendamentos).' : 'Serviço excluído.');
      reload();
    } catch (err) {
      notify(err.message, 'err');
    }
  }

  return (
    <form className={`row ${f.active ? '' : 'is-off'}`} onSubmit={save}>
      <label className="w-name">Nome<input value={f.name} onChange={set('name')} maxLength={80} required />{errors.name && <small className="err">{errors.name}</small>}</label>
      <label className="w-price">Preço (R$)<input value={f.price} onChange={set('price')} inputMode="decimal" required />{errors.priceCents && <small className="err">{errors.priceCents}</small>}</label>
      <label className="w-dur">Duração
        <select value={f.durationMin} onChange={set('durationMin')}>
          {[15, 30, 45, 60, 75, 90, 120, 150, 180].map((m) => <option key={m} value={m}>{m} min</option>)}
        </select>
      </label>
      <label className="w-desc">Descrição<input value={f.description} onChange={set('description')} maxLength={240} /></label>
      <label className="w-check"><input type="checkbox" checked={f.active} onChange={set('active')} /> Visível</label>
      <div className="row__btns">
        <button className="btn btn--primary btn--sm"><span>{isNew ? 'Adicionar' : 'Salvar'}</span></button>
        {!isNew && <button type="button" className="btn btn--danger btn--sm" onClick={remove}><span>Excluir</span></button>}
      </div>
    </form>
  );
}

export function Services({ call, notify }) {
  const [items, load] = useList(call, notify, '/api/admin/services', 'services');
  return (
    <section>
      <div className="adm__head">
        <h1>Serviços e preços</h1>
        <p>As alterações aparecem no site e na tela de agendamento imediatamente.</p>
      </div>
      <div className="rows">
        {items?.map((s) => <ServiceRow key={`${s.id}-${s.priceCents}-${s.name}`} item={s} call={call} notify={notify} reload={load} />)}
      </div>
      <h2 className="adm__sub">Novo serviço</h2>
      <ServiceRow key={`new-${items?.length}`} item={{ name: '', description: '', priceCents: 5000, durationMin: 30, active: true }} call={call} notify={notify} reload={load} />
    </section>
  );
}

/* ------------------------------- barbeiros ------------------------------- */

function BarberRow({ item, call, notify, reload }) {
  const isNew = !item.id;
  const [f, setF] = useState({
    name: item.name,
    role: item.role,
    bio: item.bio,
    specialties: item.specialties.join(', '),
    photoUrl: item.photoUrl,
    active: item.active,
  });
  const [errors, setErrors] = useState({});
  const set = (k) => (e) => setF((v) => ({ ...v, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  async function save(e) {
    e.preventDefault();
    setErrors({});
    try {
      await call(isNew ? '/api/admin/barbers' : `/api/admin/barbers/${item.id}`, { method: isNew ? 'POST' : 'PUT', body: f });
      notify(isNew ? 'Barbeiro adicionado.' : 'Barbeiro salvo.');
      reload();
    } catch (err) {
      setErrors(err.fields || {});
      notify(err.message, 'err');
    }
  }

  async function remove() {
    if (!window.confirm(`Remover ${item.name}? Se houver histórico, ele será apenas desativado.`)) return;
    try {
      const r = await call(`/api/admin/barbers/${item.id}`, { method: 'DELETE' });
      notify(r?.deactivated ? 'Barbeiro desativado (tem histórico).' : 'Barbeiro removido.');
      reload();
    } catch (err) {
      notify(err.message, 'err');
    }
  }

  return (
    <form className={`row row--barber ${f.active ? '' : 'is-off'}`} onSubmit={save}>
      <label className="w-name">Nome<input value={f.name} onChange={set('name')} required />{errors.name && <small className="err">{errors.name}</small>}</label>
      <label className="w-name">Função<input value={f.role} onChange={set('role')} placeholder="Mestre barbeiro" /></label>
      <label className="w-desc">Especialidades (separe por vírgula)<input value={f.specialties} onChange={set('specialties')} /></label>
      <label className="w-desc">Foto (opcional, https:// ou /equipe/foto.jpg)<input value={f.photoUrl} onChange={set('photoUrl')} />{errors.photoUrl && <small className="err">{errors.photoUrl}</small>}</label>
      <label className="w-full">Apresentação<textarea rows={2} value={f.bio} onChange={set('bio')} maxLength={400} /></label>
      <label className="w-check"><input type="checkbox" checked={f.active} onChange={set('active')} /> Atende clientes</label>
      <div className="row__btns">
        <button className="btn btn--primary btn--sm"><span>{isNew ? 'Adicionar' : 'Salvar'}</span></button>
        {!isNew && <button type="button" className="btn btn--danger btn--sm" onClick={remove}><span>Remover</span></button>}
      </div>
    </form>
  );
}

export function Barbers({ call, notify }) {
  const [items, load] = useList(call, notify, '/api/admin/barbers', 'barbers');
  return (
    <section>
      <div className="adm__head">
        <h1>Barbeiros</h1>
        <p>Quem está “Atende clientes” aparece no site e na agenda.</p>
      </div>
      <div className="rows">
        {items?.map((b) => <BarberRow key={`${b.id}-${b.name}-${b.bio}`} item={b} call={call} notify={notify} reload={load} />)}
      </div>
      <h2 className="adm__sub">Novo barbeiro</h2>
      <BarberRow key={`new-${items?.length}`} item={{ name: '', role: '', bio: '', specialties: [], photoUrl: '', active: true }} call={call} notify={notify} reload={load} />
    </section>
  );
}
