import { useEffect, useState } from 'react';
import { WEEKDAYS, dayMonth } from '../../lib/format.js';

export default function Settings({ call, notify }) {
  const [s, setS] = useState(null);
  const [errors, setErrors] = useState({});
  const [newDate, setNewDate] = useState('');

  useEffect(() => {
    call('/api/admin/settings')
      .then(({ settings }) => setS(settings))
      .catch((err) => notify(err.message, 'err'));
  }, [call, notify]);

  if (!s) return <p className="adm__empty">Carregando…</p>;

  const set = (k) => (e) => setS((v) => ({ ...v, [k]: e.target.value }));
  const setHour = (d, patch) => setS((v) => ({ ...v, hours: { ...v.hours, [d]: patch === null ? null : { ...(v.hours[d] || { open: '09:00', close: '18:00' }), ...patch } } }));

  async function save(e) {
    e.preventDefault();
    setErrors({});
    try {
      const { settings } = await call('/api/admin/settings', { method: 'PUT', body: s });
      setS(settings);
      notify('Configurações salvas.');
    } catch (err) {
      setErrors(err.fields || {});
      notify(err.message, 'err');
    }
  }

  return (
    <form onSubmit={save}>
      <div className="adm__head">
        <h1>Horários e contato</h1>
        <p>Define o que aparece no site, no Google e quais horários podem ser reservados.</p>
      </div>

      <div className="adm__grid">
        <fieldset className="adm-card">
          <legend>Dados da barbearia</legend>
          <label>Nome<input value={s.businessName} onChange={set('businessName')} />{errors.businessName && <small className="err">{errors.businessName}</small>}</label>
          <label>Frase de destaque<input value={s.tagline} onChange={set('tagline')} /></label>
          <label>Endereço<input value={s.address} onChange={set('address')} />{errors.address && <small className="err">{errors.address}</small>}</label>
          <label>Telefone exibido<input value={s.phone} onChange={set('phone')} /></label>
          <label>WhatsApp (DDD + número)<input value={s.whatsapp} onChange={set('whatsapp')} inputMode="tel" />{errors.whatsapp && <small className="err">{errors.whatsapp}</small>}</label>
          <label>Instagram (usuário)<input value={s.instagram} onChange={set('instagram')} />{errors.instagram && <small className="err">{errors.instagram}</small>}</label>
        </fieldset>

        <fieldset className="adm-card">
          <legend>Horário de funcionamento</legend>
          {WEEKDAYS.map((name, d) => {
            const h = s.hours[d];
            return (
              <div className="hrow" key={d}>
                <span>{name}</span>
                <label className="w-check"><input type="checkbox" checked={!h} onChange={(e) => setHour(d, e.target.checked ? null : {})} /> Fechado</label>
                <input type="time" aria-label={`${name}: abre`} value={h?.open || ''} disabled={!h} onChange={(e) => setHour(d, { open: e.target.value })} />
                <input type="time" aria-label={`${name}: fecha`} value={h?.close || ''} disabled={!h} onChange={(e) => setHour(d, { close: e.target.value })} />
              </div>
            );
          })}
          {errors.hours && <small className="err">{errors.hours}</small>}
        </fieldset>

        <fieldset className="adm-card">
          <legend>Regras da agenda</legend>
          <label>Intervalo entre horários
            <select value={s.intervalMin} onChange={set('intervalMin')}>
              {[15, 30, 60].map((m) => <option key={m} value={m}>{m} minutos</option>)}
            </select>
          </label>
          <label>Agenda aberta para os próximos (dias)<input type="number" min="1" max="90" value={s.maxDaysAhead} onChange={set('maxDaysAhead')} />{errors.maxDaysAhead && <small className="err">{errors.maxDaysAhead}</small>}</label>
          <label>Antecedência mínima (minutos)<input type="number" min="0" max="1440" step="15" value={s.minNoticeMin} onChange={set('minNoticeMin')} />{errors.minNoticeMin && <small className="err">{errors.minNoticeMin}</small>}</label>
        </fieldset>

        <fieldset className="adm-card">
          <legend>Feriados e dias fechados</legend>
          <div className="hrow">
            <input type="date" value={newDate} onChange={(e) => setNewDate(e.target.value)} />
            <button type="button" className="btn btn--ghost btn--sm" disabled={!newDate || s.closedDates.includes(newDate)} onClick={() => { setS((v) => ({ ...v, closedDates: [...v.closedDates, newDate].sort() })); setNewDate(''); }}><span>Adicionar</span></button>
          </div>
          <ul className="chips">
            {s.closedDates.length === 0 && <li className="muted">Nenhum dia bloqueado.</li>}
            {s.closedDates.map((d) => (
              <li key={d}>{dayMonth(d)}/{d.slice(0, 4)} <button type="button" aria-label={`Remover ${d}`} onClick={() => setS((v) => ({ ...v, closedDates: v.closedDates.filter((x) => x !== d) }))}>×</button></li>
            ))}
          </ul>
        </fieldset>
      </div>

      <div className="adm__save"><button className="btn btn--primary"><span>Salvar configurações</span></button></div>
    </form>
  );
}
