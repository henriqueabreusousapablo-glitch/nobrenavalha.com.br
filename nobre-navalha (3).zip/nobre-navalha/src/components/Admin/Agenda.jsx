import { useCallback, useEffect, useState } from 'react';
import { addDays, brl, formatPhone, longDate, showCode, utcDate } from '../../lib/format.js';
import { shopNow } from '../../lib/hours.js';

const STATUS = { confirmed: 'Confirmado', done: 'Concluído', cancelled: 'Cancelado', no_show: 'Faltou' };

export default function Agenda({ call, notify }) {
  const today = shopNow('America/Sao_Paulo').date;
  const [from, setFrom] = useState(today);
  const [to, setTo] = useState(addDays(today, 30));
  const [status, setStatus] = useState('');
  const [q, setQ] = useState('');
  const [rows, setRows] = useState(null);

  const load = useCallback(async () => {
    const params = new URLSearchParams({ from, to });
    if (status) params.set('status', status);
    if (q.trim()) params.set('q', q.trim());
    try {
      const { appointments } = await call(`/api/admin/appointments?${params}`);
      setRows(appointments);
    } catch (err) {
      notify(err.message, 'err');
    }
  }, [call, from, to, status, q, notify]);

  useEffect(() => {
    const t = setTimeout(load, 200);
    return () => clearTimeout(t);
  }, [load]);

  async function setState(id, next) {
    try {
      await call(`/api/admin/appointments/${id}`, { method: 'PATCH', body: { status: next } });
      notify('Agendamento atualizado.');
      load();
    } catch (err) {
      notify(err.message, 'err');
    }
  }

  const grouped = (rows || []).reduce((acc, r) => {
    (acc[r.date] ||= []).push(r);
    return acc;
  }, {});
  const active = (rows || []).filter((r) => r.status === 'confirmed');
  const revenue = (rows || []).filter((r) => r.status === 'done' || r.status === 'confirmed').reduce((s, r) => s + r.priceCents, 0);

  return (
    <section>
      <div className="adm__head">
        <h1>Agenda</h1>
        <p>{rows ? `${active.length} confirmados no período · previsão ${brl(revenue)}` : 'Carregando…'}</p>
      </div>
      <div className="adm__filters">
        <label>De<input type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
        <label>Até<input type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label>
        <label>Situação
          <select value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="">Todas</option>
            {Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
          </select>
        </label>
        <label className="grow">Buscar<input type="search" placeholder="Nome, telefone ou código" value={q} onChange={(e) => setQ(e.target.value)} /></label>
      </div>

      {rows && rows.length === 0 && <p className="adm__empty">Nenhum agendamento neste período.</p>}
      {Object.entries(grouped).map(([date, list]) => (
        <div key={date} className="adm__day">
          <h2 className="cap">{longDate(date)}{date === today ? ' · hoje' : ''}</h2>
          <ul>
            {list.map((r) => (
              <li key={r.id} className={`appt appt--${r.status}`}>
                <div className="appt__time"><b>{r.time}</b><span>{r.endTime}</span></div>
                <div className="appt__main">
                  <b>{r.customerName}</b>
                  <span>{r.serviceName} · {r.barberName} · {brl(r.priceCents)}</span>
                  <span>
                    <a href={`https://wa.me/55${r.customerPhone}`} target="_blank" rel="noopener noreferrer">{formatPhone(r.customerPhone)}</a> · código {showCode(r.code)}
                  </span>
                </div>
                <div className="appt__side">
                  <span className={`pill pill--${r.status}`}>{STATUS[r.status]}</span>
                  <div className="appt__btns">
                    {r.status === 'confirmed' && (
                      <>
                        <button className="btn btn--ghost btn--sm" onClick={() => setState(r.id, 'done')}><span>Concluir</span></button>
                        <button className="btn btn--ghost btn--sm" onClick={() => setState(r.id, 'no_show')}><span>Faltou</span></button>
                        <button className="btn btn--danger btn--sm" onClick={() => window.confirm(`Cancelar o horário de ${r.customerName}?`) && setState(r.id, 'cancelled')}><span>Cancelar</span></button>
                      </>
                    )}
                    {r.status !== 'confirmed' && (
                      <button className="btn btn--ghost btn--sm" onClick={() => setState(r.id, 'confirmed')}><span>Reativar</span></button>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </section>
  );
}
