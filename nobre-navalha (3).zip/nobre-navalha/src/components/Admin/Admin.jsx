import { useCallback, useEffect, useState } from 'react';
import { api } from '../../lib/api.js';
import { Wordmark } from '../icons.jsx';
import Agenda from './Agenda.jsx';
import { Services, Barbers } from './Catalog.jsx';
import Settings from './Settings.jsx';

const TABS = [
  ['agenda', 'Agenda'],
  ['servicos', 'Serviços e preços'],
  ['equipe', 'Barbeiros'],
  ['config', 'Horários e contato'],
];

const KEY = 'nn:admin-token';
const read = () => {
  try {
    return sessionStorage.getItem(KEY) || '';
  } catch {
    return '';
  }
};

function Login({ onLogin }) {
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setError('');
    try {
      const { token } = await api('/api/admin/login', { method: 'POST', body: { password } });
      try {
        sessionStorage.setItem(KEY, token);
      } catch {
        /* sessão só em memória */
      }
      onLogin(token);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="adm-login">
      <form onSubmit={submit} className="adm-card">
        <Wordmark />
        <h1>Painel da barbearia</h1>
        <p>Entre para ver a agenda e editar serviços, preços, equipe e horários.</p>
        <div className="field">
          <label htmlFor="pw">Senha</label>
          <input id="pw" type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} autoFocus />
        </div>
        {error && <p className="err" role="alert">{error}</p>}
        <button className="btn btn--primary" disabled={busy || !password}><span>{busy ? 'Entrando…' : 'Entrar'}</span></button>
        <a className="link" href="/">← Voltar ao site</a>
      </form>
    </main>
  );
}

export default function Admin() {
  const [token, setToken] = useState(read);
  const [tab, setTab] = useState('agenda');
  const [toast, setToast] = useState(null);

  const logout = useCallback(() => {
    try {
      sessionStorage.removeItem(KEY);
    } catch {
      /* ignora */
    }
    setToken('');
  }, []);

  /** Chamada autenticada: se a sessão expirar, volta para o login. */
  const call = useCallback(
    async (path, options = {}) => {
      try {
        return await api(path, { ...options, token });
      } catch (err) {
        if (err.status === 401) logout();
        throw err;
      }
    },
    [token, logout],
  );

  const notify = useCallback((text, type = 'ok') => setToast({ text, type, id: Date.now() }), []);
  useEffect(() => {
    if (!toast) return undefined;
    const t = setTimeout(() => setToast(null), 3600);
    return () => clearTimeout(t);
  }, [toast]);

  if (!token) return <Login onLogin={setToken} />;

  const props = { call, notify };
  return (
    <div className="adm">
      <header className="adm__bar">
        <Wordmark />
        <nav className="adm__tabs" aria-label="Seções do painel">
          {TABS.map(([k, label]) => (
            <button key={k} className={tab === k ? 'is-on' : ''} aria-current={tab === k} onClick={() => setTab(k)}>{label}</button>
          ))}
        </nav>
        <div className="adm__right">
          <a className="btn btn--ghost btn--sm" href="/"><span>Ver site</span></a>
          <button className="btn btn--ghost btn--sm" onClick={logout}><span>Sair</span></button>
        </div>
      </header>
      <main className="adm__main">
        {tab === 'agenda' && <Agenda {...props} />}
        {tab === 'servicos' && <Services {...props} />}
        {tab === 'equipe' && <Barbers {...props} />}
        {tab === 'config' && <Settings {...props} />}
      </main>
      {toast && (
        <div key={toast.id} className={`toast toast--${toast.type}`} role="status">{toast.text}</div>
      )}
    </div>
  );
}
