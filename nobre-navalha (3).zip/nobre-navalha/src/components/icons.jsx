const base = { width: 20, height: 20, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.7, strokeLinecap: 'round', strokeLinejoin: 'round', 'aria-hidden': true, focusable: 'false' };

export const IconWhatsApp = ({ size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 32 32" fill="currentColor" aria-hidden="true" focusable="false">
    <path d="M16.04 3C9.4 3 4 8.4 4 15.03c0 2.12.55 4.19 1.6 6.01L4 29l8.1-1.57a12.03 12.03 0 0 0 3.94.66h.01C22.7 28.09 28 22.7 28 16.06 28 9.4 22.68 3 16.04 3Zm0 22.05h-.01c-1.2 0-2.37-.32-3.4-.93l-.24-.15-4.8.93.99-4.68-.16-.25a9.97 9.97 0 0 1-1.54-5.32c0-5.5 4.5-9.97 10.02-9.97 5.5 0 9.97 4.47 9.97 9.98 0 5.5-4.47 10.39-9.97 10.39Zm5.47-7.46c-.3-.15-1.77-.87-2.05-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.22 3.08c.15.2 2.1 3.2 5.08 4.49.71.3 1.26.49 1.7.63.71.23 1.36.2 1.87.12.57-.08 1.77-.72 2.02-1.42.25-.7.25-1.3.17-1.42-.07-.12-.27-.2-.57-.35Z" />
  </svg>
);

export const IconPin = () => (
  <svg {...base}>
    <path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21Z" />
    <circle cx="12" cy="9.5" r="2.5" />
  </svg>
);

export const IconClock = () => (
  <svg {...base}>
    <circle cx="12" cy="12" r="9" />
    <path d="M12 7v5l3.2 2" />
  </svg>
);

export const IconPhone = () => (
  <svg {...base}>
    <path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2Z" />
  </svg>
);

export const IconInstagram = () => (
  <svg {...base}>
    <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
    <circle cx="12" cy="12" r="4" />
    <circle cx="17.2" cy="6.8" r=".6" fill="currentColor" />
  </svg>
);

export const IconCheck = ({ size = 18 }) => (
  <svg {...base} width={size} height={size} strokeWidth={2.2}>
    <path d="m5 12.5 4.5 4.5L19 7.5" />
  </svg>
);

export const IconChevron = ({ dir = 'right' }) => (
  <svg {...base} width={18} height={18} style={{ transform: `rotate(${{ right: 0, down: 90, left: 180, up: 270 }[dir]}deg)` }}>
    <path d="m9 5 7 7-7 7" />
  </svg>
);

export const IconCalendar = () => (
  <svg {...base}>
    <rect x="3.5" y="5" width="17" height="15.5" rx="2.5" />
    <path d="M3.5 10h17M8 3v4M16 3v4" />
  </svg>
);

export const IconScissors = () => (
  <svg {...base}>
    <circle cx="6" cy="6.5" r="2.7" />
    <circle cx="6" cy="17.5" r="2.7" />
    <path d="M8.2 8.1 20 18M8.2 15.9 20 6" />
  </svg>
);

export const IconStar = ({ size = 16 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" focusable="false">
    <path d="m12 2.8 2.8 5.9 6.4.8-4.7 4.4 1.2 6.4L12 17.2l-5.7 3.1 1.2-6.4-4.7-4.4 6.4-.8L12 2.8Z" />
  </svg>
);

export const IconMenu = ({ open }) => (
  <svg {...base} width={24} height={24}>
    {open ? <path d="M6 6l12 12M18 6 6 18" /> : <path d="M4 8h16M4 16h16" />}
  </svg>
);

export const IconWarn = () => (
  <svg {...base}>
    <path d="M12 3.5 2.8 19.5h18.4L12 3.5Z" />
    <path d="M12 10v4.2M12 17h.01" />
  </svg>
);

export const IconDownload = () => (
  <svg {...base}>
    <path d="M12 4v11M7.5 10.5 12 15l4.5-4.5M5 19.5h14" />
  </svg>
);

export const Wordmark = ({ className = '' }) => (
  <span className={`wordmark ${className}`}>
    <svg className="wordmark__mark" viewBox="0 0 40 40" aria-hidden="true" focusable="false">
      <path d="M6 27 28 8c2-1.7 4.6-1 5.6.9l.4.8c.8 1.6.3 3.4-1.1 4.6L10 33c-1.4 1.2-3.2 1-4.2-.4L5 31.6C4.2 30.2 4.6 28.2 6 27Z" fill="currentColor" />
      <path d="M12 31 33 14" stroke="var(--c-bg)" strokeWidth="1.4" strokeLinecap="round" opacity=".55" />
    </svg>
    <span className="wordmark__text">
      Nobre <em>Navalha</em>
    </span>
  </span>
);
