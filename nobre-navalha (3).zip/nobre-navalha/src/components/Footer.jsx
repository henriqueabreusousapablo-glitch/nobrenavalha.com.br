import { useSite } from '../site-context.js';
import { waLink } from '../lib/whatsapp.js';
import { Wordmark } from './icons.jsx';

export default function Footer() {
  const { business } = useSite();
  return (
    <footer className="footer">
      <div className="wrap">
        <div className="footer__grid">
          <div>
            <Wordmark />
            <p className="footer__tag">{business.tagline}.</p>
          </div>
          <nav aria-label="Rodapé">
            <h3>Navegue</h3>
            <ul>
              <li><a href="#servicos">Serviços e preços</a></li>
              <li><a href="#cortes">Galeria de cortes</a></li>
              <li><a href="#barbeiros">Barbeiros</a></li>
              <li><a href="#ciencia">Ciência do fio</a></li>
              <li><a href="#agendar">Agendar horário</a></li>
            </ul>
          </nav>
          <div>
            <h3>Contato</h3>
            <ul>
              <li>{business.address}</li>
              <li>
                <a href={waLink(business.whatsapp)} target="_blank" rel="noopener noreferrer">
                  WhatsApp {business.phone}
                </a>
              </li>
              {business.instagram && (
                <li>
                  <a href={`https://www.instagram.com/${business.instagram}`} target="_blank" rel="noopener noreferrer">
                    @{business.instagram}
                  </a>
                </li>
              )}
            </ul>
          </div>
        </div>
        <div className="footer__legal">
          <span>© {new Date().getFullYear()} {business.businessName}. Todos os direitos reservados.</span>
          <a href="/admin">Área da barbearia</a>
        </div>
      </div>
    </footer>
  );
}
