import { useId } from 'react';
import { useTween } from '../../hooks/useTween.js';

/* Fio de cabelo em corte longitudinal, da raiz (embaixo) até a ponta (em cima).
   Tudo é calculado a partir de dois números: `damage` (0 a 1) e `tipY` (onde o fio termina).
   Assim o mesmo desenho mostra o fio saudável, o desgaste e o fio depois do corte. */

export const VIEW = { w: 440, h: 620 };
const CX = 200;
const W = 38; // meia largura do fio
const CUT = 9; // espessura da cutícula
const WC = W - CUT; // meia largura do córtex
const SKIN = 480; // linha da pele
const SP = 20; // distância entre escamas
export const PX_PER_CM = 100;

const clamp = (v, a = 0, b = 1) => Math.min(b, Math.max(a, v));
const smooth = (v, a, b) => {
  const t = clamp((v - a) / (b - a));
  return t * t * (3 - 2 * t);
};
const hash = (i, s) => {
  const x = Math.sin(i * 12.9898 + s * 78.233) * 43758.5453;
  return x - Math.floor(x);
};
const mix = (a, b, t) => {
  const pa = a.match(/\w\w/g).map((h) => parseInt(h, 16));
  const pb = b.match(/\w\w/g).map((h) => parseInt(h, 16));
  return `rgb(${pa.map((v, i) => Math.round(v + (pb[i] - v) * t)).join(',')})`;
};

export const damageLength = (d) => 44 + 150 * d;
export const splitLength = (d) => 150 * smooth(d, 0.32, 0.85);

function Prong({ side, len, wp, ang, d, cortexFill }) {
  const off = side * wp * 0.85;
  const teeth = 5;
  const top = [];
  for (let t = 0; t <= teeth; t += 1) {
    const x = off - wp + (t * (2 * wp)) / teeth;
    const y = -len - (t % 2 ? 0 : 7 + hash(t, side) * 10 * d);
    top.push(`${x.toFixed(1)} ${y.toFixed(1)}`);
  }
  const outline = `M${off - wp} 4 L${top.join(' L')} L${off + wp} 4 Z`;
  const fibres = [-0.55, 0, 0.55].map((f, k) => {
    const x = off + f * wp;
    const spread = f * 9 * d;
    return (
      <path
        key={k}
        d={`M${x} 2 C${x} ${-len * 0.4} ${x + spread * 0.4} ${-len * 0.7} ${x + spread} ${-len - 4 - hash(k, side) * 12}`}
        fill="none"
        stroke="#e0b98a"
        strokeOpacity=".75"
        strokeWidth="2"
        strokeLinecap="round"
      />
    );
  });
  const frays = [0, 1, 2, 3].map((k) => {
    const x = off - wp * 0.7 + k * wp * 0.46;
    const y = -len - 6;
    return <path key={k} d={`M${x} ${y} l${(k - 1.5) * 4} ${-9 - hash(k, side + 3) * 10}`} stroke="#d9b58a" strokeWidth="1.6" strokeLinecap="round" opacity=".85" />;
  });
  const flakes = [0.25, 0.5, 0.75].map((f, k) => (
    <path key={k} d={`M${off - side * wp} ${-len * f} l${-side * (6 + 8 * d)} ${-8}`} stroke="#7a4f2e" strokeWidth="3" strokeLinecap="round" />
  ));
  return (
    <g transform={`translate(${CX} 0) rotate(${side * ang} 0 0)`}
    >
      <g>
        <path d={outline} fill={cortexFill} stroke="#7a4f2e" strokeWidth="3" strokeLinejoin="round" />
        {fibres}
        {flakes}
        {frays}
      </g>
    </g>
  );
}

function Body({ tipY, d, focusClass }) {
  const splitLen = splitLength(d) * (tipY < SKIN - 260 ? 1 : 0.6);
  const hasSplit = splitLen > 3;
  const ySplit = Math.min(tipY + splitLen, SKIN - 90);
  const shaftTop = hasSplit ? ySplit : tipY;
  const cortexFill = mix('#9a6844', '#c79a68', d * 0.9);
  const cortexDeep = mix('#6f4529', '#a97c4e', d * 0.9);
  const scales = [];

  for (let side = -1; side <= 1; side += 2) {
    for (let i = 0; y(i) > shaftTop + 6; i += 1) {
      const yy = y(i);
      const u = clamp((SKIN - yy) / (SKIN - tipY));
      const local = d * u ** 1.5;
      const chipped = yy < SKIN && local > 0.5 && hash(i, side) < local - 0.28;
      const lift = yy >= SKIN ? 0 : 1 + 18 * local * (0.7 + hash(i + 9, side) * 0.6);
      if (chipped) {
        scales.push(<path key={`c${side}${i}`} d={`M${CX + side * (W - CUT)} ${yy + 3} l${side * 5} -${SP * 0.55} l-${side * 2} -${SP * 0.45}`} fill="none" stroke="#7a4f2e" strokeWidth="2" strokeLinecap="round" opacity=".6" />);
        continue;
      }
      const xi = CX + side * (W - CUT - 2);
      const xo = CX + side * W;
      const tipX = CX + side * (W + lift);
      const tipYY = yy - SP * 1.35;
      scales.push(
        <path
          key={`${side}${i}`}
          d={`M${xi} ${yy + 4} L${xo} ${yy + 4} L${tipX} ${tipYY} L${xi + side * lift * 0.35} ${tipYY + 3} Z`}
          fill={mix('#c9a45c', '#9a7a42', local)}
          stroke="#5b3f1e"
          strokeWidth="1.2"
          strokeLinejoin="round"
          opacity={yy >= SKIN ? 0.7 : 1}
        />,
      );
    }
  }
  function y(i) {
    return SKIN + 36 - i * SP;
  }

  // fibras do córtex: separam-se perto da ponta quando há dano
  const fibres = [-2, -1, 0, 1, 2].map((j) => {
    const pts = [];
    for (let yy = SKIN + 60; yy >= shaftTop + 2; yy -= 16) {
      const u = clamp((SKIN - yy) / (SKIN - tipY));
      const local = d * u ** 1.5;
      const x = CX + j * 10 + Math.sin(yy * 0.045 + j * 1.7) * 1.8 + j * local * 7 + (hash(Math.round(yy), j) - 0.5) * local * 5;
      pts.push(`${x.toFixed(1)} ${yy}`);
    }
    return <polyline key={j} points={pts.join(' ')} fill="none" stroke="#d2a273" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" opacity=".55" />;
  });

  // grânulos de melanina
  const granules = Array.from({ length: 46 }, (_, k) => {
    const gy = shaftTop + 8 + hash(k, 5) * (SKIN + 56 - shaftTop - 12);
    const gx = CX + (hash(k, 7) - 0.5) * (WC * 1.7);
    return <circle key={k} cx={gx} cy={gy} r={1 + hash(k, 3) * 1.6} fill="#2e1b10" opacity=".55" />;
  });

  return (
    <g className={focusClass}>
      {/* córtex */}
      <g className="layer layer--cortex">
        <rect x={CX - WC} y={shaftTop} width={WC * 2} height={SKIN + 60 - shaftTop} rx={hasSplit ? 0 : 8} fill={cortexFill} />
        <rect x={CX - WC} y={shaftTop} width={WC * 0.9} height={SKIN + 60 - shaftTop} fill={cortexDeep} opacity=".28" />
        {fibres}
        {granules}
      </g>
      {/* medula */}
      <g className="layer layer--medulla">
        <rect x={CX - 5} y={shaftTop + (hasSplit ? 0 : 26)} width="10" height={SKIN + 60 - shaftTop - (hasSplit ? 0 : 26)} fill="#2a1a10" opacity=".7" />
        {Array.from({ length: Math.max(0, Math.floor((SKIN + 60 - shaftTop) / 14)) }, (_, k) => (
          <rect key={k} x={CX - 3} y={shaftTop + 30 + k * 14} width="6" height="5" rx="2" fill="#e9d3b0" opacity=".55" />
        ))}
      </g>
      {/* cutícula */}
      <g className="layer layer--cuticle">
        <rect x={CX - W} y={shaftTop} width={CUT} height={SKIN + 60 - shaftTop} fill="#6b4a22" opacity=".85" />
        <rect x={CX + WC} y={shaftTop} width={CUT} height={SKIN + 60 - shaftTop} fill="#6b4a22" opacity=".85" />
        {scales}
      </g>

      {hasSplit && (
        <g transform={`translate(0 ${ySplit})`}>
          <Prong side={-1} len={splitLen} wp={W * 0.5} ang={5 + 15 * d} d={d} cortexFill={cortexFill} />
          <Prong side={1} len={splitLen} wp={W * 0.5} ang={5 + 15 * d} d={d} cortexFill={cortexFill} />
        </g>
      )}
    </g>
  );
}

export default function HairStrand({ damage, tipY, focus, effect, cutting, onFocus }) {
  const id = useId().replace(/:/g, '');
  const d = useTween(damage, 900);
  const ty = useTween(tipY, 700);
  const cutY = cutting ? cutting.y : 0;
  const focusClass = focus ? `focus-${focus}` : '';
  const splitting = splitLength(d) > 30;
  const labelY = { cuticle: 330, cortex: 252, medulla: 410 };

  return (
    <svg className={`strand-svg ${focusClass} ${effect ? `fx-${effect}` : ''}`} viewBox={`0 0 ${VIEW.w} ${VIEW.h}`} role="img" aria-label="Corte longitudinal de um fio de cabelo: cutícula, córtex e medula, da raiz à ponta.">
      <defs>
        <clipPath id={`below-${id}`}><rect x="0" y={cutY} width={VIEW.w} height={VIEW.h} /></clipPath>
        <clipPath id={`above-${id}`}><rect x="0" y="-80" width={VIEW.w} height={cutY + 80} /></clipPath>
        <linearGradient id={`skin-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#c68e68" />
          <stop offset=".18" stopColor="#8d5b41" />
          <stop offset="1" stopColor="#3b261b" />
        </linearGradient>
        <linearGradient id={`blade-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#fff" />
          <stop offset=".5" stopColor="#bdb7ac" />
          <stop offset="1" stopColor="#7d786f" />
        </linearGradient>
        <radialGradient id={`heat-${id}`} cx="50%" cy="35%" r="60%">
          <stop offset="0" stopColor="#ff7a3c" stopOpacity=".55" />
          <stop offset="1" stopColor="#ff7a3c" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* pele e folículo */}
      <g className="skin">
        <rect x="0" y={SKIN} width={VIEW.w} height={VIEW.h - SKIN} fill={`url(#skin-${id})`} />
        <path d={`M${CX - 46} ${SKIN} C${CX - 54} ${SKIN + 70} ${CX - 56} ${SKIN + 100} ${CX} ${SKIN + 118} C${CX + 56} ${SKIN + 100} ${CX + 54} ${SKIN + 70} ${CX + 46} ${SKIN} Z`} fill="#2a1913" opacity=".7" />
        <circle cx={CX} cy={SKIN + 98} r="30" fill="#e7c9a4" opacity=".25" />
        <path d={`M0 ${SKIN} H${VIEW.w}`} stroke="#e8c9a6" strokeWidth="2" opacity=".6" />
      </g>

      {/* fio */}
      <g clipPath={cutting ? `url(#below-${id})` : undefined}>
        <Body tipY={ty} d={d} focusClass={focusClass} />
      </g>
      {cutting && (
        <g className="piece" clipPath={`url(#above-${id})`}>
          <Body tipY={cutting.tipY} d={cutting.d} focusClass="" />
        </g>
      )}

      {/* efeitos */}
      {effect === 'heat' && (
        <g className="fx fx--heat" aria-hidden="true">
          <ellipse cx={CX} cy={ty + 60} rx="170" ry="300" fill={`url(#heat-${id})`} />
          {[-70, -35, 35, 70].map((dx, k) => (
            <path key={dx} className="wave" style={{ '--k': k }} d={`M${CX + dx} ${SKIN - 40} q10 -22 0 -44 t0 -44 t0 -44 t0 -44`} fill="none" stroke="#ff9a5c" strokeWidth="3" strokeLinecap="round" />
          ))}
          {[0, 1, 2, 3, 4].map((k) => (
            <circle key={k} className="drop" style={{ '--k': k }} cx={CX - 16 + k * 8} cy={SKIN - 70} r="3.2" fill="#8fd0ff" />
          ))}
        </g>
      )}
      {effect === 'rub' && (
        <g className="fx fx--rub" aria-hidden="true">
          <g className="brush">
            {Array.from({ length: 9 }, (_, k) => (
              <path key={k} d={`M${CX - 130 + k * 9} 0 l-14 70`} stroke="#d9d3c6" strokeWidth="4" strokeLinecap="round" />
            ))}
            <rect x={CX - 144} y="-14" width="96" height="16" rx="8" fill="#5a4636" />
          </g>
          {[0, 1, 2, 3].map((k) => (
            <rect key={k} className="flake" style={{ '--k': k }} x={CX + 20 + k * 9} y={SKIN - 200 - k * 20} width="7" height="3" rx="1.5" fill="#c9a45c" />
          ))}
        </g>
      )}

      {/* lâmina do corte */}
      {cutting && (
        <g className="blade" style={{ '--y': `${cutY}px` }} aria-hidden="true">
          <path d={`M${CX + 220} ${cutY - 7} L${CX - 210} ${cutY - 3} L${CX - 250} ${cutY + 1} L${CX - 210} ${cutY + 5} L${CX + 220} ${cutY + 9} Z`} fill={`url(#blade-${id})`} stroke="#fff" strokeOpacity=".6" />
          <path d={`M${CX - 250} ${cutY + 1} L${CX + 220} ${cutY + 1}`} stroke="#fff" strokeWidth="1.5" opacity=".9" />
        </g>
      )}

      {/* rótulos clicáveis */}
      <g className="labels">
        {[
          ['cuticle', 'Cutícula', 'escamas que protegem', CX + W - 3, labelY.cuticle],
          ['cortex', 'Córtex', 'força, cor e elasticidade', CX + 14, labelY.cortex],
          ['medulla', 'Medula', 'núcleo do fio', CX, labelY.medulla],
        ].map(([key, title, sub, px, py]) => (
          <g
            key={key}
            className={`label ${focus === key ? 'is-on' : ''}`}
            role="button"
            tabIndex={0}
            aria-pressed={focus === key}
            aria-label={`${title}: ${sub}`}
            onClick={() => onFocus(focus === key ? null : key)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onFocus(focus === key ? null : key);
              }
            }}
          >
            <path d={`M${px} ${py} L${W + CX + 40} ${py} L${W + CX + 56} ${py}`} fill="none" />
            <circle cx={px} cy={py} r="4.5" />
            <rect className="hit" x={W + CX + 50} y={py - 24} width="170" height="48" rx="8" />
            <text x={W + CX + 62} y={py - 2}>{title}</text>
            <text x={W + CX + 62} y={py + 16} className="sub">{sub}</text>
          </g>
        ))}
        <g className="note">
          <text x="14" y={SKIN - 12}>Superfície da pele</text>
          <text x="14" y={SKIN + 108}>Folículo: aqui o fio nasce</text>
          <text x="14" y={SKIN + 126} className="sub">e cresce, na raiz</text>
        </g>
        {splitting && (
          <g className="note note--warn">
            <text x="14" y={ty + 18}>Ponta dupla</text>
            <text x="14" y={ty + 36} className="sub">fibras do córtex se abrem</text>
          </g>
        )}
        {!splitting && ty < 200 && (
          <g className="note">
            <text x="14" y={ty + 20}>Ponta: a parte</text>
            <text x="14" y={ty + 38} className="sub">mais antiga do fio</text>
          </g>
        )}
      </g>
    </svg>
  );
}
