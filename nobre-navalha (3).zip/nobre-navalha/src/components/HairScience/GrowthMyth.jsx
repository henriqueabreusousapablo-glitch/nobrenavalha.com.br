import { useState } from 'react';

const RATE = 1.25; // cm por mês, em média
const BASE = 8; // comprimento inicial (cm)
const PX = 8.5;
const GROUND = 222;

function Hair({ label, length, cuts }) {
  const h = length * PX;
  return (
    <figure className="gm__hair">
      <svg viewBox="0 0 120 262" role="img" aria-label={`${label}: ${length.toFixed(1).replace('.', ',')} cm`}>
        <rect x="0" y={GROUND} width="120" height="40" fill="#3b261b" />
        <rect x="0" y={GROUND - 2} width="120" height="3" fill="#c68e68" />
        <circle cx="60" cy={GROUND + 24} r="9" fill="#e7c9a4" opacity=".35" />
        <path
          d={`M60 ${GROUND + 8} L60 ${Math.max(6, GROUND - h)}`}
          stroke="#c9a45c"
          strokeWidth="5"
          strokeLinecap="round"
          style={{ transition: 'all .45s cubic-bezier(.22,1,.36,1)' }}
        />
        {Array.from({ length: Math.floor(length) }, (_, k) => (
          <path key={k} d={`M70 ${GROUND - (k + 1) * PX} h6`} stroke="#b5a798" strokeWidth="1" opacity=".5" />
        ))}
        {cuts.map((c, k) => (
          <g key={k} opacity=".85">
            <path d={`M42 ${GROUND - c * PX} h36`} stroke="#e8756d" strokeWidth="1.5" strokeDasharray="3 3" />
          </g>
        ))}
        <g transform={`translate(60 ${GROUND + 24})`}>
          <path d="M0 -10 V10" stroke="#8bbf72" strokeWidth="2" strokeDasharray="2 3" />
        </g>
      </svg>
      <figcaption>
        <b>{label}</b>
        <span>{length.toFixed(1).replace('.', ',')} cm</span>
      </figcaption>
    </figure>
  );
}

export default function GrowthMyth() {
  const [months, setMonths] = useState(4);
  const grown = months * RATE;
  const trimEvery = 2;
  const trimCm = 1;
  const nCuts = Math.floor(months / trimEvery);
  const withCuts = BASE + grown - nCuts * trimCm;

  // linhas pontilhadas marcam onde cada corte aconteceu (comprimento do fio naquele momento)
  const marks = [];
  for (let k = 1; k <= nCuts; k += 1) marks.push(BASE + k * trimEvery * RATE - (k - 1) * trimCm - trimCm);

  return (
    <div className="gm">
      <div className="gm__head">
        <h3>Mito: “cortar o cabelo faz crescer mais rápido”</h3>
        <p>
          <b>Não faz.</b> O fio nasce e cresce no <em>folículo</em>, debaixo da pele. O que fica para fora é queratina sem vida,
          sem nervos nem circulação, então cortar a ponta não manda nenhum sinal para a raiz. A velocidade depende de genética,
          hormônios, nutrição e saúde, e fica em torno de 1 a 1,5 cm por mês.
        </p>
      </div>

      <div className="gm__stage">
        <Hair label="Sem cortar" length={BASE + grown} cuts={[]} />
        <Hair label="Corte regular" length={withCuts} cuts={marks} />
        <div className="gm__stats">
          <div>
            <span>Tempo</span>
            <b>{months} {months === 1 ? 'mês' : 'meses'}</b>
          </div>
          <div className="is-ok">
            <span>Crescimento na raiz</span>
            <b>{grown.toFixed(1).replace('.', ',')} cm</b>
            <small>igual nos dois fios</small>
          </div>
          <div>
            <span>Diferença no comprimento</span>
            <b>{(nCuts * trimCm).toFixed(0)} cm</b>
            <small>vem só do que foi cortado</small>
          </div>
        </div>
      </div>

      <label className="range">
        <span>Passar o tempo: <b>{months} {months === 1 ? 'mês' : 'meses'}</b> (corte de 1 cm a cada 2 meses)</span>
        <input type="range" min="0" max="12" step="1" value={months} onChange={(e) => setMonths(Number(e.target.value))} />
      </label>
      <p className="gm__fine">Média ilustrativa de 1,25 cm/mês. O ritmo real varia de pessoa para pessoa.</p>
    </div>
  );
}
