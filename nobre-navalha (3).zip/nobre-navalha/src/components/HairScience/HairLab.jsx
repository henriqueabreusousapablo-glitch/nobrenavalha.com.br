import { useCallback, useEffect, useRef, useState } from 'react';
import { Reveal } from '../../hooks/useReveal.jsx';
import CutHead from '../CutHead.jsx';
import HairStrand, { PX_PER_CM, damageLength } from './HairStrand.jsx';
import GrowthMyth from './GrowthMyth.jsx';
import { IconCheck } from '../icons.jsx';

const TIP0 = 70;

const STAGES = [
  {
    key: 'saudavel',
    label: 'Fio saudável',
    d: 0,
    effect: null,
    title: 'Um fio saudável é uma estrutura em camadas',
    text: 'A cutícula é feita de escamas sobrepostas, como telhas, que ficam deitadas e refletem a luz: é o brilho. Sob ela, o córtex dá resistência, elasticidade e cor. No centro, nem todo fio tem a medula.',
    tip: 'Toque nos rótulos do desenho para destacar cada camada.',
  },
  {
    key: 'calor',
    label: 'Calor',
    d: 0.3,
    effect: 'heat',
    title: 'O calor levanta as escamas e seca o córtex',
    text: 'Secador muito perto, chapinha e água quente demais fazem a cutícula se abrir e a água de dentro do fio evaporar. O fio fica áspero, opaco e perde elasticidade, principalmente nas pontas.',
    tip: 'Use temperatura média e protetor térmico.',
  },
  {
    key: 'atrito',
    label: 'Atrito',
    d: 0.58,
    effect: 'rub',
    title: 'O atrito lasca a cutícula',
    text: 'Toalha esfregando, escova puxada com força, boné, gola e travesseiro áspero raspam as escamas até que lasquem e caiam. O córtex fica exposto e o fio quebra com mais facilidade.',
    tip: 'Seque com toalha de microfibra, apertando em vez de esfregar.',
  },
  {
    key: 'pontas',
    label: 'Pontas duplas',
    d: 0.93,
    effect: null,
    title: 'Sem proteção, o fio se abre em pontas duplas',
    text: 'Com a cutícula destruída, as fibras do córtex se separam e a ponta se divide em duas ou mais. Nenhum produto cola de verdade: ele disfarça até a próxima lavagem. E a fenda tende a subir pelo fio.',
    tip: 'A única solução definitiva é cortar a parte aberta.',
  },
  {
    key: 'corte',
    label: 'Depois do corte',
    d: 0.03,
    effect: null,
    cut: true,
    title: 'Cortar remove o que já está danificado',
    text: 'A navalha ou a tesoura eliminam a parte quebrada. O fio volta a ter a ponta uniforme, com mais brilho, menos quebra e penteado mais definido. O corte regular mantém o desenho do seu estilo.',
    tip: 'Cortar não acelera o crescimento: veja o mito logo abaixo.',
  },
];

const stateOf = (d) =>
  d < 0.12 ? ['Excelente', 'ok'] : d < 0.4 ? ['Boa', 'ok'] : d < 0.7 ? ['Em desgaste', 'warn'] : ['Danificada', 'bad'];

export default function HairLab() {
  const [stage, setStage] = useState(0);
  const [damage, setDamage] = useState(0);
  const [tipY, setTipY] = useState(TIP0);
  const [effect, setEffect] = useState(null);
  const [focus, setFocus] = useState(null);
  const [cutting, setCutting] = useState(null);
  const [removed, setRemoved] = useState(0);
  const [playing, setPlaying] = useState(false);
  const timers = useRef([]);
  const state = useRef({ damage: 0, tipY: TIP0 });
  state.current = { damage, tipY };

  const later = useCallback((fn, ms) => {
    const t = setTimeout(fn, ms);
    timers.current.push(t);
  }, []);
  const clearTimers = useCallback(() => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  }, []);
  useEffect(() => clearTimers, [clearTimers]);

  const runCut = useCallback(() => {
    const { damage: d, tipY: ty } = state.current;
    const y = ty + damageLength(d);
    setEffect(null);
    setCutting({ y, tipY: ty, d, phase: 'sweep' });
    later(() => {
      setRemoved((r) => r + (y - ty) / PX_PER_CM);
      setTipY(y);
      setDamage(0.03);
    }, 700);
    later(() => setCutting(null), 1900);
  }, [later]);

  const goStage = useCallback(
    (n, { keepPlaying = false } = {}) => {
      clearTimers();
      if (!keepPlaying) setPlaying(false);
      setCutting(null);
      setStage(n);
      const s = STAGES[n];
      setEffect(s.effect);
      if (s.cut) {
        // vai até o fio bem danificado e só então corta
        if (state.current.tipY !== TIP0 || state.current.damage < 0.8) {
          setTipY(TIP0);
          setDamage(0.93);
          later(runCut, 1400);
        } else later(runCut, 200);
      } else {
        setTipY(TIP0);
        setDamage(s.d);
        if (s.effect) later(() => setEffect(null), 3600);
      }
    },
    [clearTimers, later, runCut],
  );

  // modo "reproduzir história"
  useEffect(() => {
    if (!playing) return undefined;
    const t = setTimeout(() => {
      if (stage >= STAGES.length - 1) setPlaying(false);
      else goStage(stage + 1, { keepPlaying: true });
    }, stage === STAGES.length - 2 ? 5200 : 4600);
    return () => clearTimeout(t);
  }, [playing, stage, goStage]);

  // dispara a história quando a seção aparece pela primeira vez (só se a pessoa permitir movimento)
  const sectionRef = useRef(null);
  useEffect(() => {
    const el = sectionRef.current;
    if (!el || matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          io.disconnect();
          setPlaying(true);
          goStage(1, { keepPlaying: true });
        }
      },
      { threshold: 0.45 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [goStage]);

  const manual = (v) => {
    clearTimers();
    setPlaying(false);
    setCutting(null);
    setEffect(null);
    setTipY(TIP0);
    setDamage(v);
    setStage(-1);
  };

  const apply = (kind) => {
    clearTimers();
    setPlaying(false);
    setStage(-1);
    setEffect(kind);
    setDamage((d) => Math.min(1, d + (kind === 'heat' ? 0.22 : 0.2)));
    later(() => setEffect(null), 2800);
  };

  const reset = () => {
    clearTimers();
    setPlaying(false);
    setRemoved(0);
    goStage(0);
  };

  const current = STAGES[stage] || {
    title: 'Monte o seu próprio cenário',
    text: 'Use o controle de desgaste ou os botões de calor e atrito e acompanhe o que acontece com a cutícula, o córtex e a ponta do fio.',
    tip: 'Quando a ponta abrir, use “Cortar pontas”.',
  };
  const [stateLabel, tone] = stateOf(damage);
  const canCut = damage > 0.12 && !cutting;
  const [weeks, setWeeks] = useState(0);

  return (
    <section className="section lab" id="ciencia" aria-labelledby="ciencia-t" ref={sectionRef}>
      <div className="wrap">
        <div className="section__head">
          <Reveal as="p" className="eyebrow">Ciência do fio</Reveal>
          <Reveal as="h2" id="ciencia-t" className="section__title">
            Por que <em>cortar</em> com regularidade
          </Reveal>
          <Reveal as="p" className="section__lead" delay={100}>
            Veja por dentro de um fio de cabelo, entenda como calor e atrito o desgastam e o que muda quando a ponta danificada sai.
          </Reveal>
        </div>

        <div className="lab__grid">
          <Reveal className="lab__figure" variant="scale">
            <HairStrand damage={damage} tipY={tipY} focus={focus} effect={effect} cutting={cutting} onFocus={setFocus} />
            <div className="lab__meter" aria-live="polite">
              <span>Saúde da ponta</span>
              <div className="meter" role="meter" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round((1 - damage) * 100)} aria-label="Saúde da ponta do fio">
                <i className={`tone-${tone}`} style={{ width: `${Math.round((1 - damage) * 100)}%` }} />
              </div>
              <b className={`tone-${tone}`}>{stateLabel}</b>
            </div>
          </Reveal>

          <div className="lab__panel">
            <div className="stages" role="tablist" aria-label="Etapas da história do fio">
              {STAGES.map((s, n) => (
                <button key={s.key} role="tab" aria-selected={stage === n} className={`stage ${stage === n ? 'is-on' : ''}`} onClick={() => goStage(n)}>
                  <i>{n + 1}</i>
                  <span>{s.label}</span>
                </button>
              ))}
            </div>

            <div className="lab__copy" key={current.title} aria-live="polite">
              <h3>{current.title}</h3>
              <p>{current.text}</p>
              <p className="lab__tip"><IconCheck size={16} /> {current.tip}</p>
            </div>

            <div className="lab__controls">
              <label className="range">
                <span>Nível de desgaste <b>{Math.round(damage * 100)}%</b></span>
                <input type="range" min="0" max="100" value={Math.round(damage * 100)} onChange={(e) => manual(Number(e.target.value) / 100)} aria-label="Nível de desgaste do fio" />
              </label>
              <div className="lab__btns">
                <button className="btn btn--ghost btn--sm" onClick={() => apply('heat')} disabled={Boolean(cutting)}><span>🔥 Aplicar calor</span></button>
                <button className="btn btn--ghost btn--sm" onClick={() => apply('rub')} disabled={Boolean(cutting)}><span>🧽 Aplicar atrito</span></button>
                <button className="btn btn--primary btn--sm" onClick={() => { clearTimers(); setPlaying(false); setStage(-1); runCut(); }} disabled={!canCut}><span>✂ Cortar pontas</span></button>
                <button className="btn btn--ghost btn--sm" onClick={reset}><span>Reiniciar</span></button>
                <button className="btn btn--ghost btn--sm" onClick={() => (playing ? setPlaying(false) : (setPlaying(true), goStage(0, { keepPlaying: true })))} aria-pressed={playing}>
                  <span>{playing ? '❚❚ Pausar história' : '▶ Reproduzir história'}</span>
                </button>
              </div>
              {removed > 0 && (
                <p className="lab__removed" role="status">
                  Removido até aqui: <b>{removed.toFixed(1).replace('.', ',')} cm</b> de ponta danificada. A raiz continua crescendo no mesmo ritmo.
                </p>
              )}
            </div>
          </div>
        </div>

        <div className="why">
          <Reveal as="article" className="why__card" delay={0}>
            <span className="why__n">01</span>
            <h3>Remove as pontas danificadas</h3>
            <p>Pontas duplas não se regeneram e a fenda sobe pelo fio. Aparar a tempo corta o problema antes que ele consuma o comprimento que você queria manter.</p>
            <svg className="why__art" viewBox="0 0 240 110" role="img" aria-label="Comparação: ponta dupla antes do corte e ponta selada depois">
              <g fill="none" strokeLinecap="round" strokeWidth="9">
                <path d="M50 104 V56" stroke="#9a6844" /><path d="M50 56 L34 22" stroke="#9a6844" /><path d="M50 56 L68 18" stroke="#9a6844" />
                <path d="M190 104 V30" stroke="#9a6844" />
              </g>
              <path d="M100 56 H140 M132 48 L142 56 L132 64" fill="none" stroke="#c9a45c" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
              <text x="50" y="12" textAnchor="middle">antes</text>
              <text x="190" y="12" textAnchor="middle">depois</text>
            </svg>
          </Reveal>
          <Reveal as="article" className="why__card" delay={100}>
            <span className="why__n">02</span>
            <h3>Mantém o formato do corte</h3>
            <p>Degradê, risca e contornos são desenhados para um comprimento específico. Com o crescimento, a transição perde contraste e o volume sai do lugar. Arraste e veja.</p>
            <div className="grow">
              <CutHead kind="mid" growth={weeks / 8} label={`Degradê com ${weeks} semanas de crescimento`} />
              <label className="range">
                <span>Desde o corte: <b>{weeks === 0 ? 'dia do corte' : `${weeks} ${weeks === 1 ? 'semana' : 'semanas'}`}</b></span>
                <input type="range" min="0" max="8" value={weeks} onChange={(e) => setWeeks(Number(e.target.value))} aria-label="Semanas desde o último corte" />
              </label>
            </div>
          </Reveal>
          <Reveal as="article" className="why__card" delay={200}>
            <span className="why__n">03</span>
            <h3>Cuida da aparência dos fios</h3>
            <p>Fios com pontas íntegras refletem mais luz, embaraçam menos e respondem melhor a pomada e pente. Cabelo bem aparado parece mais cheio e saudável.</p>
            <svg className="why__art" viewBox="0 0 240 110" role="img" aria-label="Cutícula lisa reflete mais luz do que cutícula levantada">
              <g stroke="#ebd299" strokeWidth="2" strokeLinecap="round" opacity=".85">
                <path d="M30 14 L52 40 M58 8 L72 40" /><path d="M170 14 L186 40 M198 8 L206 40" opacity=".35" />
              </g>
              <path d="M20 44 H100 M30 56 H110 M20 68 H100 M30 80 H110" stroke="#c9a45c" strokeWidth="6" strokeLinecap="round" fill="none" />
              <path d="M140 44 l16 -9 h58 M150 58 l16 -9 h58 M140 72 l16 -9 h58 M150 86 l16 -9 h58" stroke="#8f6f32" strokeWidth="6" strokeLinecap="round" fill="none" />
              <text x="60" y="104" textAnchor="middle">cutícula lisa</text>
              <text x="180" y="104" textAnchor="middle">levantada</text>
            </svg>
          </Reveal>
        </div>

        <Reveal className="myth">
          <GrowthMyth />
        </Reveal>
      </div>
    </section>
  );
}
