import { useEffect, useState } from 'react';
import { useSite } from '../site-context.js';
import { waLink } from '../lib/whatsapp.js';
import { IconCalendar, IconWhatsApp } from './icons.jsx';

export default function FloatingActions() {
  const { business, startBooking } = useSite();
  const [hideBook, setHideBook] = useState(false);

  useEffect(() => {
    const el = document.getElementById('agendar');
    if (!el) return undefined;
    const io = new IntersectionObserver(([e]) => setHideBook(e.isIntersecting), { threshold: 0.15 });
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div className="fab">
      <a
        className="fab__wa"
        href={waLink(business.whatsapp, `Olá, ${business.businessName}! Gostaria de saber mais sobre um horário.`)}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Falar no WhatsApp"
      >
        <IconWhatsApp size={26} />
        <span>WhatsApp</span>
      </a>
      <button className={`btn btn--primary fab__book ${hideBook ? 'is-hidden' : ''}`} onClick={() => startBooking()}>
        <span>
          <IconCalendar /> Agendar
        </span>
      </button>
    </div>
  );
}
