import { useId } from 'react';

/* Silhueta de perfil desenhada em SVG, com o cabelo montado por camadas:
   1) laterais e nuca em degradê (pontilhado que some até a pele),
   2) volume do topo por fora do crânio.
   Assim cada corte é só uma configuração, e o mesmo desenho serve para a
   galeria e para a animação de "corte crescendo". */

const HEAD =
  'M62 250 L66 180 C44 162 34 132 38 100 C42 55 80 26 112 28 C140 30 156 56 158 88 L160 104 L174 130 C176 136 168 138 162 138 L163 148 L160 154 L163 164 C163 176 150 184 138 186 L124 189 L124 250 Z';
const SKULL_ARC = 'L158 88 C156 56 140 30 112 28 C80 26 42 55 38 100 Z';
const ZONE = 'M152 56 L156 80 L128 92 L110 98 L103 120 L97 152 L82 172 L60 186 L8 186 L8 8 L172 8 Z';
const ZONE_FULL = 'M8 8 L172 8 L172 80 L150 96 L112 108 L103 122 L97 152 L82 172 L60 186 L8 186 Z';

export const CUT_KINDS = {
  low: {
    fade: [118, 172],
    outer: `M38 100 C28 56 68 10 118 14 C152 18 168 48 160 88 ${SKULL_ARC}`,
    quiff: 'M148 44 C172 42 180 66 166 90 L158 88 Z',
    strokes: ['M60 60 C84 30 120 28 146 46', 'M52 84 C66 50 96 36 128 36'],
  },
  mid: {
    fade: [96, 148],
    outer: `M38 100 C28 52 66 8 118 12 C152 16 168 48 160 88 ${SKULL_ARC}`,
    quiff: 'M148 42 C174 38 182 66 166 90 L158 88 Z',
    strokes: ['M58 62 C84 28 122 26 148 46', 'M50 86 C64 48 98 32 130 34'],
  },
  high: {
    fade: [70, 120],
    outer: `M38 100 C22 44 66 -4 122 2 C160 6 174 46 160 88 ${SKULL_ARC}`,
    quiff: 'M146 32 C178 24 188 62 168 92 L158 88 Z',
    strokes: ['M56 56 C84 14 126 8 152 34', 'M48 84 C60 38 100 16 134 20'],
  },
  social: {
    fade: [104, 164],
    outer: `M38 100 C30 58 70 16 116 18 C150 20 166 50 160 88 ${SKULL_ARC}`,
    quiff: 'M150 50 C168 52 172 72 162 90 L158 88 Z',
    strokes: ['M70 40 C100 34 130 38 150 56', 'M52 76 C70 46 98 34 126 34'],
    part: 'M92 24 C104 32 112 42 112 56',
  },
  mullet: {
    fade: [96, 142],
    outer: `M38 100 C28 54 70 14 116 16 C148 18 166 46 160 88 ${SKULL_ARC}`,
    quiff: 'M148 44 C172 44 180 68 166 90 L158 88 Z',
    tail: 'M46 108 C14 152 22 208 54 244 L88 238 C70 206 72 178 68 160 Z',
    strokes: ['M60 62 C86 30 120 28 148 46', 'M32 150 C34 190 44 220 60 238', 'M44 140 C44 180 54 210 70 230'],
  },
  buzz: {
    fade: [150, 196],
    full: true,
    outer: `M38 100 C36 52 78 22 112 24 C142 26 162 52 162 88 ${SKULL_ARC}`,
    strokes: [],
  },
};

const HAIR = '#2d1f17';
const HAIR_HI = '#5a4233';

export default function CutHead({ kind = 'low', growth = 0, label }) {
  const id = useId().replace(/:/g, '');
  const cfg = CUT_KINDS[kind];
  const g = Math.max(0, Math.min(1, growth));
  const [top, bottom] = cfg.fade;
  // com o tempo o degradê "sobe" e a pele ganha penugem
  const fadeTop = top - 26 * g;
  const fadeBottom = bottom + 10 * g;
  const skinHair = (cfg.full ? 0.62 : 0) + 0.7 * g * (cfg.full ? 0.4 : 1);
  const lift = 1 + 0.42 * g;

  return (
    <svg
      className="cut-head"
      viewBox="0 0 220 260"
      role="img"
      aria-label={label || `Ilustração do corte ${kind}`}
      focusable="false"
    >
      <defs>
        <linearGradient id={`skin-${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#d6a07a" />
          <stop offset="1" stopColor="#a8714f" />
        </linearGradient>
        <linearGradient id={`fade-${id}`} gradientUnits="userSpaceOnUse" x1="0" y1={fadeTop} x2="0" y2={fadeBottom}>
          <stop offset="0" stopColor="#fff" />
          <stop offset="1" stopColor="#000" />
        </linearGradient>
        <mask id={`mask-${id}`} maskUnits="userSpaceOnUse" x="0" y="0" width="220" height="260">
          <rect width="220" height="260" fill={`url(#fade-${id})`} />
        </mask>
        <pattern id={`dots-${id}`} width="3.2" height="3.2" patternUnits="userSpaceOnUse" patternTransform="rotate(18)">
          <circle cx="1.1" cy="1.1" r="1.05" fill={HAIR} />
          <circle cx="2.7" cy="2.7" r="0.7" fill={HAIR} />
        </pattern>
        <clipPath id={`head-${id}`}>
          <path d={HEAD} />
        </clipPath>
        <clipPath id={`zone-${id}`}>
          <path d={cfg.full ? ZONE_FULL : ZONE} />
        </clipPath>
        <radialGradient id={`halo-${id}`} cx="50%" cy="38%" r="55%">
          <stop offset="0" stopColor="#c9a45c" stopOpacity=".28" />
          <stop offset="1" stopColor="#c9a45c" stopOpacity="0" />
        </radialGradient>
      </defs>

      <circle cx="110" cy="112" r="112" fill={`url(#halo-${id})`} />

      {cfg.tail && <path d={cfg.tail} fill={HAIR} />}
      <path d={HEAD} fill={`url(#skin-${id})`} />
      {/* sombra suave do pescoço */}
      <path d="M66 184 C90 204 112 200 124 189 L124 250 L62 250 Z" fill="#000" opacity=".16" />

      <g clipPath={`url(#head-${id})`}>
        <g clipPath={`url(#zone-${id})`}>
          {/* base: sombra suave do cabelo curto */}
          <rect width="220" height="260" fill={HAIR} opacity={0.5} mask={`url(#mask-${id})`} />
          {/* pontilhado: a barba por fazer do degradê */}
          <rect width="220" height="260" fill={`url(#dots-${id})`} mask={`url(#mask-${id})`} />
          {/* fios que crescem na área de pele */}
          {skinHair > 0 && <rect width="220" height="260" fill={`url(#dots-${id})`} opacity={skinHair} />}
          {/* parte superior sempre densa */}
          <rect x="0" y="0" width="220" height={Math.max(0, fadeTop)} fill={HAIR} />
        </g>
      </g>

      {/* orelha */}
      <path d="M96 114 C86 106 82 120 88 134 C92 142 100 140 102 132" fill="#bf8862" stroke="#8f5f40" strokeWidth="1.2" />

      {/* volume do topo */}
      <g style={{ transformOrigin: '100px 70px', transform: `scaleY(${lift})`, transition: 'transform .6s cubic-bezier(.22,1,.36,1)' }}>
        <path d={cfg.outer} fill={HAIR} />
        {cfg.quiff && <path d={cfg.quiff} fill={HAIR} />}
        {cfg.strokes.map((d) => (
          <path key={d} d={d} fill="none" stroke={HAIR_HI} strokeWidth="2.2" strokeLinecap="round" opacity=".7" />
        ))}
        {cfg.part && <path d={cfg.part} fill="none" stroke="#cfa77f" strokeWidth="1.8" strokeLinecap="round" opacity=".85" />}
      </g>

      {/* olho e sobrancelha */}
      <path d="M142 100 q6 -4 12 0" fill="none" stroke="#2a1a12" strokeWidth="2.2" strokeLinecap="round" />
      <circle cx="148" cy="107" r="1.9" fill="#2a1a12" />
    </svg>
  );
}
