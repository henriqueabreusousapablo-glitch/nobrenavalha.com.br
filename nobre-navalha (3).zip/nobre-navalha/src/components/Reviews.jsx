import { useEffect, useRef, useState } from 'react';
import { Reveal } from '../hooks/useReveal.jsx';
import { REVIEWS } from '../data/reviews.js';
import { IconChevron, IconStar } from './icons.jsx';

export default function Reviews() {
  const [i, setI] = useState(0);
  const [paused, setPaused] = useState(false);
  const timer = useRef();

  useEffect(() => {
    if (paused || matchMedia('(prefers-reduced-motion: reduce)').matches) return undefined;
    timer.current = setInterval(() => setI((v) => (v + 1) % REVIEWS.length), 7000);
    return () => clearInterval(timer.current);
  }, [paused]);

  const go = (n) => setI((n + REVIEWS.length) % REVIEWS.length);

  return (
    <section className="section section--alt" id="avaliacoes" aria-labelledby="avaliacoes-t">
      <div className="wrap reviews">
        <div className="section__head">
          <Reveal as="p" className="eyebrow">Avaliações</Reveal>
          <Reveal as="h2" id="avaliacoes-t" className="section__title">
            Quem senta, <em>volta</em>
          </Reveal>
        </div>

        <Reveal
          className="quote"
          variant="scale"
          onMouseEnter={() => setPaused(true)}
          onMouseLeave={() => setPaused(false)}
          onFocus={() => setPaused(true)}
          onBlur={() => setPaused(false)}
        >
          <span className="quote__mark" aria-hidden="true">“</span>
          <div className="quote__viewport" aria-live="polite">
            {REVIEWS.map((r, n) => (
              <figure key={r.name} className={`quote__slide ${n === i ? 'is-on' : ''}`} aria-hidden={n !== i}>
                <div className="stars" role="img" aria-label="5 de 5 estrelas">
                  {[0, 1, 2, 3, 4].map((s) => <IconStar key={s} size={18} />)}
                </div>
                <blockquote>{r.text}</blockquote>
                <figcaption><b>{r.name}</b> · {r.detail}</figcaption>
              </figure>
            ))}
          </div>
          <div className="quote__nav">
            <button className="icon-btn" onClick={() => go(i - 1)} aria-label="Avaliação anterior"><IconChevron dir="left" /></button>
            <div className="dots" role="tablist" aria-label="Escolher avaliação">
              {REVIEWS.map((r, n) => (
                <button key={r.name} role="tab" aria-selected={n === i} aria-label={`Avaliação de ${r.name}`} className={n === i ? 'is-on' : ''} onClick={() => setI(n)} />
              ))}
            </div>
            <button className="icon-btn" onClick={() => go(i + 1)} aria-label="Próxima avaliação"><IconChevron dir="right" /></button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
