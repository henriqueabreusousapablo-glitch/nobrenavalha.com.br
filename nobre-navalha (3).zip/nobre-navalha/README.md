# Nobre Navalha

Site e sistema de agendamento da barbearia **Nobre Navalha**: *"Seu estilo começa no corte certo"*.

- **Front-end:** React 19 + CSS próprio (sem framework de UI), compilado com esbuild.
- **Back-end:** servidor Node.js sem dependências externas (módulos nativos `http`, `crypto` e `node:sqlite`).
- **Banco de dados:** SQLite em um único arquivo (`data/nobre-navalha.db`).

## O que o site tem

| Recurso | Como funciona |
| --- | --- |
| Agendamento online | O cliente escolhe serviço, barbeiro, data e horário livre, informa nome e telefone e confirma. Recebe um código para consultar ou cancelar depois, e pode baixar o evento para o calendário (.ics). |
| Sem reservas duplicadas | Cada reserva roda em uma transação com `BEGIN IMMEDIATE`, que checa a sobreposição de horários. Um índice único no banco (`barbeiro + data + horário`) é a barreira final: mesmo com pedidos simultâneos, só um é aceito. Serviços longos (1 h) bloqueiam os dois intervalos. |
| Serviços e preços editáveis | Painel em `/admin`. A alteração aparece no site na hora. |
| Painel da barbearia | Agenda do dia/semana, mudança de status (concluído, faltou, cancelado), serviços, barbeiros, horários de funcionamento, feriados e contatos. |
| Galeria de cortes | Low fade, mid fade, high fade, corte social, mullet e buzz cut, em ilustrações vetoriais desenhadas em SVG. |
| Ciência do fio | Animação interativa: cutícula, córtex e medula, efeito de calor e atrito, pontas duplas, corte das pontas e a explicação de que **cortar o cabelo não acelera o crescimento** (ele nasce no folículo). |
| Extras | Barbeiros, avaliações em carrossel, endereço com mapa, horário de funcionamento com aviso "aberto agora", botão de WhatsApp, animações ao rolar, SEO (meta tags, Open Graph, JSON-LD, sitemap, robots). |
| Segurança | Limite de requisições, campo isca anti-robô, cabeçalhos de segurança, validação de todos os dados, token do painel assinado e com expiração. |

## Requisitos

- **Node.js 22.13 ou superior** (https://nodejs.org). O SQLite usado vem embutido no Node, então não há nada nativo para compilar.

## Rodar no seu computador

```bash
npm install          # instala React e esbuild
npm run dev          # compila o front ao salvar e reinicia o servidor
```

Abra http://localhost:3000. O painel fica em http://localhost:3000/admin.

Em desenvolvimento a senha do painel é `navalha123`. **Troque antes de publicar** (veja abaixo).

Outros comandos:

```bash
npm run build        # gera a pasta dist/ (produção, minificada)
npm start            # sobe o servidor de produção (serve dist/ e a API)
npm test             # 39 testes automatizados do servidor
```

## Configuração (variáveis de ambiente)

Copie `.env.example` como referência. Nenhuma é obrigatória em desenvolvimento.

| Variável | Para que serve | Padrão |
| --- | --- | --- |
| `ADMIN_PASSWORD` | Senha do painel `/admin`. **Obrigatória em produção**; sem ela o painel fica desativado. | `navalha123` só em dev |
| `SITE_URL` | Endereço público, ex.: `https://nobrenavalha.com.br`. Usado em canonical, sitemap e dados estruturados. | vazio |
| `DATABASE_PATH` | Onde fica o arquivo do banco. Em produção, aponte para um disco persistente. | `./data/nobre-navalha.db` |
| `PORT` / `HOST` | Porta e interface do servidor. | `3000` / `0.0.0.0` |
| `SHOP_TIMEZONE` | Fuso da barbearia (define "hoje" e o horário de agora). | `America/Sao_Paulo` |
| `TRUST_PROXY` | Quantos proxies existem na frente (Render, Railway, Nginx = `1`). Necessário para o limite de requisições ver o IP real. | `1` em produção |

## Personalizar o conteúdo

**Pelo painel `/admin`** (sem mexer em código): serviços, preços, durações, barbeiros, horário de funcionamento, feriados, telefone, WhatsApp, endereço e Instagram.

**Dados de exemplo.** Os serviços, barbeiros, endereço (`Av. Paulista, 1000`), telefone e WhatsApp (`(11) 99999-0000`) que vêm de fábrica são fictícios. Troque tudo pelo painel antes de divulgar. Eles só são gravados na primeira execução, então editar pelo painel nunca é sobrescrito por um novo deploy.

**Avaliações.** Os depoimentos em `src/data/reviews.js` são **exemplos**. Substitua por avaliações reais dos seus clientes (com autorização) antes de publicar. O site não declara nota agregada nos dados estruturados do Google, de propósito: só adicione `aggregateRating` em `server/seo.js` com a nota real do seu perfil.

**Cortes da galeria:** `src/data/cuts.js`. **Visual:** variáveis de cor no topo de `src/styles/base.css`.

## Estrutura

```
server/            API + servidor de arquivos
  app.js           rotas e middlewares
  scheduling.js    horários livres, reserva, cancelamento (transações)
  db.js            esquema SQLite e índice único anti-duplicidade
  catalog.js       serviços, barbeiros e configurações
  seo.js           meta tags, JSON-LD, sitemap, robots
  tests/           testes automatizados
src/               React
  components/      Hero, Services, Booking, Cuts, Barbers, HairScience, Reviews, Location, Admin...
  styles/          CSS por área
scripts/           build (esbuild) e modo dev
public/            favicon, ícones, imagem de compartilhamento, manifest
```

## Publicar

O site precisa de um servidor Node com **disco persistente** (o banco é um arquivo). Hospedagem apenas estática, como Netlify ou GitHub Pages, **não serve**, porque não roda o back-end. Também rode **uma única instância**: SQLite não deve ser compartilhado entre várias máquinas.

### Opção 1: Render (mais simples)

1. Suba o projeto para um repositório no GitHub.
2. No Render: **New → Blueprint** e escolha o repositório. O arquivo `render.yaml` já configura build, disco e variáveis.
3. Defina `ADMIN_PASSWORD` e `SITE_URL` quando solicitado.
4. Disco persistente exige plano pago. Aponte o domínio próprio em **Settings → Custom Domains**.

### Opção 2: Docker (Railway, Fly.io, VPS)

```bash
docker build -t nobre-navalha .
docker run -d --name nobre-navalha -p 3000:3000 \
  -v nobre-data:/data \
  -e ADMIN_PASSWORD='uma-senha-forte' \
  -e SITE_URL='https://seudominio.com.br' \
  --restart unless-stopped \
  nobre-navalha
```

O volume `/data` guarda o banco. No Railway e no Fly.io, crie um volume montado em `/data` e defina as mesmas variáveis.

### Opção 3: VPS sem Docker (Ubuntu)

```bash
# Node 22+ instalado
git clone <seu-repositorio> /srv/nobre-navalha && cd /srv/nobre-navalha
npm install && npm run build
export NODE_ENV=production ADMIN_PASSWORD='uma-senha-forte' SITE_URL='https://seudominio.com.br'
npm install -g pm2
pm2 start server/index.js --name nobre-navalha --node-args="--disable-warning=ExperimentalWarning"
pm2 save && pm2 startup
```

Coloque Nginx ou Caddy na frente, com HTTPS (Let's Encrypt), repassando para `localhost:3000`.

### Depois de publicar

- Acesse `/admin`, entre com a senha e confira serviços, horários, endereço e WhatsApp.
- Faça uma reserva de teste e cancele pelo painel.
- Cadastre o site no Google Search Console e envie `https://seudominio.com.br/sitemap.xml`.
- Crie o seu perfil no Google Meu Negócio com o mesmo endereço e telefone.

### Backup

Copie o arquivo do banco (`data/nobre-navalha.db`, mais os arquivos `-wal` e `-shm` se existirem) com o servidor parado, ou use `sqlite3 nobre-navalha.db ".backup backup.db"` com ele rodando. Um backup diário é suficiente.

## Observações

- As fontes (Bodoni Moda e Manrope) vêm do Google Fonts. Sem internet o site usa fontes do sistema e continua funcionando.
- O mapa usa o Google Maps incorporado pelo endereço cadastrado.
- O pagamento é no local; o site não processa pagamentos.
