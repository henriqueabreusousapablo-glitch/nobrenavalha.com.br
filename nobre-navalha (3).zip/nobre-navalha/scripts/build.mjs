// Compila o front-end (React + CSS) com esbuild e gera dist/index.html.
//   node scripts/build.mjs           -> build de produção (minificado)
//   node scripts/build.mjs --watch   -> recompila ao salvar (usado por "npm run dev")
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { build, context } from 'esbuild';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
process.chdir(root);

const dist = path.join(root, 'dist');
const watch = process.argv.includes('--watch');

const toUrl = (file) => '/' + path.relative(dist, path.resolve(root, file)).split(path.sep).join('/');

/** Monta o index.html final apontando para os arquivos com hash gerados pelo esbuild. */
async function writeHtml(metafile) {
  const entry = Object.entries(metafile.outputs).find(([, out]) => out.entryPoint === 'src/main.jsx');
  if (!entry) throw new Error('Entrada src/main.jsx não encontrada no resultado do build.');
  const [jsFile, info] = entry;

  const css = info.cssBundle ? `<link rel="stylesheet" href="${toUrl(info.cssBundle)}">` : '';
  const js = `<script type="module" src="${toUrl(jsFile)}"></script>`;
  const preload = `<link rel="modulepreload" href="${toUrl(jsFile)}">`;

  const template = await fs.readFile(path.join(root, 'src', 'index.html'), 'utf8');
  const html = template.replace('<!--@css-->', `${preload}\n    ${css}`).replace('<!--@js-->', js);
  await fs.writeFile(path.join(dist, 'index.html'), html);
}

async function copyPublic() {
  await fs.cp(path.join(root, 'public'), dist, { recursive: true });
}

const options = {
  entryPoints: ['src/main.jsx'],
  bundle: true,
  splitting: true,
  format: 'esm',
  outdir: 'dist/assets',
  entryNames: '[name]-[hash]',
  chunkNames: 'chunk-[hash]',
  assetNames: 'media/[name]-[hash]',
  jsx: 'automatic',
  target: ['es2020', 'chrome96', 'firefox95', 'safari15'],
  minify: !watch,
  sourcemap: watch ? 'inline' : false,
  legalComments: 'none',
  metafile: true,
  logLevel: 'info',
  define: { 'process.env.NODE_ENV': JSON.stringify(watch ? 'development' : 'production') },
  plugins: [
    {
      name: 'html',
      setup(b) {
        b.onEnd(async (result) => {
          if (result.errors.length) return;
          await writeHtml(result.metafile);
        });
      },
    },
  ],
};

await fs.rm(dist, { recursive: true, force: true });
await fs.mkdir(dist, { recursive: true });
await copyPublic();

if (watch) {
  const ctx = await context(options);
  await ctx.watch();
  console.log('[build] observando alterações em src/ ...');
} else {
  const result = await build(options);
  const sizes = Object.entries(result.metafile.outputs)
    .filter(([file]) => /\.(js|css)$/.test(file))
    .map(([file, out]) => `${(out.bytes / 1024).toFixed(1).padStart(7)} KB  ${file}`);
  console.log(`\nArquivos gerados:\n${sizes.join('\n')}`);
}
