// Ambiente de desenvolvimento: recompila o front-end e reinicia o servidor ao salvar.
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const children = [];

function run(name, args) {
  const child = spawn(process.execPath, args, { cwd: root, stdio: 'inherit', env: process.env });
  child.on('exit', (code) => {
    if (code) console.error(`[${name}] terminou com código ${code}`);
    shutdown();
  });
  children.push(child);
}

function shutdown() {
  for (const child of children) child.kill();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

run('build', ['scripts/build.mjs', '--watch']);
run('server', ['--watch', '--watch-path=server', '--disable-warning=ExperimentalWarning', 'server/index.js']);
